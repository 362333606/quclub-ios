module.exports = /******/ (function (modules) {
    // webpackBootstrap
    /******/ // The module cache
    /******/
    var installedModules = {};
    /******/
    /******/ // The require function
    /******/
    function __webpack_require__(moduleId) {
        /******/
        /******/ // Check if module is in cache
        /******/ if (installedModules[moduleId]) {
            /******/ return installedModules[moduleId].exports;
            /******/
        }
        /******/ // Create a new module (and put it into the cache)
        /******/
        var module = (installedModules[moduleId] = {
            /******/ i: moduleId,
            /******/ l: false,
            /******/ exports: {}
            /******/
        });
        /******/
        /******/ // Execute the module function
        /******/
        modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        /******/
        /******/ // Flag the module as loaded
        /******/
        module.l = true;
        /******/
        /******/ // Return the exports of the module
        /******/
        return module.exports;
        /******/
    }
    /******/
    /******/
    /******/ // expose the modules object (__webpack_modules__)
    /******/
    __webpack_require__.m = modules;
    /******/
    /******/ // expose the module cache
    /******/
    __webpack_require__.c = installedModules;
    /******/
    /******/ // define getter function for harmony exports
    /******/
    __webpack_require__.d = function (exports, name, getter) {
        /******/ if (!__webpack_require__.o(exports, name)) {
            /******/ Object.defineProperty(exports, name, {
                enumerable: true,
                get: getter
            });
            /******/
        }
        /******/
    };
    /******/
    /******/ // define __esModule on exports
    /******/
    __webpack_require__.r = function (exports) {
        /******/ if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
            /******/ Object.defineProperty(exports, Symbol.toStringTag, {
                value: 'Module'
            });
            /******/
        }
        /******/
        Object.defineProperty(exports, '__esModule', {
            value: true
        });
        /******/
    };
    /******/
    /******/ // create a fake namespace object
    /******/ // mode & 1: value is a module id, require it
    /******/ // mode & 2: merge all properties of value into the ns
    /******/ // mode & 4: return value when already ns object
    /******/ // mode & 8|1: behave like require
    /******/
    __webpack_require__.t = function (value, mode) {
        /******/ if (mode & 1) value = __webpack_require__(value);
        /******/
        if (mode & 8) return value;
        /******/
        if (mode & 4 && typeof value === 'object' && value && value.__esModule) return value;
        /******/
        var ns = Object.create(null);
        /******/
        __webpack_require__.r(ns);
        /******/
        Object.defineProperty(ns, 'default', {
            enumerable: true,
            value: value
        });
        /******/
        if (mode & 2 && typeof value != 'string')
            for (var key in value)
                __webpack_require__.d(
                    ns,
                    key,
                    function (key) {
                        return value[key];
                    }.bind(null, key)
                );
        /******/
        return ns;
        /******/
    };
    /******/
    /******/ // getDefaultExport function for compatibility with non-harmony modules
    /******/
    __webpack_require__.n = function (module) {
        /******/ var getter =
            module && module.__esModule
                ? /******/ function getDefault() {
                      return module['default'];
                  }
                : /******/ function getModuleExports() {
                      return module;
                  };
        /******/
        __webpack_require__.d(getter, 'a', getter);
        /******/
        return getter;
        /******/
    };
    /******/
    /******/ // Object.prototype.hasOwnProperty.call
    /******/
    __webpack_require__.o = function (object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
    };
    /******/
    /******/ // __webpack_public_path__
    /******/
    __webpack_require__.p = '';
    /******/
    /******/
    /******/ // Load entry module and return exports
    /******/
    return __webpack_require__((__webpack_require__.s = 0));
    /******/
})(
    /************************************************************************/
    /******/ [
        /* 0 */
        /***/ function (module, exports, __webpack_require__) {
            'use strict';

            /* eslint-disable */
            // 小程序开发api接口工具包，https://github.com/gooking/wxapi
            // var API_BASE_URL = 'https://api.it120.cc';
            var API_BASE_URL = 'https://top.qiuyu8.cn/fireshop';
			// var API_BASE_URL = 'http://localhost:8082/api';
            var subDomain = '';
            var merchantId = '0';
            var request = function request(url, needSubDomain, method, data) {
                var _url = API_BASE_URL + (needSubDomain ? subDomain : '') + url;
                var header = {
                    'Content-Type': 'application/x-www-form-urlencoded',
					'X-paly-Token': uni.getStorageSync('bestpw-Token')
                };
		
                return new Promise(function (resolve, reject) {
                    uni.request({
                        url: _url,
                        method: method,
                        data: data,
                        header: header,
                        success: function success(request) {
                            resolve(request.data);
                        },
                        fail: function fail(error) {
                            reject(error);
                        },
                        complete: function complete(aaa) {
                            // 加载完成
                        }
                    });
                });
            };

            /**
             * 小程序的promise没有finally方法，自己扩展下
             */
            // Promise.prototype.finally = function (callback) {
            //   var Promise = this.constructor;
            //   return this.then(
            //     function (value) {
            //       Promise.resolve(callback()).then(
            //         function () {
            //           return value;
            //         }
            //       );
            //     },
            //     function (reason) {
            //       Promise.resolve(callback()).then(
            //         function () {
            //           throw reason;
            //         }
            //       );
            //     }
            //   );
            // }

            module.exports = {
                init2: function init2(a, b) {
                    API_BASE_URL = a;
                    subDomain = b;
                },
                init: function init(b) {
                    subDomain = b;
                },
                setMerchantId: function setMerchantId(mchid) {
                    merchantId = mchid;
                },
                init3: function init3(_ref) {
                    var _ref$apiBaseUrl = _ref.apiBaseUrl,
                        apiBaseUrl = _ref$apiBaseUrl === undefined ? API_BASE_URL : _ref$apiBaseUrl,
                        subD = _ref.subDomain,
                        req = _ref.request;

                    // 某些需求需要定制化 request，需要保证传入自定义 reuqest 与默认 request 参数一致
                    if (req) {
                        request = req;
                    }
                    API_BASE_URL = apiBaseUrl;
                    subDomain = subD;
                },
                request: request,
                queryMobileLocation: function queryMobileLocation() {
                    var mobile = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
                    return request('/common/mobile-segment/location', false, 'get', {
                        mobile: mobile
                    });
                },
				//
				//
				goods: function goods(data) {
				    return request('/best', true, 'get', data);
				},
				citys: function citys() {
				    return request('/citys', true, 'get', {});
				},
				goodsDetail: function goodsDetail(id) {
				    return request('/best/detail/'+id, true, 'get', {});
				},
				plazaList: function plazaList(data) {
				    return request('/plaza', true, 'get', data);
				},
				serveList: function serveList(data) {
				    return request('/best/serve', true, 'get', data);
				},
				tagList: function tagList() {
				    return request('/best/tags', true, 'get', {});
				},
				postPlaza: function postPlaza(data) {
				    return request('/plaza/save', true, 'post', data);
				},
				rechargePackage: function rechargePackage(data) {
				    return request('/balance/recharge_Package', true, 'get', {});
				},
				menuList: function menuList(data) {
				    return request('/menu/list', true, 'get', data);
				},
				gratuityList: function gratuityList(data) {
				    return request('/best/gratuity', true, 'get', data);
				},
				mallGoodsList: function mallGoodsList(data) {
				    return request('/goods', true, 'get', data);
				},
				mallGoodsDetail: function mallGoodsDetail(id) {
				    return request('/goods/detail/'+id, true, 'get', {});
				},
				followList: function followList(data) {
				    return request('/follow', true, 'get', data);
				},
				demandList: function demandList(data) {
				    return request('/demand', true, 'get', data);
				},
				orderList: function orderList(data) {
				    return request('/order', true, 'get', data);
				},
				orderDetail: function orderList(id) {
				    return request('/order/detail/'+id, true, 'get', {});
				},
				postPartner: function postPartner(data) {
				     return request('/partner/save', true, 'post', data);
				},
				postActivity: function postActivity(data) {
				     return request('/activity/save', true, 'post', data);
				},
				newsDetail: function newsDetail(id) {
				    return request('/news/detail?id='+id, true, 'get', {});
				},
				checkToken: function checkToken(token) {
				    return request('/wxuser/check-token', true, 'get', {
				        token: token
				    });
				},
				authorize: function authorize(data) {
				    return request('/wxuser/authorize', true, 'post', data);
				},
				newlogine: function newlogine(phone,password) {
				    return request('/login', true, 'post', {
				        phone,
						password
				    });
				},
				userDetail: function userDetail() {
				    return request('/user/detail', true, 'get', {});
				},
				goodsFollow: function goodsFollow(data) {
				    return request('/follow/update', true, 'post', data);
				},
				resetPwd: function resetPwd(data) {
				    return request('/resetPwd', true, 'post', data);
				},
				goodsFavCheck: function goodsFavCheck(goodsId) {
				    return request('/follow/check', true, 'get', {
				        bestId: goodsId
				    });
				},
				bestStatus: function bestStatus(data) {
				    return request('/best/status', true, 'post', data);
				},
				bestAlbum: function bestAlbum(data) {
				    return request('/best/album', true, 'get', data);
				},
				balance: function balance() {
				    return request('/balance', true, 'get', {});
				},
				balanceDeposit: function balanceDeposit(data) {
				    return request('/balance/deposit', true, 'post', data);
				},
				bestSaveAlbum: function bestSaveAlbum(data) {
				    return request('/best/saveAlbum', true, 'post', data);
				},
				demandSave: function demandSave(data) {
				    return request('/demand/save', true, 'post', data);
				},
				getMsgCode: function getMsgCode(data) {
				    return request('/sendCode', true, 'post', data);
				},
				newRegister: function newregister(data) {
				    return request('/register', true, 'post', data);
				},
				partner: function partner(data) {
				    return request('/partner', true, 'get', data);
				},
				demandOrder: function demandOrder(data) {
				    return request('/demand/order', true, 'get', data);
				},
				demandAll: function demandAll(data) {
				    return request('/demand/all', true, 'get', data);
				},
				demandDetail: function demandDetail(data) {
				    return request('/demand/detail', true, 'get', data);
				},
				demandSign: function demandSign(data) {
				    return request('/demand/sign', true, 'post', data);
				},
				orderDemandList: function orderDemandList(data) {
				    return request('/order/demand', true, 'get', data);
				},
				orderClose: function orderClose(data) {
				    return request('/order/close', true, 'post', data);
				},
				payOrder: function payOrder(data) {
				    return request('/pay/order', true, 'post', data);
				},
				bestAttr: function bestAttr(data) {
				    return request('/best/attr', true, 'get', data);
				},
				orderCreate: function orderCreate(data) {
				    return request('/order/create', true, 'post', data);
				},
				goodsOrderCreate: function goodsOrderCreate(data) {
				    return request('/goodsOrders/create', true, 'post', data);
				},
				goodsOrderList: function goodsOrderList(data) {
				    return request('/goodsOrders', true, 'get', data);
				},
				goodsOrderDetail: function goodsOrderDetail(id) {
				    return request('/goodsOrders/detail/'+id, true, 'get', {});
				},
				goodsOrderClose: function goodsOrderClose(data) {
				    return request('/goodsOrders/close', true, 'post', data);
				},
				activityRez: function activityRez(data) {
				    return request('/activity/rez', true, 'post', data);
				},
				messageList: function messageList(data) {
				    return request('/message/list', true, 'get', data);
				},
				messageUnReadCount: function messageUnReadCount(data) {
				    return request('/message/unRead/count', true, 'get', data);
				},
				balanceWithdrawal: function balanceWithdrawal(data) {
				    return request('/balance/withdrawal', true, 'post', data);
				},
				userUpdate: function userUpdate(data) {
				    return request('/user/update', true, 'post', data);
				},
				userInviteList: function userInviteList(data) {
				    return request('/user/inviteList', true, 'get', data);
				},
				plazaRemove: function plazaRemove(data) {
				    return request('/plaza/remove', true, 'post', data);
				},
				plazaSign: function plazaSign(data) {
				    return request('/plaza/sign', true, 'post', data);
				},
				getOpenId: function getOpenId(data) {
				    return request('/wxuser/openid', true, 'post', data);
				},
				bestAdd: function bestAdd(data) {
				    return request('/best/save', true, 'post', data);
				},
				getData: function getData(data) {
				    return request('/data', true, 'get', {
						name: data
					});
				},
				bestPlazaList: function bestPlazaList(data) {
				    return request('/best/plaza', true, 'get', data);
				},
				
				getLocation: function getLocation(data) {
				    return request('/ws/geocoder/v1/', true, 'get', data);
				},
				wxuserAuth: function checkToken(token) {
				    return request('/wxuser/auth', true, 'get', {});
				},
				wxLogin: function wxLogin(data) {
				    return request('/wxuser/login', true, 'post', data);
				},
				partnerLocate: function partnerLocate(data) {
				    return request('/partner/locate', true, 'post', data);
				},
				bindPhone: function bindPhone(data) {
				    return request('/user/bindphone', true, 'post', data);
				},
				newsNotice: function newsNotice(id) {
				    return request('/news/notice?id='+id, true, 'get', {});
				},
				bestLockWechat: function bestLockWechat(id) {
				    return request('/best/lockWechat?bestId='+id, true, 'get', {});
				},
				bestIsOrder: function bestIsOrder(id) {
				    return request('/best/isOrder?bestId='+id, true, 'get', {});
				},
				isBest: function isBest(id) {
				    return request('/best/isBest', true, 'get', {});
				},
				giftList: function giftList() {
				    return request('/gift/list', true, 'get', {});
				},
				withdrawalLinkDetail: function withdrawalLinkDetail(data) {
				    return request('/balance/withdrawalLink/detail', true, 'get', data);
				},
				withdrawalLink: function withdrawalLink(data) {
				    return request('/balance/withdrawalLink', true, 'post', data);
				},
				unlockLinkDetail: function withdrawalLinkDetail(data) {
				    return request('/unlockLink/detail', true, 'get', data);
				},
				unlockLink: function withdrawalLink(data) {
				    return request('/unlockLink', true, 'post', data);
				},
				
				//im
				roomIM: function roomIM(id) {
				    return request('/chat/room?toUserId='+ id, true, 'get', {});
				},
				initIM: function initIM() {
				    return request('/chat/init', true, 'get', {});
				},
				timePackageIM: function timePackageIM() {
				    return request('/chat/timePackage', true, 'get', {});
				},
				unLockIM: function bestLockIM(id) {
				    return request('/chat/lock?bestId='+id, true, 'get', {});
				},
				//
				//
				//
				

        
                checkReferrer: function checkReferrer(referrer) {
                    return request('/user/check-referrer', true, 'get', {
                        referrer: referrer
                    });
                },
                login_wx: function login_wx(code) {
                    //return request('/user/wxapp/login', true, 'post', {
                    return request('/wxuser/login', true, 'post', {
                        code: code,
                        type: 2
                    });
                },
                login_q: function login_q(code) {
                    return request('/user/q/login', true, 'post', {
                        code: code,
                        type: 2
                    });
                },
                loginWxaMobile: function loginWxaMobile(code, encryptedData, iv) {
                    return request('/user/wxapp/login/mobile', true, 'post', {
                        code: code,
                        encryptedData: encryptedData,
                        iv: iv
                    });
                },
                loginWxaMobileV2: function loginWxaMobileV2(data) {
                    return request('/user/wxapp/login/mobile', true, 'post', data);
                },
                login_username: function login_username(data) {
                    return request('/user/username/login', true, 'post', data);
                },
                bindUsername: function bindUsername(token, username) {
                    var pwd = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
                    return request('/user/username/bindUsername', true, 'post', {
                        token: token,
                        username: username,
                        pwd: pwd
                    });
                },
                userWxinfo: function userWxinfo(token) {
                    return request('/user/wxinfo', true, 'get', {
                        token: token
                    });
                },
                userAmount: function userAmount(token) {
                    return request('/wxuser/amount', true, 'get', {
                        token: token
                    });
                },
                province: function province() {
                    return request('/common/region/v2/province', false, 'get');
                },
                city: function city() {
                    return request('/common/region/v2/city', false, 'get');
                },
    
              
             
         
                bindOpenid: function bindOpenid(token, code) {
                    return request('/user/wxapp/bindOpenid', true, 'post', {
                        token: token,
                        code: code,
                        type: 2
                    });
                },
     
                voteLogs: function voteLogs(data) {
                    return request('/vote/vote/list', true, 'post', data);
                },

                register_email: function register_email(data) {
                    return request('/user/email/register', true, 'post', data);
                },
                login_email: function login_email(data) {
                    return request('/user/email/login', true, 'post', data);
                },
        
                growthLogs: function growthLogs(data) {
                    return request('/growth/logs', true, 'post', data);
                },
               
                register_tt: function register_tt(data) {
                    return request('/user/tt/microapp/register', true, 'post', data);
                },
                login_tt: function login_tt(code) {
                    return request('/user/tt/microapp/login', true, 'post', {
                        code: code
                    });
                },
                wxOpenAuthorization: function wxOpenAuthorization(data) {
                    return request('/user/wxsns/authorization', true, 'post', data);
                },
                userAttentioncheck: function userAttentioncheck(token, uid) {
                    return request('/user/attention/check', true, 'get', {
                        token: token,
                        uid: uid
                    });
                },
               
                wxappServiceLogin: function wxappServiceLogin(data) {
                    return request('/user/wxappService/login', true, 'post', data);
                },
                wxappServiceLoginWxaMobile: function wxappServiceLoginWxaMobile(data) {
                    return request('/user/wxappService/login/mobile', true, 'post', data);
                },
                wxappServiceRegisterComplex: function wxappServiceRegisterComplex(data) {
                    return request('/user/wxappService/register/complex', true, 'post', data);
                },
                wxappServiceRegisterSimple: function wxappServiceRegisterSimple(data) {
                    return request('/user/wxappService/register/simple', true, 'post', data);
                },
                wxappServiceAuthorize: function wxappServiceAuthorize(data) {
                    return request('/user/wxappService/authorize', true, 'post', data);
                },
                wxappServiceBindMobile: function wxappServiceBindMobile(data) {
                    return request('/user/wxappService/bindMobile', true, 'post', data);
                },
                wxappServiceBindOpenid: function wxappServiceBindOpenid(data) {
                    return request('/user/wxappService/bindOpenid', true, 'post', data);
                },
                wxappServiceEncryptedData: function wxappServiceEncryptedData(data) {
                    return request('/user/wxappService/decode/encryptedData', true, 'post', data);
                },
                
                setPayPassword: function setPayPassword(token, pwd) {
                    return request('/user/paypwd/set', true, 'post', {
                        token: token,
                        pwd: pwd
                    });
                },
                modifyPayPassword: function modifyPayPassword(token, pwdOld, pwdNew) {
                    return request('/user/paypwd/modify', true, 'post', {
                        token: token,
                        pwdOld: pwdOld,
                        pwdNew: pwdNew
                    });
                },
                resetPayPassword: function resetPayPassword(mobile, code, pwd) {
                    return request('/user/paypwd/reset', true, 'post', {
                        mobile: mobile,
                        code: code,
                        pwd: pwd
                    });
                },
                adPosition: function adPosition(key) {
                    return request('/site/adPosition/info', true, 'get', {
                        key: key
                    });
                },
            };
        }
    ]
);
