<template>
    <view style="height: 100%">
        <view class="container">
            <view class="goods-list">
                <view class="list-title">订单列表</view>
                <view class="a-goods" v-for="(item, index) in goodsList" :key="index">
                    <view class="img-box">
                        <image :src="imagebaseurl + item.goodsImg" class="img" />
                    </view>

                    <view class="text-box">
                        <view class="arow arow01">
                            <view class="goods-name">{{ item.goodsName }}</view>
                            <view class="goods-price">¥ {{ item.price.toFixed(2) }}</view>
                        </view>
                        <view class="arow">
                            <view class="goods-label">
                                {{ item.serveName }}
                                <!-- <block v-for="(option, index1) in item.sku" :key="index1">{{ option.optionName }}:{{ option.optionValueName }}</block> -->
                            </view>
                            <view class="goods-num">x {{ buyNumber }}</view>
                        </view>
                    </view>
                </view>
            </view>
            <view class="peisong-way">
                <!-- 预约人信息 -->
				<view class="row-box">
				    <view class="row-label">下单时长</view>
				    <view class="right-text num-box">
				       <view class="num-jian" @click="buyNumberTap(0)">-</view>
				       <view class="num-input">
				       	<input type="number" :value="buyNumber" disabled />
				       </view>
				       <view class="num-jia" @click="buyNumberTap(1)">+</view>
				    </view>
				</view>
				<view class="row-box">
				    <view class="row-label">约玩地址</view>
				    <view class="right-text">
				        <input v-model="address" type="text" class="liuyan" placeholder="请输入您的地址" />
				    </view>
				</view>
                <view class="row-box">
                    <view class="row-label">预约人姓名</view>
                    <view class="right-text">
                        <input v-model="name" type="text" class="liuyan" placeholder="请输入您的名字" />
                    </view>
                </view>
                <view class="row-box">
                    <view class="row-label">预约人手机</view>
                    <view class="right-text">
                        <input v-model="phone" type="text" class="liuyan" placeholder="请输入您的联系方式" />
                    </view>
                </view>
                <view class="row-box">
                    <view class="row-label">备注</view>
                    <view class="right-text">
                        <input v-model="remark" type="text" class="liuyan" placeholder="如需备注请输入" />
                    </view>
                </view>
				<view class="notice">
				    <block>
				        <rich-text :nodes="activityDetail"></rich-text>
				    </block>
				</view>
            </view>

            <view class="jiesuan-box safeAreaOldPaddingBttom safeAreaNewPaddingBttom">
                <view class="left-price">
                    <view class="total">合计：¥ {{ payAmount }}</view>
                </view>
                <button class="to-pay-btn" @tap="createOrder">提交订单</button>
            </view>
        </view>
		<view class="show-popup" v-if="isPay">
			<view class="popup-mask" @click="closePay"></view>
			<view class="popup-contents">
				<payment @toCancel="closePay" @okPay="okPay" :payTypeId="1" :payOrderId="payOrderId" :payAmount="payAmount"></payment>
			</view>
		</view>
    </view>
</template>

<script>
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
import payment from '@/components/payment';
export default {
	components: {
		payment
	},
    data() {
        return {
            wxlogin: true,
            goodsList: [],
			imagebaseurl: getApp().globalData.fileDomain,
            buyType: 1,
            remark: '',
            name: '',
            phone: '',
			address:'',
            showModal: false,
			activityDetail: '',
			isPay:false,
			payOrderId:0,
			goodsPrice:0,
			payAmount:0,
			buyNumber:3
        };
    },
    onShow() {
        AUTH.checkHasLogined().then((isLogined) => {
            this.setData({
                wxlogin: isLogined
            });
            if (isLogined) {
                this.doneShow();
            }
        });
    },
    onLoad(e) {
		WXAPI.newsDetail(9).then(res => {
		  if (res.code == 200) {
		    this.activityDetail = res.data.content;
		  }
		});
    },
    methods: {
		closePay: function() {
			this.isPay = false;
		},
		okPay: function() {
			this.isPay = false;
			uni.redirectTo({
				url: "/pages_order/order-list/index"
			});
		},
        async doneShow() {
			var buyNowInfoMem = uni.getStorageSync('buyNowInfo');
			this.goodsList = buyNowInfoMem;
			this.goodsPrice = this.goodsList[0].price.toFixed(2);
			this.payAmount = (this.goodsPrice * this.buyNumber).toFixed(2);
        },
		buyNumberTap: function(type) {
			if (type == 0) {
				if (this.buyNumber > 3) {
					this.buyNumber --;
				} else {
					uni.showToast({icon: 'none',title: '时长最少3小时起'}); 
				}
			} else {
				this.buyNumber ++;
			}
			this.payAmount = (this.goodsPrice * this.buyNumber).toFixed(2);
		},
        createOrder: function (e) {
            var _this = this;
			let postData = this.goodsList[0];
			if (_this.address =='') {
				uni.showToast({icon: 'none',title: '请输入地址'}); 
			    return false;
			} 
			if (_this.name =='') {
				uni.showToast({icon: 'none',title: '请输入姓名'}); 
			    return false;
			} 
			if (_this.phone =='') {
				uni.showToast({icon: 'none',title: '请输入手机号'}); 
			    return false;
			} 
			uni.showLoading();
			postData.address = this.address;
			postData.remark = this.remark;
			postData.name = this.name;
			postData.phone = this.phone;
			postData.type = this.buyType;
			postData.amount = this.payAmount;
            postData.num = this.buyNumber;
            WXAPI.orderCreate(postData).then(function (res) {
				uni.hideLoading();
                if (res.code == 200) {
                    _this.payOrderId = res.data.id;
                    _this.payAmount = res.data.amount;
                    _this.isPay = true;
                } else {
					uni.showModal({
					    title: '错误',
					    content: res.msg,
					    showCancel: false
					});
				}
                
            });
        },
    }
};
</script>
<style>
@import './index.css';
</style>
