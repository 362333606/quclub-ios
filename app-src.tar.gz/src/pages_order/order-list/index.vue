<template>
    <view style="height: 100%">
        <view class="container">
            <view v-if="!hasRefund" class="status-box">
                <view
                    @tap="statusTap"
                    :class="'status-label sub-width ' + (index == currentType ? 'active' : '')"
                    :data-index="index"
                    v-for="(item, index) in statusType"
                    :key="index">
                    {{ item }}
                    <view :class="tabClass[index]"></view>
                </view>
            </view>
            <view class="no-order" v-if="orderList.length == 0">
                <image src="/static/images/no-order.png" class="no-order-img"></image>
                <view class="text">暂无订单</view>
            </view>
            <view class="order-list" v-if="orderList.length > 0">
                <view class="order-item" v-for="(item, index) in orderList" :key="index">
					<navigator :url="currentType == 0 ? '/pages_order/order-details/index?id=' + item.id : '/pages_monad/monad/detail?id='+item.id">
						<view class="goods-content">
							<view class="goods-img">
								<image class="img" mode="aspectFill" :src="imagebaseurl+item.goodsImg"></image>
							</view>
							<view class="goods-info">
								<view>
									<text class="goods-name">{{item.goodsName}}</text>
									<text class="serve-name">{{item.serveName}}</text>
									<image v-if="item.status==1 && item.remark == 'chat'" src="/static/images/nav/im.png" style="width:40rpx;height:40rpx;margin-left: 30rpx;margin-right: 5px;"></image>
									<text v-if="item.status==1 && item.remark == 'chat'" style="color: #999;vertical-align: middle;">立即沟通</text>
								</view>
								<view class="goods-time">
								<image src="/static/images/order/order_time.png"></image>
								{{item.date}} {{item.time}}</view>
								<view class="goods-address">
									<image src="/static/images/order/order_address.png"></image>
									{{item.address}}</view>
							</view>
						</view>
					</navigator>
					<view class="order-bottom">
						<view class="order-add-time">发送约玩：{{ formatDate(item.createDate) }}</view>
						<view class="price-box">
						    <text class="btn" v-if="item.status==0"  @click="cancelOrderTap(item)" >取消订单</text>
						    <text class="btn" v-if="item.status==0"  @click="toPayTap(item)">待支付</text>
							<!-- <text class="btn okpay" v-if="item.status==1 && item.remark == 'chat'">立即沟通</text> -->
							<text class="btn okpay" v-if="item.status==1">已支付</text>
							<text v-if="item.status==-1">已取消</text>
						</view>
					</view>
					
                </view>
            </view>
            <view class="safeAreaOldMarginBttom safeAreaNewMarginBttom"></view>
        </view>
		
		<view class="show-popup" v-if="isPay">
			<view class="popup-mask" @click="closePay"></view>
			<view class="popup-contents">
				<payment @toCancel="closePay" @okPay="okPay" :payTypeId="1" :payOrderId="payOrderId" :payAmount="payAmount"></payment>
			</view>
		</view>
    </view>
</template>

<script>
const wxpay = require('../../utils/pay.js');
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
import payment from '@/components/payment';
export default {
	components: {
		payment
	},
    data() {
        return {
            statusType: ['下单记录', '接单记录'],
			imagebaseurl: getApp().globalData.fileDomain,
            hasRefund: false,
            currentType: 0,
            tabClass: ['', '', '', '', ''],
            wxlogin: true,
            orderList: [],
			curPage: 1,
			pageSize: 10,
			totalPages:0,
			isPay:false,
			payOrderId:0,
			payAmount:0
        };
    },
    onLoad: function (options) {
        if (options && options.type) {
            if (options.type == 99) {
                this.setData({
                    hasRefund: true,
                    currentType: options.type
                });
            } else {
                this.setData({
                    hasRefund: false,
                    currentType: options.type
                });
            }
        }
		this.onShowClone();
    },
    onReady: function () {
        // 生命周期函数--监听页面初次渲染完成
    },
    onShow: function () {
        
    },
    onHide: function () {
        // 生命周期函数--监听页面隐藏
    },
    onUnload: function () {
        // 生命周期函数--监听页面卸载
    },
    onPullDownRefresh: function () {
        // 页面相关事件处理函数--监听用户下拉动作
    },
    onReachBottom: function () {
        // 滚动刷新
        if (this.curPage == this.totalPages) {
        	return;
        }
        this.setData({
            curPage: this.curPage + 1
        });
        this.doneShow();
    },
    methods: {
		closePay: function() {
			this.isPay = false;
		},
		okPay: function() {
			this.isPay = false;
			this.initPage();
		},
		
		initPage: function() {
			this.curPage = 1;
			this.orderList = [];
			this.doneShow();
		},
		initDemandPage: function() {
			this.curPage = 1;
			this.orderList = [];
			this.doneDemandShow();
		},
		formatDate: function(date){
			let newDate = new Date(date);
			let year = newDate.getFullYear();
			let month = (newDate.getMonth()+1).toString().padStart(2,0);
			let day = newDate.getUTCDate().toString().padStart(2,0);
			return year + '.' + month + '.' + day;
		},
        onShowClone: function () {
			 
            AUTH.checkHasLogined().then((isLogined) => {
                this.setData({
                    wxlogin: isLogined
                });
                if (isLogined) {
                    this.doneShow();
                }
            });
        },

        statusTap: function (e) {
            const curType = e.currentTarget.dataset.index;
            this.currentType = curType;
          
			if (this.currentType == 0) {
				this.initPage();
			} else {
				this.initDemandPage();
			}
        },

        cancelOrderTap: function (item) {
            const that = this;
            const orderId = item.id;
            uni.showModal({
                title: '确定要取消该订单吗？',
                content: '',
                success: function (res) {
                    if (res.confirm) {
						uni.showLoading();
                        WXAPI.orderClose({orderId: orderId}).then(function (res) {
							uni.hideLoading();
                            if (res.code == 200) {
								uni.showToast({title: '取消成功'});
								setTimeout(() => {
								   that.doneShow();
								}, 1500);
                            } else {
								uni.showToast({
									 icon: 'none',
									 title: res.msg
								}); 
							}
                        });
                    }
                }
            });
        },



        toPayTap: function (item) {
			
			this.payOrderId = item.id;
			this.payAmount = item.amount;
			this.isPay = true;
        },

        toPayTapFun: function (orderId, money) {
            const that = this;
            if (money <= 0) {
                // 直接使用余额支付
                WXAPI.orderPay(uni.getStorageSync('bestpw-Token'), orderId).then(function (res) {
                    that.onShowClone({});
                });
            } else {
                wxpay.wxpay('order', money, orderId, '/pages/order-list/index');
            }
        },

        doneShow: function () {
            // 获取订单列表
            let that = this;
    
			uni.showLoading({
			    title: '加载中'
			});
            WXAPI.orderList({
				pageSize: this.pageSize,
				page: this.curPage
			}).then(function (res) {
                if (res.code == 200) {
					var newArray = res.data.content;
					that.orderList = [...that.orderList,...newArray];
					that.totalPages = res.data.totalPages;
                } else {
                    that.setData({
                        orderList: null,
                    });
                }
				uni.hideLoading();
            });
        },
		
		doneDemandShow: function () {
		    // 获取订单列表
		    let that = this;
		    
			uni.showLoading({
			    title: '加载中'
			});
		    WXAPI.orderDemandList({
				pageSize: this.pageSize,
				page: this.curPage
			}).then(function (res) {
		        if (res.code == 200) {
					var newArray = res.data.content;
					let array = [];
					res.data.content.forEach((item,index)=>{
						array.push({
							"id": item.demandId,
							"goodsName": item.demand.projectName,
							"goodsImg": item.demand.img,
							"createDate": item.createDate,
							"address": item.demand.address,
							"serveName": item.demand.projectName,
							"date": item.demand.date,
							"time": item.demand.time
						})
					});
					that.orderList = [...that.orderList,...array];
					that.totalPages = res.data.totalPages;
		        } else {
		            that.setData({
		                orderList: null,
		            });
		        }
				uni.hideLoading();
		    });
		}
    }
};
</script>
<style>
@import './index.css';
</style>
