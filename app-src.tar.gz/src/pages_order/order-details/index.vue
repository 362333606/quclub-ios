<template>
    <view style="height: 100%">
        <view class="container">
            <view class="sec-wrap">
                <view class="order-status">
                    <view class="icon-box">
                        <image v-if="orderDetail.status == -1" class="icon" src="/static/images/order-details/icon-ddgb.png"></image>
                        <image v-else-if="orderDetail.status == 0" class="icon" src="/static/images/order-details/icon-ddfk.png"></image>
                        <image
                            v-else-if="orderDetail.status == 1"
                            class="icon"
                            src="/static/images/order-details/icon-jycg.png"
                        ></image>
                    </view>
                    <view class="right-text">
                        <view class="status red">
							<text v-if="orderDetail.status == -1">已取消</text>
							<text v-if="orderDetail.status == 0">待支付</text>
							<text v-if="orderDetail.status == 1">已支付</text>
						</view>
                        <view class="des" v-if="false">请于11时59分59秒内付款，超时订单将自动关闭</view>
                    </view>
                </view>

            </view>
            <view class="goods-list">
                <view class="list-title">预约信息</view>
               <view class="a-goods" @tap="toDetail">
					<view class="img-box">
						<image :src="imagebaseurl+ orderDetail.goodsImg" class="img" />
					</view>
					<view class="text-box">
						<view class="arow arow01">
							<view class="goods-name">{{ orderDetail.goodsName }}</view>
							<view class="goods-price">¥ {{orderDetail.price}}</view>
						</view>
						<view class="arow">
							<view class="goods-label">{{orderDetail.serveName}}</view>
							<view class="goods-num">x {{orderDetail.num}}</view>
						</view>
					</view>
				</view>
            </view>
            <view class="goods-info">
                <view class="row-box">
                    <view class="row-label">订单金额</view>
                    <view class="right-text">¥ {{ orderDetail.amount }}</view>
                </view>
				<view class="row-box">
				    <view class="row-label">约玩地址</view>
				    <view class="right-text"> {{ orderDetail.address }}</view>
				</view>
				<view class="row-box">
				    <view class="row-label">约玩时间</view>
				    <view class="right-text">{{orderDetail.date}} {{orderDetail.time}}</view>
				</view>
            </view>
			<view style="text-align: center;padding-bottom: 60rpx;" v-if="isLockIM > 0">
				<text v-if="lockIMHour == 9999">已解锁永久聊天</text>
				<text v-else>还剩 <text style="font-weight: bolder;margin-left: 6rpx;">{{lockIMHour}}</text>小时聊天时间</text>
				<text class="chat-btn" @click="toChat">立即沟通</text>
			</view>
        </view>
    </view>
</template>

<script>
const app = getApp();
const CONFIG = require('../../config.js');
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
	import { TUILogin } from '@tencentcloud/tui-core';
	// #ifdef APP-PLUS || H5
	import { TUIChatKit } from '../../TUIKit';
	TUIChatKit.init();
	// #endif
export default {
    data() {
        return {
            orderId: 0,
            goodsList: [],
            appid: '',
			imagebaseurl: getApp().globalData.fileDomain,
            orderDetail: {
                orderInfo: {
                    status: '',
                    statusStr: '',
                    orderNumber: '',
                    amount: '',
                    amountReal: ''
                },
                goods: []
            },
			isLockIM: 0,
			lockIMHour: 0
        };
    },
    onLoad: function (e) {
        var orderId = e.id;
        this.orderId = orderId;
        this.setData({
            orderId: orderId,
            appid: uni.getStorageSync('wxAppid')
        });
    },
    onShow: function () {
        this.onShowClone();
		
    },
    methods: {
		toChat() {
			let _this = this;
			uni.showLoading();
			WXAPI.roomIM(_this.orderDetail .goodsId).then((res) => {
				
			    if (res.code == 200) {
					uni.hideLoading();
					uni.navigateTo({ url: '/pages/chat/webview?bestId=' + _this.orderDetail.goodsId });
					
				
			    } else {
					uni.hideLoading();
					uni.showToast({
						 icon: 'none',
						 title: res.msg
					}); 
				}
			});
		},
		toDetail: function() {
			uni.navigateTo({
			    url: '/pages_details/goods-details/index?id='+ this.orderDetail.goodsId
			});
		},
        onShowClone: function () {
			uni.showLoading({
			    title: '加载中'
			});
            var that = this;
            WXAPI.orderDetail(that.orderId).then(function (res) {
                if (res.code == 200) {
					that.orderDetail = res.data
					uni.hideLoading();
					
					WXAPI.unLockIM(that.orderDetail.goodsId).then(res => {
						that.isLockIM = res.data.isLock;
						if (res.data.isLock == 1) {
							that.lockIMHour = res.data.hour;
						}
					})
                }
            });
        },
    }
};
</script>
<style>
@import './index.css';
</style>
