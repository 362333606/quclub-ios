const configureWebpack = {};
export { configureWebpack };
