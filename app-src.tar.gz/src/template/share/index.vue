<template>
    <view style="height: 100%">
        <template name="apifmShare">
            <view class="apifmShare">
                <view class="share">
                    <image src="/static/images/share/share1.png"></image>
                    <button open-type="share"></button>
                </view>
                <view class="share">
                    <image src="/static/images/share/share2.png"></image>
                    <button @tap="createPosterFun" :data-d="goodsDetail"></button>
                </view>
            </view>
        </template>
    </view>
</template>

<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
let goodsDetail;
var ctx;
const clientWidth = uni.getSystemInfoSync().screenWidth;
function px(number) {
    return (number * clientWidth) / 750;
}
export default {
    data() {
        return {
            posterShow: false,
            goodsDetail: ''
        };
    },
    init(page) {
        page._createPoster = this.createPosterFun;
        page._drawQrcode = this._drawQrcode;
        page._saveToMobile = this._saveToMobile;
    },
    _createPoster(e) {
        ctx = uni.createCanvasContext('firstCanvas');
        uni.showLoading({
            title: '正在生成海报'
        });
        ctx.setFillStyle('#fff');
        ctx.fillRect(0, 0, px(600), px(1000));
        this._drawQrcode();
    },
    async _drawQrcode() {
        const _this = this;
        const qrcodeRes = await WXAPI.wxaQrcode({
            scene: _this.goodsDetail.basicInfo.id + ',' + uni.getStorageSync('uid'),
            page: 'pages/goods-details/index',
            is_hyaline: false,
            expireHours: 1
        });
        if (qrcodeRes.code != 0) {
            uni.showModal({
                title: '错误',
                content: '无法获取小程序码',
                showCancel: false
            });
            return;
        }
        let x = 0;
        let y = 0;
        uni.getImageInfo({
            src: _this.goodsDetail.basicInfo.pic,
            success(res) {
                ctx.drawImage(res.path, 0, 0, res.width, res.height, x + px(50), y, px(500), px(500));
                y += px(500);
                x = px(300);
                y = y + 20;
                ctx.setFontSize(16);
                ctx.setFillStyle('#333333');
                ctx.setTextAlign('center');
                let name = _this.goodsDetail.basicInfo.name;
                ctx.fillText(name, x, y);
                x = px(300);
                y = y + 30;
                ctx.setFontSize(18);
                ctx.setFillStyle('#e64340');
                ctx.setTextAlign('center');
                name = _this.goodsDetail.basicInfo.minPrice;
                ctx.fillText('￥' + name, x, y);
                y = y - 20;

                // 写入二维码
                uni.getImageInfo({
                    src: qrcodeRes.data,
                    success(qrRes) {
                        x = px(150);
                        y = y + 30;
                        ctx.drawImage(qrRes.path, 0, 0, qrRes.width, qrRes.height, x, y, px(300), px(300));
                        x = px(300);
                        y = y + px(300) + 20;
                        ctx.setFontSize(12);
                        ctx.setFillStyle('#aaa');
                        ctx.setTextAlign('center');
                        ctx.fillText('长按识别小程序码查看详情', x, y);
                        ctx.draw();
                        uni.hideLoading();
                        _this.setData({
                            posterShow: true
                        });
                    }
                });
            }
        });
    },
    _saveToMobile() {
        const _this = this;
        uni.canvasToTempFilePath({
            canvasId: 'firstCanvas',
            success: function (res) {
                let tempFilePath = res.tempFilePath;
                uni.saveImageToPhotosAlbum({
                    filePath: tempFilePath,
                    success: (res) => {
                        uni.showModal({
                            content: '图片已保存到手机相册',
                            showCancel: false,
                            confirmText: '知道了',
                            confirmColor: '#333'
                        });
                    },
                    complete: () => {
                        _this.setData({
                            posterShow: false
                        });
                    },
                    fail: (res) => {
                        uni.showToast({
                            title: res.errMsg,
                            icon: 'none',
                            duration: 2000
                        });
                    }
                });
            }
        });
    }
};
</script>
<style>
@import './index.css';
</style>
