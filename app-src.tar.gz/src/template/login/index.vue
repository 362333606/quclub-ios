<template>
    <view style="height: 100%">
        <!-- template对应的原始代码，为保证正常显示，已对其进行隐藏。 -->
        <template name="apifmLogin" v-if="false">
            <view class="apifmLogin" v-if="!wxlogin">
                <view class="s-b">
                    <view class="s-l-b">
                        <image src="/static/images/nologin.png" />
                        <text>授权登录</text>
                    </view>
                    <view class="s-t-b">
                        <view class="s-t-i">
                            <text>·</text>
                            请授权小程序登录
                        </view>
                        <view class="s-t-i">
                            <text>·</text>
                            我们不会公布您的这些信息
                        </view>
                        <view class="s-t-i">
                            <text>·</text>
                            只是为了给您提供更好的服务
                        </view>
                    </view>
                    <button class="l" open-type="getUserInfo" @getuserinfo="processLogin">允许</button>
                    <button class="c" @tap="cancelLogin" type="default">暂不登录</button>
                </view>
            </view>
        </template>
    </view>
</template>

<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
export default {
    data() {
        return {
            wxlogin: ''
        };
    },
    init(page) {
        // page._cancelLogin = this._cancelLogin;
        // page._processLogin = this._processLogin;
    }
};
</script>
<style>
@import './index.css';
</style>
