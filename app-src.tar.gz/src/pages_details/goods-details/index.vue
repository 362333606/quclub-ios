<template>
	<view class="container">
		<view :style="{ 'padding-top' : statusBarHeight +'px',  }"></view>
		<view class="best-detail-head">
			<view class="title-return" @click="returns()">
				<image src="/static/images/back.png"></image>
			</view>
			<view class="best-item-head" v-if="goodsDetail.pic">
				 <image class="img" mode="aspectFill" :lazy-load="true" :src="imagebaseurl + goodsDetail.pic+'?x-oss-process=image/resize,m_fill,h_60,w_60'"></image>
			</view>
			<view class="best-item-content">
				<text class="best-item-name">{{goodsDetail.name}}</text>
				<text class="best-item-sex" :class="goodsDetail.sex == 1 ? 'man':'woman'">
					<image v-if="goodsDetail.sex == 2" mode="aspectFill" class="sex" src="/static/images/nav/woman.png"></image>
					<image v-if="goodsDetail.sex == 1" mode="aspectFill" class="sex" src="/static/images/nav/man.png"></image>
					<text>{{goodsDetail.age}}</text>
				</text>
				<text class="best-item-sex" :class="goodsDetail.sex == 1 ? 'man':'woman'" v-if="goodsDetail.auths && goodsDetail.auths.includes('颜值认证')">
					<image mode="aspectFill" class="sex" src="/static/images/nav/yz_auth.png"></image>
					<text style="margin-left: 6rpx;">颜值认证</text>
				</text>
			</view>
			<view class="share-item" @tap="showGift(5)">
				<image src="/static/images/icon/gift.png"></image>
				<text>打赏</text>
			</view>
		</view>
		<view class="best_detail" :style="{ 'padding-top' : statusBarHeight == 0 ? 40 : statusBarHeight +'px',  }">
			<view class="swiper-container">
				<swiper :class="'screen-swiper '+(dotStyle?'square-dot':'round-dot')" :circular="true" @change="swiperChange"
					:autoplay="false" interval="1000" duration="500">
					<swiper-item v-for="(item,index) in (goodsDetail.imgs)" :key="index" @click="preview(imagebaseurl+item)">
						<image :src="imagebaseurl+item" class="slide-image" mode="aspectFill" :lazy-load="true" v-if="!item.includes('video')" />
						<video :src="imagebaseurl + item" class="slide-image" mode="aspectFill" :lazy-load="true" v-if="item.includes('video')" :enable-progress-gesture="false" :poster="imagebaseurl + item + '?x-oss-process=video/snapshot,t_0,f_jpg'" />
					</swiper-item>
				</swiper>
				<view class="follow-btn" @tap="addToFav">
					<image src="/static/images/nav/best_follow.png"></image>
					<text v-if="favicon == 0">关注</text>
					<text v-if="favicon == 1">取消关注</text>
				</view>
				<!-- <view @click="tobuy" class="in-order">立即预约</view> -->
				<view class="ip-address">IP属地：{{goodsDetail.city}}</view>
				<view class="img-count">{{swiperIndex}}/{{imgCount}}</view>
			</view>
			<view>
				<q-previewImage ref="previewImage" :urls="goodsDetail.imgs"></q-previewImage>
			</view>
			
		</view>
		
		<view class="goods-info">
			<view>
				<image class="best-icon" src="/static/images/nav/best_info.png"></image>
				<span class="goods-title">TA的资料</span>
				<text class="best-item-sex" :class="goodsDetail.sex == 1 ? 'man':'woman'" v-if="goodsDetail.auths && goodsDetail.auths.includes('真人认证')">
					<text style="margin-left: 6rpx;">真人认证</text>
				</text>
				<!-- <image class="serve-icon" src="/static/images/nav/serve.png" onclick="window.location.href='https://work.weixin.qq.com/kfid/kfcb1cc156237257592'"></image> -->
				<image class="serve-icon" src="/static/images/nav/im.png" @click="showGift(7)"></image>
				<view class="js-wx" @tap="showlockWechat">
					<image mode="aspectFill" class="weixin-icon" src="/static/images/icon/weixin.png"></image>
					<text>解锁微信</text>
				</view>
			</view>
			<view class="best_tag" style="white-space:nowrap;">
				<image class="best-icon" src="/static/images/nav/best_info_n.png"></image>
				<span class="best-tag-item">身高：{{goodsDetail.height}} cm</span>
				<span class="best-tag-item" style="margin-right: 0px;">体重：{{goodsDetail.weight}} kg</span>
			</view>
			<view class="info-desc" v-if="goodsDetail.remark">
				<image class="best-icon" src="/static/images/nav/best_desc.png"></image>
				<text>{{goodsDetail.remark}}</text>
			</view>
			<view class="best-item-tag">
				<image class="best-icon" src="/static/images/nav/best_tags.png"></image>
				<text v-for="(tag,index) in (goodsDetail.tags || '').split(',')">{{tag}}</text>
			</view>
			
			<view class="goods-imgs">
				<view v-for="(img,index) in (goodsDetail.imgs)" @click="preview(imagebaseurl+img)">
					<video id="myVideo" :src="imagebaseurl + img" class="slide-image" mode="aspectFill" 
					:lazy-load="true" v-if="img.includes('video')" :enable-progress-gesture="false" 
					:controls="false" @play="pay" :poster="imagebaseurl + img + '?x-oss-process=video/snapshot,t_0,f_jpg'" />
					<image :src="imagebaseurl + img" class="slide-image"  mode="aspectFill" :lazy-load="true" v-else />
				</view>
			</view>
		</view>
		
		<view>
			<uni-collapse>
				<uni-list-item title="动态空间" thumbSize="sm" clickable showArrow @click="onPlaza(goodsDetail.id)" thumb="/static/images/menu/gc1.png"></uni-list-item>
				<uni-collapse-item title="约玩项目" :open="true" thumb="/static/images/nav/project.png">
					<view class="collapse-content">
						<project_list 
							@toConfirm="serveConfirm"
							:goodsId.sync="formData.goodsId"
							:showCancel="false" 
							:showConfirm="false" />
					</view>
				</uni-collapse-item>
				<uni-collapse-item title="选择约玩时间" :open="true" thumb="/static/images/nav/time.png">
					<view class="collapse-content">
						<time_list :showCancel="false" :showConfirm="false" :date.sync="formData.date" :time.sync="formData.time"></time_list>
					</view>
				</uni-collapse-item>
			</uni-collapse>
		</view>
		
		<view class="submit-order">
			<view class="submit-order-text">
				<view class="submit-order-price">
					<text>¥</text>
					<text class="submit-order-amount">{{formData.price}}</text>
					<text>元</text>
				</view>
				<view class="submit-tip-text">注:预约后30分钟内无人接单可退款</view>
			</view>
			<view class="submit-order-btn" @tap="buyNow">提交订单</view>
		</view>
		
		<view class="show-popup" v-if="showUnlockWechat">
			<view class="popup-mask" @click="closeUnlockWechat"></view>
			<view class="popup-contents">
				<view class="js-wechat-card" v-if="!isUnlockWechat">
					<view class="js-wechat-card-content">
						<view class="js-wechat-card-item">
							<view style="font-size: 46rpx;font-weight: bolder;color: #317d1d;">会员VIP</view>
							<view style="margin-top: 20rpx;color: #317d1d;">尊享超级特权</view>
						</view>
						<view class="js-wechat-card-item js-wechat-vip">VIP</view>
					</view>
				</view>
				<view v-if="isUnlockWechat" style="text-align: center;margin: 50rpx;">
					<image mode="aspectFill" class="weixin-unlock-icon" src="/static/images/icon/wechat3.jpg"></image>
				</view>
				<view class="js-wechat-title" v-if="!isUnlockWechat">VIP权限-解锁微信账号</view>
				<view class="js-wechat-title" v-if="isUnlockWechat">已解锁TA的微信号</view>
				<view v-if="isUnlockWechat" style="text-align: center;margin-top: 10rpx;">添加微信好友时请备注“趣club”</view>
				<view class="js-wechat" v-if="!isUnlockWechat">
					<view class="js-wechat-text">
						<view class="js-wechat-price">
							<text>¥</text>
							<text class="js-wechat-amount">{{payAmount}}</text>
							<text>元</text>
						</view>
						<text class="js-wechat-text">解锁此微信账号</text>
					</view>
					<view class="js-wechat-btn" @tap="unlockWechat">
						<image mode="aspectFill" class="weixin-icon" src="/static/images/icon/weixin.png"></image>
						解锁微信
					</view>
				</view>
				<view class="js-lock-wechat" v-if="isUnlockWechat">
					<view class="js-lock-wechat-content">
						<view><image mode="aspectFill" class="weixin-icon" src="/static/images/nav/wechat1.png"></image></view>
						<view class="wechat-info">{{bestWechat}}</view>
						<view class="copy-btn" @tap="copyWechat">复制</view>
					</view>
					<view style="text-align: center;margin-top: 20rpx;">解锁有效期{{bestWechatDays}}天</view>
				</view>
			</view>
		</view>
		
		<view class="show-popup" v-if="isPay">
			<view class="popup-mask" @click="closePay"></view>
			<view class="popup-contents">
				<payment @toCancel="closePay" @okPay="okPay" :markIndex="markIndex" :payTypeId="payTypeId" :payOrderId="payOrderId" :payAmount="payAmount"></payment>
			</view>
		</view>
		<!-- v-if="isGift" -->
		<view class="show-popup" v-if="isGift" style="z-index: 99;">
			<view class="popup-mask" @click="closeGift"></view>
			<view class="popup-contents">
				<view class="gift-content">
					<view class="gift-title">
						<text class="gift-title-t">礼物</text>
						<text class="gift-title-d">赠一个礼物吧 让关系更加亲密～</text>
					</view>
					<view class="gift-list">
						<view class="gift-item" @tap="selectGift(index)" :class="giftIndex === index ? 'gift-active' : ''" v-for="(item, index) in giftList">
							 <view class="gift-item-img" :style="giftIndex === index ? 'padding:10rpx' : ''">
								 <image :src="imagebaseurl + item.logo" :style="giftIndex === index ? 'width: 120rpx;height: 120rpx;' : 'width: 100rpx;height: 100rpx;'" />
							 </view>
							 <view v-if="giftIndex !== index" class="gift-item-title">{{item.title}}</view>
							 <view class="gift-item-price">{{item.price}}钻</view>
							 <view class="give-gift" v-if="giftIndex === index" @tap="giveGift(5)">赠送</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		
		<!-- v-if="isChat" -->
		<view class="show-popup" v-if="isChat" style="z-index: 99;">
			<view class="popup-mask" @click="closeChat"></view>
			<view class="popup-contents">
				<view class="gift-content">
					<view class="gift-title">
						<text class="gift-title-t">解锁聊天</text>
						<text class="gift-title-d"> 让关系更进一步～</text>
					</view>
					<view class="gift-list">
						<view class="gift-item" @tap="selectGift(index)" :class="giftIndex === index ? 'gift-active' : ''" v-for="(item, index) in giftList">
							 <view class="gift-item-img" :style="giftIndex === index ? 'padding:10rpx' : ''">
								 <image :src="imagebaseurl + item.logo" :style="giftIndex === index ? 'width: 120rpx;height: 120rpx;' : 'width: 100rpx;height: 100rpx;'" />
							 </view>
							 <view v-if="giftIndex !== index" class="gift-item-title">{{item.title}}</view>
							 <view class="gift-item-price">{{item.price}}钻</view>
							 <view class="give-gift" v-if="giftIndex === index" @tap="giveGift(7)">确认解锁</view>
						</view>
						
					</view>
					<view style="text-align: center;padding-bottom: 20rpx;" v-if="isLockIM > 0">
						<text v-if="lockIMHour == 9999">已解锁永久聊天</text>
						<text v-else>还剩 <text style="font-weight: bolder;margin-left: 6rpx;">{{lockIMHour}}</text>小时聊天时间</text>
						<text class="chat-btn" @click="toChat">继续聊天</text>
					</view>
				</view>
			</view>
		</view>
		
	
		<!-- <share :goods-info="goodsDetail"></share> -->
	</view>
</template>

<script>
	import project_list from '@/components/project_list.vue';
	import time_list from '@/components/time_list.vue';
	import payment from '@/components/payment';
	// import share from "@/components/share/index";
	const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
	const app = getApp();
	// import ApifmShare from '../../template/share/index.js';
	const CONFIG = require('../../config.js');
	const AUTH = require('../../utils/auth');


	// v2.1.4: TUI SDK在APP模块级init会炸(vm创建失败=n.$vm._$vd白屏);聊天走webview,仅H5保留
	// #ifdef H5
	import { TUILogin } from '@tencentcloud/tui-core';
	import { TUIChatKit } from '../../TUIKit';
	TUIChatKit.init();
	// #endif
	export default {
		components: {
			// share,
			project_list,
			time_list,
			payment
			// titles
		},
		data() {
			return {
				statusBarHeight: (typeof getApp().globalData.statusBarHeight === "number") ? getApp().globalData.statusBarHeight : 0,
				imagebaseurl: getApp().globalData.fileDomain,
				wxlogin: true,
				showUnlockWechat: false,
				isUnlockWechat: false,
				bestWechat:'',
				bestWechatDays:0,
				swiperIndex:1,
				goodsDetail: [],
				sid: '',
				showShare: true,
				favicon: 0,
				dotStyle: "square-dot",
				imgCount: 0,
				videoContext:'',
				formData:{
					attrId:0,
					goodsId:0,
					serveId:0,
					serveName:'',
					date:'',
					time:'',
					price:0,
					goodsName:'',
					goodsImg:'',
				},
				isPay:false,
				isGift:false,
				isChat:false,
				payOrderId:0,
				payAmount:0,
				giftList:[],
				giftIndex:'',
				payTypeId:0,
				markIndex:0,
				isLockIM: 0,
				lockIMHour: 0
			}
		},
		async onLoad(e) {
			this.formData.goodsId = e.id;
			const that = this;
			this.videoContext = uni.createVideoContext('myVideo');
			this.getNotice();
		},
		
		onShow() {
			
			this.getGoodsDetailInfo(this.formData.goodsId);
			AUTH.checkHasLogined().then(isLogined => {
				//AUTH.checkHasLogined(isLogined => {
				this.setData({
					wxlogin: isLogined
				});
				if (isLogined) {
					this.afterAuth();
					
				}
			});
			
			
		},
		onShareAppMessage: function() {
			let _data = {
				title: this.goodsDetail.name,
				path: '/pages_details/goods-details/index?id=' + this.goodsDetail.id + '&inviter_id=' + uni.getStorageSync(
					'uid'),
				imageUrl: 'https://www.bestpw.cn/logo.jpg',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}
			};
	
			return _data;
		},
		methods: {
			
			selectGift(index) {
				this.giftIndex = index;
			},
			showGift(index) {
				let _this = this;
				if (!_this.wxlogin) {
					uni.showToast({
					    title: '请登录后再操作',
					    icon: 'none'
					});
					return false;
				}
				this.giftIndex = '';
				if (index == 5) {
					this.isGift = true;
					WXAPI.giftList().then(res => {
						_this.giftList = res.data;
					});
				} else {
					this.isChat = true;
					WXAPI.timePackageIM().then(res => {
						_this.giftList = res.data;
					});
					WXAPI.unLockIM(_this.goodsDetail.id).then(res => {
						_this.isLockIM = res.data.isLock;
						if (res.data.isLock == 1) {
							_this.lockIMHour = res.data.hour;
						}
					})
				}
				
			},
			closeGift() {
				this.isGift = false;
			},
			closeChat() {
				this.isChat = false;
			},
			giveGift(index) {
				let _this = this;
				if (!_this.wxlogin) {
					uni.showToast({
					    title: '请登录后再操作',
					    icon: 'none'
					});
					return false;
				}
				this.payTypeId = index;
				this.payAmount = this.giftList[this.giftIndex].price;
				this.payOrderId = this.giftList[this.giftIndex].id;
				this.markIndex = this.goodsDetail.id;
				this.isPay = true;
			},
			copyWechat() {
				let _this = this;
				uni.setClipboardData({
				  data: _this.bestWechat,
				  success: function() {
				    console.log('复制成功');
				  }
				})
			},
			toChat() {
				let _this = this;
				if (!_this.wxlogin) {
					uni.showToast({
					    title: '请登录后再操作',
					    icon: 'none'
					});
					return false;
				}
				uni.showLoading();
				WXAPI.roomIM(_this.formData.goodsId).then((res) => {
					
				    if (res.code == 200) {
						uni.hideLoading();
						uni.navigateTo({ url: '/pages/chat/webview?bestId=' + _this.formData.goodsId });
						
					
				    } else {
						uni.hideLoading();
						uni.showToast({
							 icon: 'none',
							 title: res.msg
						}); 
					}
				});
			},
			showlockWechat() {
				let _this = this;
				if (!_this.wxlogin) {
					uni.showToast({
					    title: '请登录后再操作',
					    icon: 'none'
					});
					return false;
				}
				WXAPI.bestIsOrder(_this.formData.goodsId).then(res => {
					if (res.data == 0) {
						uni.showToast({
						    title: '请下单预约后才可解锁',
						    icon: 'none'
						});
						return false;
					} else {
						WXAPI.bestLockWechat(_this.goodsDetail.id).then(res => {
							_this.showUnlockWechat = true;
							if (res.data.isLock == 1) {
								_this.isUnlockWechat = true;
								_this.bestWechat = res.data.wechat;
								_this.bestWechatDays = 3 - res.data.days;
							} else {
								_this.payTypeId = 4;
								_this.payAmount = res.data.amount;
							}
						})
					}
				})
			},
			closeUnlockWechat() {
				this.showUnlockWechat = false;
			},
			unlockWechat() {
				this.payOrderId = this.goodsDetail.id;
				this.isPay = true;
				// this.isUnlockWechat = true;
			},
			closePay: function() {
				this.isPay = false;
			},
			okPay: function() {
				this.isPay = false;
				this.isUnlockWechat = true;
				this.bestWechat = "获取中...";
				this.bestWechatDays = 3;
				this.showlockWechat();
			},
			getNotice() {
				WXAPI.newsNotice(1).then(res => {
				  if (res.code == 200 && res.data.popStatus == 1) {
					uni.showModal({
						title: '官方提醒',
						content: res.data.content,
						showCancel: false,
						confirmText: '我已知晓',
						success: function (res) {
							if (res.confirm) {
								console.log('用户点击确定');
							}
						}
					});
				  }
				});
			},
			pay() {
				this.videoContext.pause();;
			},
			share() {
			  uni.share({
			    provider: 'weixin',
			    type: 0,
			    title: '测试',
			    imageUrl: 'https://www.bestpw.cn/logo.jpg',
			    path: '/pages_details/goods-details/index?id=1',
			    success: () => {
			      uni.showToast({
			        title: '分享成功',
			        icon: 'none'
			      });
			    },
			    fail: () => {
			      uni.showToast({
			        title: '分享失败',
			        icon: 'none'
			      });
			    }
			  });
			},
			val(id,name){
				console.info(id + "_" + name);
			},
			serveConfirm(item) {
				this.formData.attrId = item.attrId;
				this.formData.serveId = item.id;
				this.formData.serveName = item.title;
				this.formData.price = item.price;
			},
			// 返回的箭头
			returns(){
				// 获取有无上一页
				let pages = getCurrentPages();//当前页
				if(pages.length == 1){
					uni.switchTab({
						url:'/pages/index/index' //返回首页
					})
				}else{
					uni.navigateBack({
						delta: 1  //返回上一页
					});
				}
			},
			onPlaza(id){
				uni.navigateTo({
					url: '/pages_details/plaza-list/index?id='+ id
				});
			},
			swiperChange(e) {
			
				const that = this;
				
				that.setData({
				
				swiperIndex: e.detail.current,
				
				})
			},
			preview(url) {
				console.info(url);
			    this.$refs.previewImage.open(url); // 传入当前选中的图片地址
			},
			
			afterAuth() {
				this.getFav(this.formData.goodsId);
			},

			async getGoodsDetailInfo(goodsId) {
				uni.showLoading();
				const that = this;
				const goodsDetailRes = await WXAPI.goodsDetail(goodsId);
				if (goodsDetailRes.code == 200) {
					uni.hideLoading();
					that.goodsDetail = goodsDetailRes.data;
					let _data = {
						goodsDetail: that.goodsDetail,
						imgCount: goodsDetailRes.data.imgs.length
					};
					that.setData(_data);
				}
			},
			/**
				* 立即购买
				*/
			buyNow: function(e) {
				if (!this.wxlogin) {
					uni.showToast({
					    title: '请登录后再操作',
					    icon: 'none'
					});
					return false;
				}
				let that = this;
				if (this.formData.serveId == 0) {
					uni.showToast({icon: 'none',title: '请选择约玩项目'});
					return false;
				}
				if (this.formData.date == '') {
					uni.showToast({icon: 'none',title: '请选择日期'});
					return false;
				}
				if (this.formData.time == '') {
					uni.showToast({icon: 'none',title: '请选择时间'});
					return false;
				}
				this.formData.goodsName = this.goodsDetail.name;
				this.formData.goodsImg = this.goodsDetail.pic;
				
				console.info(this.formData);
				// 写入本地存储
				let info = [];
				info[0] = this.formData;
				
				console.info(info);
				uni.setStorage({
					key: 'buyNowInfo',
					data: info,
				});
				uni.navigateTo({
					url: '/pages_order/pay-order/index'
				});
			},

			goIndex() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},

			getFav(goodsId) {
				console.log('-----Fav Check----------------------');
				WXAPI.goodsFavCheck(goodsId).then(res => {
					if (res.code == 200) {
						this.setData({
							favicon: res.data
						});
					}
				});
			},
			goCustomer(){
			   
			},

			addToFav: function() {
				
				if (!this.wxlogin) {
					uni.showToast({
					    title: '请登录后再操作',
					    icon: 'none'
					});
					return false;
				}
				if (this.wxlogin) {
					WXAPI.goodsFollow({'bestId': this.goodsDetail.id}).then(res => {
						if (res.code == 200) {
							if (res.data == 1) {
								uni.showToast({
									title: '关注成功',
									icon: 'success',
									image: "/static/images/active.png",
									duration: 2000
								});
							} else {
								uni.showToast({
									 icon: 'none',
									 title: '已取消'
								}); 
							}
							
							this.setData({
								favicon: res.data
							});
						}
					});
				}
			},

		}
	};
</script>
<style>
	@import "./index.css";
</style>