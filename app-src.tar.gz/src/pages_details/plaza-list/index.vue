<template>
    <view class="goods-container">
        <view class="goods-new-item" v-for="(item, index) in plazaList" :key="index">
             <view class="gc-content-item">
				 <view class="gc-item-head">
					<view class="best-item-head">
						  <image class="img" mode="aspectFill" :src="imagebaseurl+item.best.pic" :lazy-load="true" v-if="item.best"></image>
						  <image class="img" mode="aspectFill" :src="imagebaseurl + item.userPic" :lazy-load="true" v-else></image>
					</view>
					 <view class="best-item-content">
						 <view class="best-item-content-head">
							<text class="best-item-name" v-if="item.best">{{item.best.name}}</text>
							<text class="best-item-name" v-else>{{item.userName}}</text>
							<text class="best-item-tag" v-if="item.best" :class="item.best.sex == 1 ? 'man':'woman'">
								<image v-if="item.best.sex == 2" mode="aspectFill" class="sex" src="/static/images/nav/woman.png"></image>
								<image v-if="item.best.sex == 1" mode="aspectFill" class="sex" src="/static/images/nav/man.png"></image>
								<text style="margin-left: 10rpx">{{item.best.age}}</text>
							</text>
							<text class="best-item-tag" v-if="item.best">
								<image mode="aspectFill" class="sex" src="/static/images/nav/yz_auth.png"></image>
								<text style="margin-left: 10rpx;">颜值认证</text>
							</text>
							
						</view>
						<view class="best-item-content-info">
							<text>{{item.createTime}}</text>
							<text class="status-point"></text>
							<text>{{item.city}}</text>
						</view>
					 </view>
				 </view>
				 <view class="gc-item-text">{{item.content}}</view>
				 <view class="gc-item-imgs" v-if="item.imgs != ''">
					 <view class="gc-item" v-for="(img,indexx) in (item.imgs || '').split(',')" :key="indexx" @click="preview(item.imgs,indexx)">
						 <video :id="'myVideo'+indexx" :src="imagebaseurl + img" class="myVideo slide-image" mode="aspectFill"
						 :lazy-load="true" v-if="img.includes('video')" :enable-progress-gesture="false"
						 :controls="false" @play="pay(indexx,img)" :poster="imagebaseurl + img + '?x-oss-process=video/snapshot,t_0,f_jpg'" />
						 <image class="img" mode="aspectFill" :src="imagebaseurl + img" :lazy-load="true" v-else></image>
					 </view>
				 </view>
			 </view>
        </view>
        <view v-if="plazaList.length == 0" class="no-more-goods">
            <image src="/static/images/empty_record.png" class="no-order-img"></image>
            <view class="text">还没有任何动态呢</view>
        </view>
		
		<q-previewImage :urls="previewImgs" ref="previewImage"></q-previewImage>

    </view>
</template>

<script>
//index.js
//获取应用实例
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
const tools = require('../../utils/tools.js');
export default {
    data() {
        return {
			curPage: 1,
			pageSize: 5,
			totalPages: 0,
			imagebaseurl: getApp().globalData.fileDomain,
            wxlogin: false,
            plazaList: '',
            loadingMoreHidden: false,
			statusBarHeight: (typeof getApp().globalData.statusBarHeight === "number") ? getApp().globalData.statusBarHeight : 0,
			banners: [],
			dotStyle: 'square-dot',
			previewImgs:[],
			showYw: false,
			bestId:'',
			notice:''
        };
    }, 
	onLoad: function (e) {
		 this.bestId = e.id;
	},
    onShow: function () {
       this.afterAuth();
    },
	onPullDownRefresh: function() {
	
	  this.getList();
	  wx.stopPullDownRefresh();
	},
	onReachBottom: function () {
		// 滚动刷新
		if (this.curPage == this.totalPages || this.totalPages == 0) {
			return;
		}
	    this.setData({
	        curPage: this.curPage + 1
	    });
	    this.getList();
	},
    methods: {
		
        async afterAuth(e) {
            this.setData({
                wxlogin: true
            });
            await this.getList();
        },
		pay(index,img) {
			console.info(0);
			const videoContext = uni.createVideoContext('myVideo'+index, this);
			videoContext.pause();
			this.previewImgs = [];
			this.previewImgs.push(img)
			this.$refs.previewImage.open(this.previewImgs[0]);
		},
		preview(imgs,index) {
			this.previewImgs = imgs.split(",");
			this.$refs.previewImage.open(this.previewImgs[index]);
		},
        getList() {
			uni.showLoading({
			    title: '加载中'
			});
            WXAPI.bestPlazaList({
				pageSize: this.pageSize,
				page: this.curPage,
				bestId: this.bestId
			}).then((res) => {
                if (res.code == 200) {
					res.data.content.map(item=>{
						item.createTime = tools.timeago(item.createDate);
					});
					let newArray = res.data.content;
					this.plazaList = [...this.plazaList,...newArray]
                    this.setData({
						totalPages: res.data.totalPages,
                        loadingMoreHidden: true
                    });
                } else {
                    this.setData({
                        plazaList: [],
                        loadingMoreHidden: false
                    });
                }
				uni.hideLoading();
            });
        }
    }
};
</script>
<style>
@import './index.css';
</style>
