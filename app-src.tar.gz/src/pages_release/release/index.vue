<template>
	
	<view class="contain" >
		
		<view class="swiper-container" v-if="banners.length > 0">
		    <swiper :class="'screen-swiper ' + (dotStyle ? 'square-dot' : 'round-dot')" :circular="true" :autoplay="true" :indicator-dots="true" interval="5000" duration="500">
		        <swiper-item @tap="tapNav" :data-url="item.link" v-for="(item, index) in banners" :key="index">
		            <image :src="imagebaseurl + item.img"></image>
		        </swiper-item>
		    </swiper>
		</view>
		
<!-- #ifndef APP-PLUS -->
		<map style="width: 100%; height: 424rpx;"  enable-3D="false" :latitude="latitude" :longitude="longitude" show-compass="false" :scale="scale" enable-overlooking="false" :enable-satellite="false" :enable-traffic="false" show-location="true" :markers="covers" @click="jumpMap"></map>
		<!-- #endif -->
		<!-- #ifdef APP-PLUS -->
		<view style="width: 100%; height: 424rpx; background: #f0f2f5; display: flex; flex-direction: column; align-items: center; justify-content: center;" @click="jumpMap">
			<text style="color: #909399; font-size: 26rpx;">📍 {{form.address || '点击选择位置'}}</text>
			<text style="color: #c0c4cc; font-size: 22rpx; margin-top: 8rpx;">({{form.city || '选择城市'}})</text>
		</view>
		<!-- #endif -->
		
		<view class="release-content">
			<view class="release-address">
				<!-- <view>地址</view> -->
				<uni-data-select
					  class="city-select"
				      v-model="form.city"
				      :localdata="cityData"
					  placeholder="请选择城市"
					  @change="cityChange"
					  :clear="false"
				    ></uni-data-select>
				<view class="input-address" style="margin-left: 8px;">
					<textarea placeholder="请输入地址" v-model="form.address" auto-height />
				</view>
			</view>
			<view class="release-address">
				<view style="font-size: 16px;">备注</view>
				<view class="input-address">
					<textarea placeholder="请输入备注" v-model="form.remark" auto-height />
				</view>
			</view>
			<uni-collapse ref="collapse">
				<uni-collapse-item :title="'约玩项目 ：' + form.projectName" :open="collapseOpen" :show-animation="true" thumb="/static/images/nav/project.png">
					<view class="collapse-content" style="height: auto;">
						<project_list :projects="projects" :showCancel="false" :showConfirm="false" @toConfirm="serveConfirm" :city="form.city"></project_list>
					</view>
				</uni-collapse-item>
				<uni-collapse-item :title="'约玩时间 ：'+ form.date + ' ' + form.time" :open="collapseOpen" thumb="/static/images/nav/time.png">
					<view class="collapse-content">
						<time_list :showCancel="false" :showConfirm="false" :date.sync="form.date" :time.sync="form.time"></time_list>
					</view>
				</uni-collapse-item>
				<uni-collapse-item :title="'小费（加小费可让更多搭档报名） ：'+ form.gratuity" :open="collapseOpen" thumb="/static/images/nav/price.png">
					<view class="collapse-content">
						<gratuity_list :showCancel="false" :showConfirm="false" @toConfirm="gratuityConfirm"></gratuity_list>
					</view>
				</uni-collapse-item>
			</uni-collapse>
		</view>
		
		<view class="submit-order">
			<view class="submit-order-text">
				<view class="submit-order-price">
					<text>¥</text>
					<text class="submit-order-amount">{{form.price}}</text>
					<text>元</text>
				</view>
				<view class="submit-tip-text">注:发单扣除费用，增加打赏可让更多搭档报名</view>
			</view>
			<view class="submit-order-btn" @tap="submitApply()">提交订单</view>
		</view>
		<view class="show-popup" v-if="isPay">
			<view class="popup-mask" @click="closePay"></view>
			<view class="popup-contents">
				<payment @toCancel="closePay" @okPay="okPay" :payTypeId="2" :payOrderId="payOrderId" :payAmount="payAmount"></payment>
			</view>
		</view>
	</view>
	
</template>

<script>
// pages/search/search.js
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const TOOLS = require('../../utils/tools');
import project_list from './project_list.vue';
import time_list from '@/components/time_list.vue';
import gratuity_list from '@/components/gratuity_list.vue';
import payment from '@/components/payment';
export default {
    components: {
		project_list,
		time_list,
		gratuity_list,
		payment
    },
    data() {
        return {
		   collapseOpen:true,
		   latitude: 39.899,
		   longitude: 116.39742,
			scale:14,
		    covers:[{
	            id: 1, // Number
	            title: '', // String-标注点名
	            rotate: 0, // Number - 顺时针旋转的角度，范围 0 ~ 360，默认为 0
	            alpha: 1, // 默认1，无透明，范围 0 ~ 1
	            latitude: 39.899,
	            longitude: 116.39742,
	            width: 30,
	            height: 30,
	            callout: { //自定义标记点上方的气泡窗口 点击有效 
                        content: '', //文本
                        color: '#333', //文字颜色
                         fontSize: 14, //文本大小
                        borderRadius: 10, //边框圆角
                        bgColor: '#fff', //背景颜色
                        display: 'ALWAYS', //常显
                        padding:10
	            },
	            // anchor: {},
	            iconPath: '/static/images/dingwei.png', // 显示的图标
	        }],
	
			form : {
				city: uni.getStorageSync('cityindex'),
				projectId:'',
				projectName:'',
				address:'',
				date:'',
				time:'',
				remark:'',
				price:19.9,
				gratuity:'',
			},
			isPay:false,
			payOrderId:0,
			payAmount:0,
			banners:[],
			imagebaseurl: getApp().globalData.fileDomain,
			dotStyle: 'square-dot',
			price:19.9,
			cityData: [],
			priceDate: [],
			projectDate:[],
			projects:[]
        };
    },
	
	
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (option) {
		let _this = this;
		uni.getLocation({
			type: 'wgs84',
			geocode: true,
			isHighAccuracy: true,
			success: function(res) {
				console.log(res.latitude+"--"+res.longitude);
				_this.latitude = res.latitude;
				_this.longitude = res.longitude;
				_this.getLocation(0);
			
			},
			fail: function(res) {
				console.log('获取当前位置的经纬度-失败');
				console.log(res);
			}
		});
		this.initPage();
		this.getNotice();
		this.getCity();
	},
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
		// this.mapContext = uni.createMapContext("map", this);
	},
	
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
		this.$nextTick(() => {
			this.$refs.collapse.resize()
			this.getProjects();
		})
    },
	
    methods: {
		cityChange(i) {
			var priceItem;
			if (i === 0) {
				priceItem = this.priceDate[0];
			} else {
				priceItem = this.priceDate.find(city => city.title === i);
			}
			// 核心匹配逻辑
			this.projects = this.projectDate.filter(item => 
			  priceItem.server_names.split(',').includes(item.title)
			);
			this.price = priceItem.price;
			this.form.price = priceItem.price + Number(this.form.gratuity);
		},
		getProjects(){
			WXAPI.serveList({
				bestId: 0,
				type: 1
			}).then((res) => {
				if(res.code==200){
					this.projectDate = res.data;
					if (this.form.city == '') {
						// this.projects = this.projectDate;
						this.cityChange(0);
					} else {
						this.cityChange(this.form.city);
					}
					
				}
			});
		},
		getCity() {
			let _this = this;
			WXAPI.citys().then((res) => {
				if(res.code == 200){
					let array = res.data;
					this.priceDate = array;
					for(var key in array){
						_this.cityData.push({
							"value": array[key].title,
							"text": array[key].title
						})
					}
				}
			});
		},
		// onMapReady(e) {
		//   this.mapCtx = e.mp.createMapContext();
		// },
		getPrice(){
			WXAPI.getData('Demand_Price').then((res) => {
				if(res.code==200){
					let resData = Object.values(res.data)
					let nowPrices = resData.filter(priceItem => {
					  const nowHours = new Date().getHours();
					  const price = priceItem.split('-');
					  return nowHours >= price[0] && nowHours < price[1];
					});
					if (nowPrices != null && nowPrices[0].indexOf('-') > 0) {
						const prices = nowPrices[0].split('-');
						this.price = Number(prices[2]);
						this.form.price = this.price;
					}
				}
			});	
		},
		getNotice() {
			WXAPI.newsNotice(2).then(res => {
			  if (res.code == 200 && res.data.popStatus == 1) {
				uni.showModal({
					title: '官方提醒',
					content: res.data.content,
					showCancel: false,
					confirmText: '我已知晓',
					success: function (res) {
						if (res.confirm) {
							console.log('用户点击确定');
						}
					}
				});
			  }
			});
		},
		tapNav(e) {
		    const url = e.currentTarget.dataset.url;
			if (url.includes("http")) {
				// #ifdef H5
				window.location.href = url;
				// #endif
				// #ifdef APP-PLUS
				plus.runtime.openURL(url);
				// #endif
			} else {
				uni.navigateTo({
				    url: url
				});
			}
		},
		async initPage() {
			//获取轮播
			const bannerRes = await WXAPI.menuList({type: 13});
			if (bannerRes.code == 200) {
			     this.banners = bannerRes.data;
			}
		},
		getLocation: function(type) {
			let _this = this;
			uni.request({
				url: "/ws/geocoder/v1/",
				data: {
				 key: "3QHBZ-UQXYJ-OWAFU-DFBJH-X6DS7-PXFU7",
				 location: _this.latitude + ',' + _this.longitude,
				},
				success: (res) => {
					console.log('==H5获取当前位置==');
					let result = eval('(' + JSON.stringify(res) + ')');
					console.log('===='+result.data.message);
					let {
						province,
						city,
						district,
						street,
					} = result.data.result.address_component;
					console.log(result.data.result.address_component);
					
					if (type == 0) {
						_this.form.address = city+district;
					} else {
						_this.form.address = result.data.result.address;
					}
					_this.form.city = city;
					if (city.indexOf('市') > -1) {
						_this.form.city = city.substring(0,city.length - 1);
					}
					console.info(_this.form.city);
				},
				fail: (err) => {
				 console.log(err);
				}
			  })
		},
		closePay: function() {
			this.isPay = false;
		},
		okPay: function() {
			this.isPay = false;
			uni.navigateTo({
				url: "/pages_release/release/list"
			});
		},
		serveConfirm(serve) {
			this.form.projectId = serve.id;
			this.form.projectName = serve.title;
		},
		gratuityConfirm(amount) {
			this.form.gratuity = amount;
			this.form.price = this.price + Number(amount);
		},
		closePopup(n) {
			if (n == 0) {
				this.form.projectId = '';
				this.form.projectName = '';
			} else if (n == 1) {
				this.form.gratuity = '';
			} else {
				this.form.gratuity = 0;
			}
		},
		
		jumpMap() {
			// v2.1.8: APP未打Map模块,chooseLocation会弹"未添加Map模块"——APP上引导手动填写地址
			// #ifdef APP-PLUS
			uni.showToast({ title: '请直接在下方输入地址', icon: 'none' });
			return;
			// #endif
			// #ifndef APP-PLUS
			let _this = this;
			uni.chooseLocation({
				success: function(res) {
					_this.latitude = res.latitude;
					_this.longitude = res.longitude;
					let address = res.address;
					if(address.indexOf('省') > -1) {
						address = address.substring(address.indexOf('省')+1);
						_this.form.city = address.substring(address.indexOf('省')+1,address.indexOf('市'));
					}
					_this.form.address = address + res.name;
					
					_this.covers[0].callout.content = res.name;
					_this.covers[0].latitude = res.latitude;
					_this.covers[0].longitude = res.longitude;
					
					//_this.getLocation(1);
				}
			});
			// #endif
		},
		
		submitApply(){
			var loginToken = uni.getStorageSync('bestpw-Token');
			if (!loginToken) {
			    uni.showModal({
			        title: '友情提示',
			        content: '用户未登录，请用户登录后再发单！',
			        showCancel: false
			    });
			    return;
			}
			let _this = this;
			if (_this.form.city =='') {
				uni.showToast({icon: 'none',title: '请点击地图选择地址'}); 
			    return false;
			} 
			if (_this.form.address =='') {
				uni.showToast({icon: 'none',title: '请填写详细地址'}); 
			    return false;
			} 
			if (_this.form.projectId =='') {
				uni.showToast({icon: 'none',title: '请选择项目'}); 
			    return false;
			} 
			if (_this.form.date == '') {
				uni.showToast({icon: 'none',title: '请选择日期'});
				return false;
			}
			if (_this.form.time == '') {
				uni.showToast({icon: 'none',title: '请选择时间'});
				return false;
			}
			if (_this.form.gratuity == '') {
				uni.showToast({icon: 'none',title: '请选择小费'});
				return false;
			}
			uni.showLoading();
			WXAPI.demandSave(_this.form).then((res) => {
				uni.hideLoading();
				if(res.code==200){
					var id = res.data;
					this.payOrderId = res.data;
					this.payAmount = _this.form.price;
					this.isPay = true;
				} else {
					uni.showModal({
						title: '提示',
						content: result.msg,
						showCancel: false
					});
				}
			});
		}
    }
};

</script>
<style>
@import './index.css';
</style>
