<template>
    <view style="height: 100%;background: none;">
        
        <navigator :url="'/pages_release/release/best?id=' + item.id" v-for="(item, index) in demand_list" :key="index">
            <view class="list1 shadow bg-white">
				
                <view class="goods-info">
                    
					<view class="address">
						<text>城市：{{ item.city }}</text>
						<text style="float: right;margin-right: 20rpx;" v-if="item.secondTime > 0">
							<uni-countdown style="display: inline-block;" 
							:show-day="item.isDay"
							@timeup="timeup(index)" :second="item.secondTime" />
						</text>
						<text style="float: right;margin-right: 20rpx;color: #b1a8a8;font-size: 30rpx;" v-else>
							已失效
						</text>
					</view>
					
                    <view class="address">约玩地址：{{ item.address }}</view>
					
					<view class="address">约玩项目：{{ item.projectName }}</view>
					
					<view class="address" v-if="item.demandTime">约玩时间：{{ item.demandTime }}</view>
					<view class="address" v-else>约玩时间：{{ item.date }} {{ item.time }}</view>
					<view class="address">红包打赏：{{ item.gratuity }}元</view>
					<view class="address" v-if="item.remark">备注：{{ item.remark }}</view>
					
                    <view class="buy-info">
                        <view class="price">已接单 {{ item.num }} 人</view>
                        <view><button class="ydbtn">查看接单</button></view>
                    </view>
                </view>
            </view>
        </navigator>

        <view v-if="demand_list.length == 0" class="no-more-goods">
            <image src="/static/images/empty_goods.png" class="no-order-img"></image>
            <view class="text">没有发单</view>
        </view>
		
    </view>
</template>

<script>
//获取应用实例
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const app = getApp();
export default {
    data() {
        return {
            //需求列表
			curPage: 1,
			pageSize: 5,
			totalPages:0,
            demand_list: [],
        };
    },
    onLoad: function (options) {
        
        this.getList();
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
		// 滚动刷新
		if (this.curPage == this.totalPages) {
			return;
		}
		this.setData({
		    curPage: this.curPage + 1
		});
		this.getList();
	},
    methods: {
        async getList() {
            // 搜索商品
            uni.showLoading({
                title: '加载中'
            });
			WXAPI.demandList({
				pageSize: this.pageSize,
				page: this.curPage
			}).then((res) => {
			    if (res.code == 200) {
					res.data.content.map(item=>{
						item.secondTime = 0;
						item.isDay = false;
						if (item.time.indexOf('-') > 0) {
							const array = item.time.split('-');
							var endTime = new Date(item.date + " " + array[1] + ":00");
							endTime.setHours(endTime.getHours() - 1);
							if (endTime.getTime() > new Date().getTime()) {
								item.secondTime = Math.round((endTime.getTime() - new Date().getTime()) / 1000)
							}
						} else {
							const diffs = 3600 - Math.round((new Date() - new Date(item.createDate)) / 1000);
							if (diffs > 0) {
								item.secondTime = diffs;
							}
						}
					});
					var newArray = res.data.content;
					this.demand_list = [...this.demand_list,...newArray];
					
					this.totalPages = res.data.totalPages;
					uni.hideLoading();
			    }
			});
        },
		timeup(index) {
			this.demand_list[index].secondTime = 0;
		}
    }
};
</script>
<style>
@import './list.css';
</style>

