<template>
    <view style="height: 100%">
		
		
		<navigator :url="'/pages_details/goods-details/index?id=' + item.best.id" class="shadow goods-new-item" v-for="(item, index) in bestList" :key="index">
		    <view class="list1 bg-white">
		        <image class="img" mode="aspectFill" :src="imagebaseurl + item.best.pic" :lazy-load="true"></image>
		        <view class="goods-info">
		            <view class="title">
						{{ item.best.name }}
						<view class="best-item-tag" :class="item.best.sex == 1 ? 'man':'woman'">
							<image v-if="item.best.sex == 2" mode="aspectFill" class="sex" src="/static/images/nav/woman.png"></image>
							<image v-if="item.best.sex == 1" mode="aspectFill" class="sex" src="/static/images/nav/man.png"></image>
							<text style="margin-left: 10rpx">{{item.best.age}}</text>
						</view>
						<view class="best-item-tag" :class="item.best.sex == 1 ? 'man':'woman'" v-if="item.best.auths.includes('颜值认证')">
							<image mode="aspectFill" class="sex" src="/static/images/nav/yz_auth.png"></image>
							<text style="margin-left: 6rpx;">颜值认证</text>
						</view>
		            </view>
		        </view>
				<view class="yuyue2">查看详情</view>
				
		    </view>
			<view class="buy-info">
			    <view class="num" style="white-space:nowrap;">
					<text class="info-desc" v-for="(mk,index) in (item.best.tags || '').split(',')">{{mk}}</text>
				</view>
			</view>
			<view class="goods-imgs">
				 <view class="goods-img" v-for="(img,index) in (item.imgs)">
					 <image :src="imagebaseurl + img" class="slide-image" mode="widthfix" :lazy-load="true" />
				 </view>
			</view>
			
		</navigator>

        <view v-if="bestList.length == 0" class="no-more-goods">
            <image src="/static/images/empty_goods.png" class="no-order-img"></image>
            <view class="text">没人接单</view>
        </view>
		
    </view>
</template>

<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const app = getApp();
export default {
    data() {
        return {
            //
			imagebaseurl: getApp().globalData.fileDomain,
			demandId:'',
			curPage: 1,
			pageSize: 5,
			totalPages:0,
            bestList: [],
        };
    },
    onLoad: function (options) {
        this.demandId = options.id;
        this.getList();
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
		// 滚动刷新
		if (this.curPage == this.totalPages) {
			return;
		}
		this.setData({
		    curPage: this.curPage + 1
		});
		this.getList();
	},
    methods: {
       
        async getList() {
            // 搜索商品
            uni.showLoading({
                title: '加载中'
            });
			WXAPI.demandOrder({
				pageSize: this.pageSize,
				page: this.curPage,
				demandId: this.demandId
			}).then((res) => {
			    if (res.code == 200) {
					var newArray = res.data.content;
					this.bestList = [...this.bestList,...newArray]
					this.totalPages = res.data.totalPages;
					uni.hideLoading();
			    }
			});
			
        },

        
    }
};
</script>
<style>
@import './best.css';
</style>

