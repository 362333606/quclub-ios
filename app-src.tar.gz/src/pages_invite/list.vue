<template>
    <view class="partner-container">
		<view class="invite-content">
			<view class="invite-item" v-for="(item,index) in userList">
				<view class="user-logo">
					<image :src="item.pic" v-if="item.pic.includes('http')" />
					<image :src="imagebaseurl + item.pic" v-if="!item.pic.includes('http')" />
				</view>
				<view class="user-info">
					<view>{{item.phone}}</view>
				</view>
				<view class="user-price">{{item.time}}</view>
			</view>
		</view>
		<view v-if="userList.length == 0" class="no-more-goods">
		    <image src="/static/images/empty_record.png" class="empty-record"></image>
		    <view class="text">还没有任何记录呢</view>
		</view>
    </view>
</template>

<script>
//index.js
//获取应用实例
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
export default {
    data() {
        return {
			type:0,
			curPage: 1,
			pageSize: 5,
			totalPages: 0,
			userList:[],
			loadingMoreHidden:false,
			imagebaseurl: getApp().globalData.fileDomain,
        };
    },
    onShow: function () {
		this.getList();
    },
	onReachBottom: function () {
		// 滚动刷新
		if (this.curPage == this.totalPages) {
			return;
		}
	    this.setData({
	        curPage: this.curPage + 1
	    });
	    this.getList();
	},
    methods: {
		getList() {
			uni.showLoading({
			    title: '加载中'
			});
		    WXAPI.userInviteList({
				pageSize: this.pageSize,
				page: this.curPage,
			}).then((res) => {
		        if (res.code == 200) {
					let newArray = res.data;
					this.userList = [...this.userList,...newArray];
		        }
				uni.hideLoading();
		    });
		}
    }
};
</script>
<style>
@import './list.css';
</style>
