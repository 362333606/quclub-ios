<template>
    <view class="partner-container">
		<image src="/static/images/bg/invite.jpeg"></image>
		<view class="invite-content">
			<view>
				<canvas canvas-id="qrcode" :style="{width:qrWidth+'px',height:qrWidth+'px'}"></canvas>
			</view>
			<view v-if="inviteCode">
				<view class="invite-text">邀请码：{{inviteCode}}</view>
				<view class="invite-list" @click="tapNav">邀请的朋友</view>
			</view>
		</view>
    </view>
</template>

<script>
//index.js
//获取应用实例
import uQRCode from '@/utils/uqrcode.js';
const AUTH = require('@/utils/auth');
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
export default {
    data() {
        return {
			type:0,
			QRurl: '',
			inviteCode:'',
			qrWidth: 100
        };
    },
    onShow: function () {
		
    },
	onLoad:function(){
		let _this = this;
		AUTH.checkHasLogined().then((isLogined) => {
		    if (isLogined) {
				WXAPI.userDetail().then((res) => {
					if (res.code == 200) {
						_this.inviteCode = res.data.inviteCode;
						this.QRurl = 'https://top.qiuyu8.cn/#/pages/login/reg?inviteCode='+res.data.inviteCode;
						this.qrFun(this.QRurl);
					}
				})
			}
		});
		
	},
    methods: {
		tapNav() {
			uni.navigateTo({
			    url: '/pages_invite/list'
			});
		},
		qrFun(text) {
			uQRCode.make({
				canvasId: 'qrcode',  // 必须与上面canvas-id="qrcode"值一致
				componentInstance: this,  // 组件实例
				text: text,  // 二维码内容
				size: this.qrWidth,  // 单位px，做了手机适配
				margin: 0,
				backgroundColor: '#ffffff',  //背景颜色
				foregroundColor: '#000000',  // 前景颜色
				fileType: 'jpg',  // 二维码图片类型
				errorCorrectLevel: uQRCode.errorCorrectLevel.H,  // 容错级别
				success: res => {
					// 生成二维码成功后的操作
					// ...
				}
			})
		}
    }
};
</script>
<style>
@import './index.css';
</style>
