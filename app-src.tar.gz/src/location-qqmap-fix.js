(function() {
	var appendChild
	try {
		appendChild = document.body.appendChild
	} catch (e) {}

	function parse(src) {
		var array = src.split('?')[1].split('&')
		var obj = {}
		array.forEach(function(item) {
			var key = item.split('=')[0]
			var value = item.split('=')[1]
			obj[key] = value
		})
		return obj
	}
	if (appendChild) {
		document.body.appendChild = function(child) {
			if (child instanceof HTMLScriptElement) {
				var src = child.src
				if (src && src.includes('apis.map.qq.com/jsapi?qt=translate')) {
					var obj = parse(src)
					var callback = obj.cb
					var newCallback = callback + '_translate'
					window[newCallback] = function(data) {
						delete window[newCallback]
						var points = data.locations
						window[callback]({
							detail: {
								points: points
							},
						})
					}
					child.src =
						'https://apis.map.qq.com/ws/coord/v1/translate?locations=' + obj.points.split(',')
						.reverse()
						.join(',') +
						'&output=jsonp&type=1&key=' + obj.key + '&callback=' + newCallback
				}
			}
			appendChild.apply(document.body, arguments)
		}
	}
})()