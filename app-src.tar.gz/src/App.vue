<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const CONFIG = require('./config.js');
const AUTH = require('./utils/auth');

// import { WXAPI } from '/miniprogram_npm/apifm-wxapi';
// import { CONFIG } from './config.js';
// import { AUTH } from './utils/auth';

// import { TUILogin } from '@tencentcloud/tui-core';
// // #ifdef APP-PLUS || H5
// import { TUIChatKit } from './TUIKit';
// TUIChatKit.init();
// // #endif

// let vueVersion = 2;
// // #ifdef VUE3
// vueVersion = 3;
// // #endif
// ﻿
// Required information
// You can get userSig from TencentCloud chat console for Testing TUIKit.
// Deploy production environment please get it from your server.
// View https://cloud.tencent.com/document/product/269/32688
// uni.$SDKAppID = 0; // Your SDKAppID
// uni.$userID = ''; // Your userID
// uni.$userSig = ''; // Your userSig

// uni.$SDKAppID = 1600065675; // Your SDKAppID
// uni.$userID = 'dll'; // Your userID
// uni.$userSig = 'eJyrVgrxCdYrSy1SslIy0jNQ0gHzM1NS80oy0zLBwik5OVDh4pTsxIKCzBQlK0MzAwMDM1Mzc1OITGpFQWZRKlDc1NTUCCgFES3JzAWJmRsbm5uaGFpC1RZnpgNNLSzzLovR9y8rscx2KfM3cPOJMA2p8vBP9o7wKDJ1c8tILkl0MQnyKTV3Ncu3VaoFAOIVMOA_'; // Your userSig
// // uni.$userID = 'zxc'; // Your SDKAppID

export default {
    data() {
        return {
		};
    },
    onError: function (err) {
        console.error('App.onError:', err);
        // #ifdef APP-PLUS
        try {
            var msg = String((err && err.message) || err).slice(0, 260);
            uni.showModal({ title: '页面脚本报错(截图发令曦)', content: msg, showCancel: false });
        } catch (e) {}
        // #endif
    },
    onLaunch: function () {
        // 全局错误捕获(令曦20260904 v2.1.3): APP上任何页面脚本报错弹窗显示错误文本,截图即可远程定位
        // #ifdef APP-PLUS
        try {
            uni.onUnhandledRejection(function (res) {
                var msg = String((res && res.reason && (res.reason.errMsg || res.reason.message)) || res.reason || '').slice(0, 260);
                if (msg.indexOf('app-no-wx-oauth') !== -1) return; // 预期内:APP无微信授权
                console.error('unhandledRejection:', res.reason);
                uni.showModal({ title: '脚本报错(截图发令曦)', content: msg || '(空)', showCancel: false });
            });
        } catch (e) { console.error('错误捕获注册失败', e); }
        // #endif
		// TUILogin.login({
		//   SDKAppID: uni.$SDKAppID,
		//   userID: uni.$userID, 
		//   userSig: uni.$userSig, 
		//   useUploadPlugin: true, // If you need to send rich media messages, please set to true.
		//   framework: `vue${vueVersion}` // framework used vue2 / vue3
		// }).catch(() => {});
		const fileDomain = "https://okqwe-1317925852.cos.ap-beijing.myqcloud.com"
		// const subDomain = uni.getExtConfigSync().subDomain;
		const subDomain = '';
        // const componentAppid = uni.getExtConfigSync().componentAppid;
        // if (componentAppid) {
        //     uni.setStorageSync('appid', uni.getAccountInfoSync().miniProgram.appId);
        //     uni.setStorageSync('componentAppid', componentAppid);
        // }
        if (subDomain) {
            WXAPI.init(subDomain);
        } else {
            WXAPI.init(CONFIG.subDomain);
            WXAPI.setMerchantId(CONFIG.merchantId);
        }
        const that = this;
        // #ifdef MP-WEIXIN
        // 检测新版本(小程序专用,原裸调在APP/H5是死代码且可能报错)
        const updateManager = uni.getUpdateManager();
        updateManager.onUpdateReady(function () {
            uni.showModal({
                title: '更新提示',
                content: '新版本已经准备好，是否重启应用？',
                success(res) {
                    if (res.confirm) {
                        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                        updateManager.applyUpdate();
                    }
                }
            });
        });
        // #endif
        // #ifdef APP-PLUS
        // v2.1.9: APP热更新(wgt)——拉version.json比对widget版本,新则弹窗下载wgt静默安装重启
        // 全程try/catch+fail静默: 任何一步失败绝不阻塞启动、绝不弹错
        try {
            plus.runtime.getProperty(plus.runtime.appid, function (widgetInfo) {
                if (!widgetInfo || !widgetInfo.versionCode) { return; }
                uni.request({
                    url: 'https://vipk.qyai001.cn/quclub/version.json',
                    timeout: 5000,
                    success: function (res) {
                        try {
                            var remote = (res && res.data) ? res.data : {};
                            if (typeof remote === 'string') { try { remote = JSON.parse(remote); } catch (e) { return; } }
                            if (remote.code && parseInt(remote.code) > parseInt(widgetInfo.versionCode)) {
                                uni.showModal({
                                    title: '更新提示',
                                    content: remote.note || '发现新版本，是否立即升级？',
                                    success: function (r) {
                                        if (r.confirm && remote.wgtUrl) {
                                            uni.showLoading({ title: '下载新版本中...', mask: true });
                                            uni.downloadFile({
                                                url: remote.wgtUrl,
                                                success: function (dl) {
                                                    uni.hideLoading();
                                                    if (dl.statusCode == 200) {
                                                        plus.runtime.install(dl.tempFilePath, { force: false }, function () {
                                                            plus.runtime.restart();
                                                        }, function (e) { console.log('wgt安装失败', e); });
                                                    }
                                                },
                                                fail: function (e) {
                                                    uni.hideLoading();
                                                    console.log('wgt下载失败', e);
                                                }
                                            });
                                        }
                                    }
                                });
                            }
                        } catch (e) { console.log('热更新比对失败', e); }
                    },
                    fail: function () { /* 静默: 网络失败跳过 */ }
                });
            });
        } catch (e) { console.log('热更新初始化失败', e); }
        // #endif
        //检测手机类型
        uni.getSystemInfo({
            success: function (res) {
                if (res.model.search('iPhone X') != -1) {
                    that.globalData.iphone = true;
                }
                if (res.model.search('MI 8') != -1) {
                    that.globalData.iphone = true;
                }
            }
        });
        /**
         * 初次加载判断网络情况
         * 无网络状态下根据实际情况进行调整
         */
        uni.getNetworkType({
            success(res) {
                const networkType = res.networkType;
                if (networkType === 'none') {
                    that.globalData.isConnected = false;
                    uni.showToast({
                        title: '当前无网络',
                        icon: 'loading',
                        duration: 2000
                    });
                }
            }
        });
        /**
         * 监听网络状态变化
         * 可根据业务需求进行调整
         */
        uni.onNetworkStatusChange(function (res) {
            if (!res.isConnected) {
                that.globalData.isConnected = false;
                uni.showToast({
                    title: '网络已断开',
                    icon: 'loading',
                    duration: 2000,
                    complete: function () {
                        that.globalData.goStartIndexPage();
                    }
                });
            } else {
                that.globalData.isConnected = true;
                uni.hideToast();
            }
        });
    
    },
    onShow(e) {
        this.globalData.launchOption = e;
        // 保存邀请人
        if (e && e.query && e.query.inviter_id) {
            uni.setStorageSync('referrer', e.query.inviter_id);
            if (e.shareTicket) {
                // 通过分享链接进来
                uni.getShareInfo({
                    shareTicket: e.shareTicket,
                    success: (res) => {
                        // console.error(res)
                        // console.error({
                        //   referrer: e.query.inviter_id,
                        //   encryptedData: res.encryptedData,
                        //   iv: res.iv
                        // })
                        WXAPI.shareGroupGetScore(e.query.inviter_id, res.encryptedData, res.iv);
                    }
                });
            }
        }
        // 自动登录
        // AUTH.checkHasLogined().then((isLogined) => {
        //     if (!isLogined) {
        //         AUTH.login();
        //     } else {
        //         AUTH.bindSeller();
        //     }
        // });
    },
    globalData: {
        isConnected: true,
		
		api_root: 'https://top.qiuyu8.cn/fireshop',
		fileDomain : "https://oss.bestpw.cn/",
        //vipLevel: 0
        launchOption: undefined,
		statusBarHeight: function() {
			var t = uni.getMenuButtonBoundingClientRect();
			if (t) {
				return t.bottom;
			} else {
				return 0;
			}
		},
		
		// statusBarHeight: uni.getMenuButtonBoundingClientRect().bottom,

        fadeInOut: function (that, param, opacity) {
            const animation = uni.createAnimation({
                //持续时间800ms
                duration: 300,
                timingFunction: 'ease'
            });
            animation.opacity(opacity).step();
            let json = '{"' + param + '":""}';
            json = JSON.parse(json);
            json[param] = animation.export();
            that.setData(json);
        },
	
        goStartIndexPage: function () {
            setTimeout(function () {
                uni.redirectTo({
                    url: '/pages/start/start'
                });
            }, 1000);
        },
	
		tapNav(e) {
		    const url = e.currentTarget.dataset.url;
		    uni.navigateTo({
		        url: url
		    });
		},
		/**
		 * 显示失败提示框
		 */
		showError(msg, callback) {
		    uni.showModal({
		        title: '友情提示',
		        content: msg,
		        showCancel: false,
		
		        success(res) {
		            // callback && (setTimeout(function() {
		            //   callback();
		            // }, 1500));
		            if (callback) {
		                callback();
		            }
		        }
		    });
		},
		
		/**
		 * post提交
		 */
		_post_form(url, data, success, fail, complete, isShowNavBarLoading) {
		    let _this = this;
	
		    isShowNavBarLoading || true;
		
		    if (isShowNavBarLoading == true) {
		        uni.showNavigationBarLoading();
		    }
		
		    uni.request({
		        url: url,
		        header: {
		            'content-type': 'application/x-www-form-urlencoded'
		        },
		        method: 'POST',
		        data: data,
		
		        success(res) {
		            if (res.statusCode !== 200 || typeof res.data !== 'object') {
		                _this.showError('网络请求出错');
		
		                return false;
		            }
		
		            if (res.data.code === -1) {
		                // 登录态失效, 重新登录
		                uni.hideNavigationBarLoading();
		
		                _this.doLogin(1);
		
		                return false;
		            } else if (res.data.code === 0) {
		                _this.showError(res.data.msg, function () {
		                    if (fail) {
		                        fail(res);
		                    }
		                });
						uni.hideLoading();
		                return false;
		            }
		
		            if (success) {
		                success(res.data);
		            }
		        },
		
		        fail(res) {
		            // console.log(res);
		            _this.showError(res.errMsg, function () {
		                if (fail) {
		                    fail(res);
		                }
		            });
		        },
		
		        complete(res) {
		            uni.hideNavigationBarLoading(); // wx.hideLoading();
		
		            if (complete) {
		                complete(res);
		            }
		        }
		    });
		},
		
		
    }
};
</script>
<style>
@import './app.css';
</style>
