<template>
    <view style="height: 100%">
        
        
		<view class="list1 shadow bg-white">
			
			<view class="goods-info">
				
				<view class="address">
					<text>城市：{{ detail.city }}</text>
					<text style="float: right;margin-right: 20rpx;" v-if="testSecond > 0">
						<uni-countdown style="display: inline-block;" 
						:show-day="isDay"
						@timeup="timeup" :second="testSecond" />
					</text>
					<!-- <text style="float: right;margin-right: 20rpx;color: #b1a8a8;font-size: 30rpx;" v-else>
						已失效
					</text> -->
				</view>
				
				<view class="address">约玩地址：{{ detail.address }}</view>
				
				<view class="address">约玩项目：{{ detail.projectName }}</view>
				
				<view class="address">约玩时间：{{ detail.date }} {{ detail.time }}</view>
				<view class="address">红包打赏：{{ detail.gratuity }}元</view>
				<view class="address">备注：{{ detail.remark }}</view>
				
				<view class="btn-info">
					<view v-if="detail.isAdd == 0">
						<button class="ydbtn" @click="toDemand">报名</button>
						<!-- <button class="isydbtn" v-else>已过期</button> -->
					</view>
					<view v-if="detail.isAdd == 1"><button class="isydbtn">已报名</button></view>
					<view class="recharge-desc" style="margin-top: 20rpx;text-align: center;" v-if="detail.isAdd == 0">
						<checkbox-group @click="changeChecked">
							<label style="color: #9c9d9d;">
								<checkbox value="bb" :checked="checkboxMark" style="transform: scale(0.8)"  />
								已知晓并同意<text style="color: #6ea2ff" @click="tapNav('/pages/news/index?id=18')">《接单协议》</text>
							</label>
						</checkbox-group>
					</view>
				</view>
			</view>
		</view>
       

        <view v-if="detail.length == 0" class="no-more-goods">
            <image src="/static/images/empty_goods.png" class="no-order-img"></image>
            <view class="text">没有发单</view>
        </view>
		
    </view>
</template>

<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const app = getApp();
export default {
    data() {
        return {
			demandId:'',
            //需求列表
            detail: [],
			testSecond: 0,
			isDay:false,
			checkboxMark: true
        };
    },
    onLoad: function (options) {
        
		this.demandId = options.id;
        this.search();
		if(this.isWeiXinLogin() && (!uni.getStorageSync('bestpw-Token'))) {
			this.toWxLogin();
		}
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {},
    methods: {
		changeChecked(){
			this.checkboxMark = !this.checkboxMark;
		},
		tapNav(url) {
		    uni.navigateTo({
		        url: url
		    });
		},
		isWeiXinLogin() {
			// #ifdef APP-PLUS
			return false; // APP非微信环境,wx oauth流程整体跳过(v2.1.2)
			// #endif

		    var ua = window.navigator.userAgent.toLowerCase();
		    if (ua.match(/MicroMessenger/i) == 'micromessenger') {
		        return true; // 微信中打开
		    } else {
		        return false; // 普通浏览器中打开
		    }
		},
		getUrlCodeParam: function(name) {
			var after = window.location.hash.split("?")[1];
			if(after){
			 var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
			 var r = after.match(reg);
			 if(r != null){
				return  decodeURIComponent(r[2]);
			 } else {
				return null;
				}
			}
		},
       toWxLogin: function() {
			let code = this.getUrlCodeParam('code');
			let n = window.location.href.replace("#", "virtually");
			null == code || "" === code ? window.location.href = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx5a64ae4cbfea3f43&redirect_uri=" + encodeURIComponent(n) + "&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect" : this.wxLogin(code)
		},
		wxLogin: function(t) {
			uni.showLoading(),
			WXAPI.wxLogin({
				code: t
			}).then((res) => {
				uni.hideLoading();
				if (res.code == 200) {
					uni.setStorageSync("bestpw-Token", res.data.token)
					uni.setStorageSync("user_pic", res.data.pic)
					uni.setStorageSync("user_op", res.data.openid)
				} else {
					uni.showToast({
						icon: "none",
						title: res.msg
					})
				}
			})
		},
        search() {
            // 搜索商品
            uni.showLoading({
                title: '加载中'
            });
			WXAPI.demandDetail({
				demandId: this.demandId
			}).then((res) => {
			    if (res.code == 200) {
					this.detail = res.data;
					if (this.detail.time.indexOf('-') > 0) {
						const array = this.detail.time.split('-');
						var endTime = new Date(this.detail.date + " " + array[1] + ":00");
						// endTime.setHours(endTime.getHours() - 1);
						
						if (endTime.getTime() > new Date().getTime()) {
							this.testSecond = Math.round((endTime.getTime() - new Date().getTime()) / 1000)
							if (this.testSecond > 86400) {
								this.isDay = true;
							}
						}
					} else {
						const diffs = 5400 - Math.round((new Date() - new Date(res.data.createDate)) / 1000);
						if (diffs > 0) {
							this.testSecond = diffs;
						}
					}
					uni.hideLoading();
			    }
			});
        },
		timeup(){
			this.testSecond = 0;	   
		},
		toDemand(){
			var loginToken = uni.getStorageSync('bestpw-Token');
			if (!loginToken) {
			    uni.showModal({
			        title: '提示',
			        content: '用户未登录，请登录后再接单！',
			        showCancel: false
			    });
			    return;
			}
			uni.showLoading();
			WXAPI.demandSign({
				demandId: this.demandId
			}).then((res) => {
				uni.hideLoading();
			    if (res.code == 200) {
					uni.showToast({
					    title: '报名成功'
					});
					setTimeout(() => {
						//关闭提示后跳转
						location.reload();
					}, 1500);
			    } else {
					uni.showModal({
						title: '提示',
						content: res.msg,
						showCancel: false
					});
				}
			});
		}
    }
};
</script>
<style>
@import './detail.css';
</style>

