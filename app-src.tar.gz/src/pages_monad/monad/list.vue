<template>
    <view style="height: 100%">
        
        <navigator :url="'/pages_monad/monad/detail?id=' + item.id" v-for="(item, index) in demandList" :key="index">
            <view class="list1 shadow bg-white">
				
                <view class="goods-info">
                    
					<view class="address">城市：{{ item.city }}</view>
					
                    <view class="address">约玩地址：{{ item.address }}</view>
					
					<view class="address">约玩项目：{{ item.projectName }}</view>
					
					<view class="address">约玩时间：{{ item.date }} {{ item.time }}</view>
					<view class="address">红包打赏：{{ item.gratuity }}元</view>
					<view class="address">备注：{{ item.remark }}</view>
					
                    <view class="btn-info">
                        <view v-if="item.isAdd == 0"><button class="ydbtn">详情</button></view>
						<view v-if="item.isAdd == 1"><button class="isydbtn">已报名</button></view>
                    </view>
                </view>
            </view>
        </navigator>

        <view v-if="demandList.length == 0" class="no-more-goods">
            <image src="/static/images/empty_goods.png" class="no-order-img"></image>
            <view class="text">没有发单</view>
        </view>
		
    </view>
</template>

<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const app = getApp();
export default {
    data() {
        return {
            //需求列表
			curPage: 1,
			pageSize: 5,
			totalPages:0,
            demandList: [],
        };
    },
    onLoad: function (options) {
        
        this.getList();
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
		// 滚动刷新
		if (this.curPage == this.totalPages) {
			return;
		}
		this.setData({
		    curPage: this.curPage + 1
		});
		this.getList();
	},
    methods: {
        async getList() {
            // 搜索商品
            uni.showLoading({
                title: '加载中'
            });
        	WXAPI.demandAll({
        		pageSize: this.pageSize,
        		page: this.curPage,
				city:uni.getStorageSync('cityindex')?uni.getStorageSync('cityindex'):'武汉'
        	}).then((res) => {
        	    if (res.code == 200) {
        			var newArray = res.data.content;
        			this.demandList = [...this.demandList,...newArray]
        			this.totalPages = res.data.totalPages;
        			uni.hideLoading();
        	    }
        	});
        },
        
    }
};
</script>
<style>
@import './list.css';
</style>

