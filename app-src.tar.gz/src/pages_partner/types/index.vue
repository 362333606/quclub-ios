<template>
    <view class="partner-container">
		<view class="partner-head">
			<view class="partner-head-title">选择申请技能的类型</view>
			<view class="partner-head-text">各技能要求不同，可点击申请查看具体要求</view>
		</view>
		<view class="partner-content">
			<view class="types-item" @tap="navigateToPage" :data-id="item.id" :data-url="item.url" v-for="(item, index) in typesInfo" :style="'background-color:'+item.bg" :key="index">
				<view class="types-img"><image class="img" mode="aspectFill" :src="item.img"></image></view>
				<view class="types-info">
					<view class="types-name">{{item.name}}</view>
					
					<view class="types-desc" v-if="(index == 0 && count == 0) || index > 0">{{item.desc}}</view>
					<view class="types-desc" v-else>已申请陪玩搭档，无须重复申请</view>
				</view>
				<view class="types-btn" v-if="(index == 0 && count == 0) || index > 0">申请</view>
			</view>
		</view>
    </view>
</template>

<script>
//index.js
//获取应用实例
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
export default {
    data() {
        return {
			typesInfo:[{
				id: 1,
				name: '陪玩搭档',
				desc: '有颜有才爱玩会玩可申请',
				img: '/static/images/partner1.jpg',
				bg: '#82d4fe',
				url: '/pages/apply/index'
			},
			{
				id: 2,
				name: '营销搭档',
				desc: '拥有广大的用户群体可申请',
				img: '/static/images/partner2.jpg',
				bg: '#649cff',
				url: '/pages_partner/setin/index?type=2'
			},{
				id: 3,
				name: '人力搭档',
				desc: '拥有较多的陪玩搭档资源可申请',
				img: '/static/images/partner3.jpg',
				bg: '#b990f3',
				url: '/pages_partner/setin/index?type=3'
			},{
				id: 4,
				name: '合伙人搭档',
				desc: '认可行业并及拥有较优的资源可申请',
				img: '/static/images/partner4.jpg',
				bg: '#fdcf88',
				url: '/pages_partner/setin/index?type=4'
			}],
			count:0,
        };
    },
    onShow: function () {
		WXAPI.isBest().then((res) => {
		    this.count = res;
		});
    },
    methods: {
        navigateToPage(e) {
			let id = e.currentTarget.dataset.id;
			if (id == 1 && this.count > 0) {
				return;
			}
			let url = e.currentTarget.dataset.url;
			uni.navigateTo({
			    url: url
			});
		}
    }
};
</script>
<style>
@import './index.css';
</style>
