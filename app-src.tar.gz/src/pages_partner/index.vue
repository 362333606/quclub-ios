<template>
    <view class="partner-container">
		<view class="partner-head" style="margin-top: 100px;">
			<!-- <uni-section title="自定义图标" type="line" padding>
				<uni-steps :options="list1" active-icon="circle-filled" active-color="#ccc" :active="active" />
			</uni-section> -->
			<view class="user-head">
				<view class="user-head-item">
					<text class="time-btn" @tap="onLocate('开始订单')" v-if="bestId > 0">开始订单</text>
				</view>
				<view class="user-head-item" style="margin-top: -80px;">
					<image :src="imagebaseurl + pic" class="userinfo-avatar" v-if="pic"></image>
				</view>
				<view class="user-head-item">
					<text class="time-btn" @tap="onLocate('结束订单')" v-if="bestId > 0">结束订单</text>
				</view>
			</view>
		</view>
		<view class="wallet">
			<view class="wallet-info">
				<view class="wallet-all">
					<text class="wallet-title">钱包余额</text>
					<view class="wallet-balance">{{balance.toFixed(2)}}</view>
					<view class="wallet-desc">A档搭档100-200/H</view>
					<view class="wallet-desc">S档搭档200-400/H</view>
				</view>
				<view class="wallet-level">A档搭档</view>
			</view>
			<view class="wallet-option">
				<text @click="inputAlipayDialogToggle">绑定支付宝</text>
				<!-- <text @click="inputWechatDialogToggle" style="margin-left: 30rpx;">绑定微信</text> -->
				<text class="zz-yj" @tap="tapNav" data-url="/pages_invite/list">组长佣金</text>
				<text @click="inputTxDialogToggle" class="wallet-withdrawal">提现</text>
			</view>
		</view>
		
		<view class="swiper-container" v-if="banners.length > 0">
		    <swiper :class="'screen-swiper ' + (dotStyle ? 'square-dot' : 'round-dot')" :circular="true" :autoplay="true" :indicator-dots="true" interval="5000" duration="500">
		        <swiper-item @tap="tapNav" :data-url="item.link" v-for="(item, index) in banners" :key="index">
		            <image :src="imagebaseurl + item.img"></image>
		        </swiper-item>
		    </swiper>
		</view>
		
		<view class="balance-record">
			<view class="balance-record-title">
				<text :class="type == 0 ? 'active' :''" @click="onList(0)">提现明细</text>
				<text :class="type == 1 ? 'active' : ''" @click="onList(1)">收入明细</text>
				<text :class="type == 2 ? 'active' : ''" @click="onList(2)">扣款明细</text>
			</view>
			<view class="balance-item" v-for="(item, index) in balanceList" :key="index">
				<view class="balance-item-left">
					<view>
						<text v-if="item.way == 0">余额</text>
						<text v-if="item.way == 1">微信</text>
						<text v-if="item.way == 2">支付宝</text>
						<text v-if="item.type == 0">提现</text>
						<text v-if="item.type == 1">充值</text>
						<text v-if="item.type == 2">扣款</text>
						{{item.balance}}元</view>
					<view class="balance-item-time">{{item.createDate}}</view>
				</view>
				<view class="balance-item-right" v-if="item.type < 2">
					<text v-if="item.status == 0" style="display: inline-block;">审核中</text>
					<text v-if="item.status == 1" style="display: inline-block;">已打款</text>
					<text style="font-size: 20rpx;display: grid;">{{item.remark}}</text>
				</view>
				<view class="balance-item-right" v-if="item.type == 2">
					<text>{{item.remark}}</text>
				</view>
			</view>
			<view v-if="balanceList.length == 0" class="no-more-goods">
			    <image src="/static/images/empty_record.png" class="empty-record"></image>
			    <view class="text">还没有任何记录呢</view>
			</view>
		</view>
		
		<uni-popup ref="inpuAlipayDialog" type="dialog">
			<uni-popup-dialog ref="inputClose"  mode="input" title="绑定支付宝" :value="aliPay"
				placeholder="请输入支付宝" @confirm="aliPayConfirm">
			</uni-popup-dialog>
		</uni-popup>
		<!-- <uni-popup ref="inputWechatDialog" type="dialog">
			<uni-popup-dialog ref="inputClose"  mode="input" title="绑定微信号" :value="wechat"
				placeholder="请输入微信号" @confirm="wechatConfirm">
			</uni-popup-dialog>
		</uni-popup> -->
		<uni-popup ref="inpuTxDialog" type="dialog">
			<view class="tx-container">
				<view class="tx-title">提现申请</view>
				<view class="tx-content">
					<view style="margin-top: 30rpx;">
						<input class="tx-input" v-model="txBalance" />
						<text>元</text>
					</view>
					<view class="tx-desc">提款24小时内到账</view>
				</view>
				<view class="tx-option">
					<view class="tx-option-btn tx-upload" @click="upLoadPhoto">
						<image :src="imagebaseurl + fareImg" v-if="fareImg"></image>
						<image src="/static/images/nav/upload.png" v-else></image>
						<text>订单车费凭据</text>
					</view>
					<view class="tx-option-btn tx-submit" @click="txConfirm">立即提现</view>
				</view>
			</view>
		</uni-popup>
    </view>
</template>

<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('@/utils/auth');
//index.js
//获取应用实例
export default {
    data() {
        return {
			wxlogin: false,
			curPage: 1,
			pageSize: 10,
			totalPages: 0,
			type:0,
			pic:'',
			num:0,
			time:0,
			balance:0,
			banners: [],
			dotStyle: 'square-dot',
			balanceList:[],
			wechat:'',
			aliPay:'',
			txBalance:0,
			fareImg:'',
			imagebaseurl: getApp().globalData.fileDomain,
			active: 1,
			bestId: 0,
			list1: [{
				title: ''
			}, {
				title: 'A档'
			}, {
				title: 'S档'
			}, {
				title: ''
			}],
        };
    },
    onLoad: function () {
		this.getNotice();
		AUTH.checkHasLogined().then((isLogined) => {
		if (isLogined) {
				this.initPage();
				this.wxlogin = true;
				this.onLocate("自动访问");
			}
		});
    },
	onReachBottom: function () {
		// 滚动刷新
		if (this.curPage == this.totalPages) {
			return;
		}
	    this.setData({
	        curPage: this.curPage + 1
	    });
	    this.getList();
	},
    methods: {
		getNotice() {
			WXAPI.newsNotice(3).then(res => {
			  if (res.code == 200 && res.data.popStatus == 1) {
				uni.showModal({
					title: '官方提醒',
					content: res.data.content,
					showCancel: false,
					confirmText: '我已知晓',
					success: function (res) {
						if (res.confirm) {
							console.log('用户点击确定');
						}
					}
				});
			  }
			});
		},
		onLocate(title) {
			console.info(111);
			let _this = this;
			uni.getLocation({
				type: 'wgs84',
				geocode: true,
				isHighAccuracy: true,
				success: function(location) {
					console.info(2222)
					uni.request({
						url: "/ws/geocoder/v1/",
						data: {
							key: "3QHBZ-UQXYJ-OWAFU-DFBJH-X6DS7-PXFU7",
							location: location.latitude + "," + location.longitude
						},
						success: (res) => {
							var result = eval("(" + JSON.stringify(res) + ")");
							WXAPI.partnerLocate({
								location: "lat:" + location.latitude + ",lng:" + location.longitude,
								title: title,
								address: result.data.result.formatted_addresses.recommend + "(" + result.data.result.formatted_addresses.standard_address + ")",
								remark: result.data.result.address
							}).then((function(t) {
									if (200 == t.code && "自动访问" != title) {
										uni.showToast({title: "操作成功"})
									}
								}	
							))
						},
						fail: (err) => {
							console.log(t);
						}
					})
				},
				fail: function(t) {
					console.log('获取当前位置的经纬度-失败');
					console.log(t);
				}
			})
		},
		inputWechatDialogToggle() {
			this.$refs.inputWechatDialog.open();
		},
		inputAlipayDialogToggle() {
			this.$refs.inpuAlipayDialog.open();
		},
		inputTxDialogToggle() {
			this.$refs.inpuTxDialog.open();
		},
		wechatConfirm(val) {
			this.updatInfo(this.aliPay, val);
		},
		aliPayConfirm(val) {
			this.updatInfo(val, this.wechat);
		},
		updatInfo(aliPay, wechat) {
			let _this = this;
			if (!this.wxlogin) {
				uni.showToast({icon: 'none',title: '请登录后再操作'}); 
			}
			WXAPI.userUpdate({
				aliPay: aliPay,
				wechat: wechat
			}).then((res) => {
				if (res.code == 200) {
					uni.showToast({title: '绑定成功'});
					setTimeout(() => {
						_this.initPage();
					  }, 1000);
				} else {
					uni.showToast({
					    title: res.msg,
					    icon: 'none'
					});
				}
			})
		},
		txConfirm(val) {
			let _this = this;
			if (!this.wxlogin) {
				uni.showToast({icon: 'none',title: '请登录后再操作'}); 
				return false;
			}
			if (this.txBalance == '') {
				uni.showToast({icon: 'none',title: '请输入提现金额'}); 
			    return false;
			}
			if (Number(this.txBalance) < 50) {
				uni.showToast({icon: 'none',title: '单次提现不能小于50元'}); 
			    return false;
			}
			uni.showLoading();
			WXAPI.balanceWithdrawal({
				amount: this.txBalance,
				fareImg: this.fareImg
			}).then((res) => {
				uni.hideLoading();
				if (res.code == 200) {
					uni.showToast({title: '提现成功，等待审核'});
					setTimeout(() => {
						_this.$refs.inpuTxDialog.close();
						_this.fareImg = '';
						_this.initPage();
					}, 1500);
				} else {
					uni.showToast({
					    title: res.msg,
					    icon: 'none'
					});
				}
			})
		},
		tapNav(e) {
		    const url = e.currentTarget.dataset.url;
			if (url.includes("http")) {
				// #ifdef H5
				window.location.href = url;
				// #endif
				// #ifdef APP-PLUS
				plus.runtime.openURL(url);
				// #endif
			} else {
				uni.navigateTo({
				    url: url
				});
			}
		},
        onList(n){
			this.type = n;
			this.curPage = 1;
			this.balanceList = [];
			this.getList();
		},
		async initPage() {

			//获取轮播
			const bannerRes = await WXAPI.menuList({type: 12});
			if (bannerRes.code == 200) {
			     this.banners = bannerRes.data;
			}
			this.balanceList = [];
		    await this.getList();
		},
		getList() {
			uni.showLoading();
			var _that = this;
			WXAPI.partner({
				pageSize: this.pageSize,
				page: this.curPage,
				type: this.type
			}).then((res) => {
				uni.hideLoading();
			    if (res.code == 200) {
					let newArray = res.data.balanceList.content;
					this.balanceList = [...this.balanceList,...newArray];
					this.balance = res.data.balance;
					this.aliPay = res.data.alipay;
					this.pic = res.data.pic;
					this.bestId = res.data.bestId,
					// this.wechat = res.data.wechat;
					this.totalPages = res.data.balanceList.totalPages;
					if (res.data.count) {
						this.num = res.data.count;
						this.time = res.data.count * 3;
					}
					
					this.txBalance = this.balance;
			    } else {
					uni.navigateTo({
						url:'/pages/index/index'
					})
				}
			});
		},
		upLoadPhoto(){
			let _this = this;
			uni.chooseImage({
			    count: 1,
			    sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
			    sourceType: ['album'], //从相册选择
			    success: function(res) {
					var item = res.tempFiles.find(item=>{
						return item.size > 10*1024*1024
					})
					if(item){
						uni.showToast({
							title:'图片大小不得高于10M',
							icon:"none"
						})
						return;
					}
					uni.showLoading({
						title: "上传中"
					});
					uni.uploadFile({
						url: getApp().globalData.api_root + '/upload', //接口地址
						filePath: res.tempFilePaths[0],
						name: 'file',
						success: (res) => {
							let data = JSON.parse(res.data);
							uni.hideLoading();
							if(data.code == 200){
								_this.fareImg = data.msg;
								// uni.showToast({
								// 	 icon: 'none',
								// 	 title: data.msg
								// }); 
							}else {
								_this.value.pop();
								uni.showToast({
									 icon: 'none',
									 title: data.msg
								}); 
							}
						}
					});
				}
			})
		},
    }
};
</script>
<style>
@import './index.css';
</style>
