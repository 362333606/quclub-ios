<template>
	
	<view class="contain" >
		<view class="info-tip">
			<view class="info-tip-img">
				 <image src="/static/images/nav/gb.png" class="no-order-img"></image>
			</view>
			<view class="info-tip-msg">
				<text v-if="titleType == 2">营销分佣月/1-30单以内分佣10%；30-50单分佣15%；50单以上分佣20%</text>
				<text v-if="titleType == 4">合伙人可代理多个城市且启动资金不得低于5万</text>
				<text v-if="titleType == 3">有效陪玩搭档成员大于5人，每单可分佣52元；有效陪玩搭档大于10人，每单分佣88元；有效陪玩搭档大于20人，每单分佣108元</text>
			</view>
		</view>
		<view class="info-title">
			<view class="info-title-m">基础资料</view>
			<view class="info-title-b">(请真实填写信息资料)</view>
		</view>
		<view class="info-input">
			<view class="title">姓名</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.name" value=""  placeholder="请输入昵称"/></view>
		</view>
		<view class="info-input">
			<view class="title">电话</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.phone" value=""  placeholder="请输入电话"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">性别</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.sex" value=""  placeholder="请输入性别"/></view>
		</view>
		
		<view class="info-input" v-if="titleType == 4">
			<view class="title">年龄</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.age" value=""  placeholder="请输入年龄"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">城市</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.city" value=""  placeholder="请输入城市"/></view>
		</view>
		
		<view class="info-input" v-if="titleType == 4">
			<view class="title">加盟城市</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.joinCity" value=""  placeholder="请输入加盟城市"/></view>
		</view>
		
		<view class="info-input" v-if="titleType == 4">
			<view class="title">加盟预算</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.budget" value=""  placeholder="请输入加盟预算"/></view>
		</view>
		
		<view class="info-input" v-if="titleType == 4">
			<view class="title" style="width: 50%;">是否有合伙人共同经营</view>
			<view class="input" style="width: 50%;"><input type="text" class="apply_input" v-model="form.jointOperation" value=""  placeholder="请输入是否"/></view>
		</view>
		
		<view class="info-input" v-if="titleType == 2 || titleType == 3">
			<view class="title">目前职业</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.job" value=""  placeholder="请输入职业"/></view>
		</view>
		<view class="info-input" v-if="titleType == 2">
			<view class="title">客户群体</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.customerGroup" value=""  placeholder="请输入客户群体"/></view>
		</view>
		
		
		<view class="info-title">
			<view class="info-title-m">个人简介</view>
		</view>
		<view class="info-content">
			<textarea v-model="form.remark" placeholder="请输入个人简介" />
		</view>
		
		<view class="form-submit">
		    <button formType="submit" type="primary" class="submit" @tap="submitApply()">确定提交</button>
		</view>
		
	</view>
	
</template>

<script>
// pages/search/search.js
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const TOOLS = require('../../utils/tools');
export default {
    components: {
    },
    data() {
        return {
			headerTitle: '陪玩搭档',
			titleType: 0,
			image_list:[],
			
			form: {
				name:'',
				phone:'',
				city:'',
				sex:'',
				age:'',
				job:'',//职业
				joinCity:'',
				budget:'',//预算
				jointOperation:'',//共同经营
				remark:'',
				customerGroup:'',//客户群体
			}
        };
    },
	
	
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
		if (options?.type) {
			this.titleType = options.type;
			let barTitle = "xxx";
			switch (this.titleType) {
			  case '1':
				barTitle = '陪玩搭档';
				break;
			  case '2':
				barTitle = '营销搭档';
				break;
			  case '3':
				barTitle = '人力搭档';
				break;
			  case '4':
				barTitle = '合伙人搭档';
				break;
			}
		   this.headerTitle = barTitle;
		}
	},
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
		uni.setNavigationBarTitle({
			title: this.headerTitle
		});
	},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
	
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {},
	
    methods: {
        
		submitApply(){

			let _this = this;
			
			if (_this.form.name =='') {
				uni.showToast({icon: 'none',title: '请填写姓名'}); 
			    return false;
			} 
			if (_this.form.phone =='') {
				uni.showToast({icon: 'none',title: '请填写电话'}); 
			    return false;
			} 
			if (_this.form.sex =='') {
				uni.showToast({icon: 'none',title: '请填写性别'}); 
			    return false;
			} 
			if (_this.form.city =='') {
				uni.showToast({icon: 'none',title: '请填写城市'}); 
			    return false;
			} 
			
			if (_this.form.remark =='') {
				uni.showToast({icon: 'none',title: '请填写个人简介'}); 
			    return false;
			} 
			_this.form.type = _this.titleType;
			WXAPI.postPartner(_this.form).then((result) => {
				if(result.code == 200){
					uni.showToast({
						 icon: 'none',
						 title: '申请成功'
					}); 
					setTimeout(() => {
						uni.hideToast();
						//关闭提示后跳转
						uni.navigateTo({
							url: "/pages/my/index"
						});
					  }, 2000);
				}
			});
		}
    }
};
</script>
<style>
@import './index.css';
</style>
