<template>
    <view class="goods-container">
		
		<!-- 自定义导航栏 -->
		<view class="gc-head" :style="{ 'padding-top' : statusBarHeight == 0 ? 30 : statusBarHeight +'px',  }">
			<view class="gc-head-title" @click="returns()">取消</view>
			<view class="gc-head-img">
				<image :src="imagebaseurl + pic" v-if="pic"></image>
				发布动态
			</view>
			<view class="gc-post-btn" style="text-align: right" @click="submit()">
				<image src="/static/images/nav/post_palza.png"></image>
			</view>
		</view>
		
		<view class="uni-textarea">
			<textarea v-model="plazaForm.content" placeholder="说点什么,让大家看到不一样的..." maxlength="120" />
		</view>
		
		<upload_video :imgsUrl.sync="plazaForm.imgs" v-if="type == 1"></upload_video>
		<upload_img :imgsUrl.sync="plazaForm.imgs" v-else></upload_img>
		
		<view class="post-menu">
			<view class="post-menu-item" @click="openPopup(0)">
				<image src="/static/images/nav/project.png"></image>
				<text class="post-menu-item-name">约玩项目</text>
				<text class="post-menu-item-desc">
					<text style="margin-right: 20rpx;" v-if="plazaForm.projectId == 0">选择合适的活动吸引TA的第一步</text>
					<text style="margin-right: 20rpx;" v-else>{{plazaForm.projectName}}</text>
					<image class="arrow-right" src="/static/images/arrow-right.png"></image>
				</text>
			</view>
			<view class="post-menu-item" @click="openPopup(1)">
				<image src="/static/images/nav/tags.png"></image>
				<text class="post-menu-item-name">个性标签</text>
				<text class="post-menu-item-desc">
					<text style="margin-right: 20rpx;" v-if="plazaForm.tags.length == 0">选择合适的标签更受异性的喜爱</text>
					<text style="margin-right: 20rpx;" v-else>{{plazaForm.tags.toString()}}</text>
					<image class="arrow-right" src="/static/images/arrow-right.png"></image>
				</text>
			</view>
			<view class="post-menu-item" @click="openPopup(2)">
				<image src="/static/images/nav/time.png"></image>
				<text class="post-menu-item-name">今日有空</text>
				<text class="post-menu-item-desc">
					<text style="margin-right: 20rpx;" v-if="plazaForm.time == ''">选择合适的时间开启你们的邂逅</text>
					<text style="margin-right: 20rpx;" v-else>{{plazaForm.date}} {{plazaForm.time}}</text>
					<image class="arrow-right" src="/static/images/arrow-right.png"></image>
				</text>
			</view>
		</view>
		
		<view class="show-popup" v-if="!popup[0]">
			<view class="popup-mask" @click="closePopup(0)"></view>
			<view class="popup-contents">
				<project_list @toConfirm="serveConfirm" @toCancel="closePopup(0)" :serveId="sid"></project_list>
			</view>
		</view>
		
		<view class="show-popup" v-if="!popup[1]">
			<view class="popup-mask" @click="closePopup(1)"></view>
			<view class="popup-contents">
				<view class="popup-title">
					<text class="popup-cancel" @click="closePopup(1)">取消</text>
					<text class="popup-title-text">个性选择</text>
					<text class="popup-ok-btn" @click="popupConfirm(1)">确认</text>
				</view>
				<view class="tags-list">
					<view class="tags-title-text">已选择标签({{plazaForm.tags.length}}/3)</view>
					<view class="select-tags">
						<text class="select-tag tag-item" v-for="tag in plazaForm.tags" @click="chooseTags(tag)">{{tag}} x</text>
					</view>
				</view>
				<view class="tags-list">
					<view class="tags-title-text">全部标签</view>
					<view class="select-tags">
						<text class="tag-item" 
						v-for="tag in tagLists"
						:class="plazaForm.tags.includes(tag) ? 'select-tag' : 'default'" 
						@click="chooseTags(tag)">{{tag}}</text>
					</view>
				</view>
			</view>
		</view>
		
		<view class="show-popup" v-if="!popup[2]">
			<view class="popup-mask" @click="closePopup(2)"></view>
			<view class="popup-contents">
				<time_list @toConfirm="timeConfirm" @toCancel="closePopup(2)"></time_list>
			</view>
		</view>
		

    </view>
</template>

<script>
//index.js
//获取应用实例
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
const tools = require('../../utils/tools.js');
import project_list from '@/components/project_list.vue';
import time_list from '@/components/time_list.vue';
import upload_img from '@/components/upload_img.vue';
import upload_video from '@/components/upload_video.vue';
export default {
	components: {
		project_list,
	    time_list,
		upload_img,
		upload_video
	},
    data() {
        return {
            wxlogin: false,
            favList: '',
            loadingMoreHidden: false,
			popup: [true, true, true],
			tagLists:[],
			sid:0,
			time:'',
			pic:'',
			plazaForm:{
				content:'',
				projectId:0,
				projectName:'',
				tags:[],
				imgs:[],
				date:'',
				time:'',
			},
			imagebaseurl: getApp().globalData.fileDomain,
			statusBarHeight: (typeof getApp().globalData.statusBarHeight === "number") ? getApp().globalData.statusBarHeight : 0,
			type:0,
        };
    },
    onShow: function () {
		this.getTagList();
		this.pic = uni.getStorageSync('user_pic');
    },
	async onLoad(e) {
		this.type = e.type
	},
    methods: {
        afterAuth(e) {
            this.setData({
                wxlogin: true
            });
        },
		serveConfirm: function(serve) {
			if (!serve) {
				uni.showToast({icon: 'none',title: '请选择项目'});
				return false;
			}
			this.plazaForm.projectId = serve.id;
			this.plazaForm.projectName = serve.title;
			this.sid = serve.id;
			this.popup[0] = true;
			this.$forceUpdate();
		},
		popupConfirm: function(i) {
			this.popup[i] = true;
			this.$forceUpdate();
		},
		chooseTags: function(tag) {
			if (this.plazaForm.tags.includes(tag)) {
				this.plazaForm.tags = this.plazaForm.tags.filter(function(item) {
				  return item !== tag;
				});
			} else {
				if (this.plazaForm.tags.length == 3) {
					uni.showToast({icon: 'none',title: '最多选3个标签哦'}); 
					return;
				}
				this.plazaForm.tags.push(tag);
			}
		},
		openPopup: function(i) {
			this.popup[i] = false;
			this.$forceUpdate();
		},
		closePopup: function(i) {
			this.popup[i] = true;
			this.$forceUpdate();
		},

        closeAuth() {
            uni.navigateBack();
        },
		// 返回的箭头
		returns(){
			uni.navigateBack({
				delta: 1  //返回上一页
			});
		},
		timeConfirm(date,time){
			if (date == null) {
				uni.showToast({icon: 'none',title: '请选择日期'});
				return false;
			}
			if (time == null) {
				uni.showToast({icon: 'none',title: '请选择时间'});
				return false;
			}
			this.plazaForm.date = date;
			this.plazaForm.time = time;
			this.popup[2] = true;
			this.$forceUpdate();
		},
		getTagList(){
			WXAPI.tagList().then((res) => {
				if(res.code==200){
					this.tagLists = res.data;
				}
			});
		},
		 // 发布
		submit(){
			var loginToken = uni.getStorageSync('bestpw-Token');
			if (!loginToken) {
			    uni.showModal({
			        title: '友情提示',
			        content: '用户未登录，请登录后再操作！',
			        showCancel: false
			    });
			    return;
			}
			if (this.plazaForm.content =='') {
				uni.showToast({icon: 'none',title: '内容不能为空'}); 
			    return false;
			} 
			// if (this.plazaForm.projectId == '') {
			// 	uni.showToast({icon: 'none',title: '请选择约玩项目'});
			// 	return false;
			// }
			// if (this.plazaForm.date == '' || this.plazaForm.time == '') {
			// 	uni.showToast({icon: 'none',title: '请选择约玩时间'});
			// 	return false;
			// }
			this.plazaForm.city = uni.getStorageSync('cityindex');
			uni.showLoading();
			WXAPI.postPlaza(this.plazaForm).then((res) => {
				uni.hideLoading();
				if(res.code==200){
					uni.showToast({
						 title: '发布成功'
					}); 
					setTimeout(() => {
						uni.hideToast();
						//关闭提示后跳转
						uni.navigateTo({
							url: "/pages/plaza-list/index"
						});
					  }, 1500);
				} else {
					uni.showToast({
						 icon: 'none',
						 title: res.msg
					}); 
				}
			});
		},
		
    }
};
</script>
<style>
@import './index.css';
</style>
