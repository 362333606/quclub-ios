<template>
    <view style="height: 100%">
        <swiper class="swiper_box" @change="swiperchange" :indicator-dots="true" indicator-active-color="#fff">
            <swiper-item v-for="(item, index) in banners" :key="index">
                <image mode="aspectFill" @tap="imgClick" :src="item.picUrl" />
            </swiper-item>
        </swiper>
        <view class="btn">
            <button v-if="swiperCurrent + 1 == swiperMaxNumber" type="primary" size="mini" @tap="goToIndex" class="cu-btn bg-green round">立即体验</button>
        </view>
    </view>
</template>

<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const CONFIG = require('../../config.js');
//获取应用实例
var app = getApp();
export default {
    data() {
        return {
            banners: [],
            swiperMaxNumber: 0,
            swiperCurrent: 0
        };
    },
    onLoad: function () {
        const that = this;
        uni.setNavigationBarTitle({
            title: uni.getStorageSync('mallName')
        });
        const app_show_pic_version = uni.getStorageSync('app_show_pic_version');
        if (app_show_pic_version && app_show_pic_version == CONFIG.version) {
            uni.switchTab({
                url: '/pages/index/index'
            });
        } else {
            // 展示启动页
           
        }
    },
    onShow: function () {},
    methods: {
        swiperchange: function (e) {
            //console.log(e.detail.current)
            this.setData({
                swiperCurrent: e.detail.current
            });
        },

        goToIndex: function (e) {
            if (app.globalData.isConnected) {
                uni.setStorage({
                    key: 'app_show_pic_version',
                    data: CONFIG.version
                });
                uni.switchTab({
                    url: '/pages/index/index'
                });
            } else {
                uni.showToast({
                    title: '当前无网络',
                    icon: 'none'
                });
            }
        },

        imgClick() {
            if (this.swiperCurrent + 1 != this.swiperMaxNumber) {
                uni.showToast({
                    title: '左滑进入',
                    icon: 'none'
                });
            }
        }
    }
};
</script>
<style>
@import './start.css';
</style>
