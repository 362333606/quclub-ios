<template>
	
	<view class="contain" >
		
		<view class="info-title">
			<view class="info-title-m">个人信息</view>
		</view>
		
		<view class="info-input">
			<view class="title">姓名</view>
			<view class="input"><input type="text" class="apply_input" v-model="best.name" value=""  placeholder="请输入昵称"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">年龄</view>
			<view class="input"><input type="text" class="apply_input" v-model="best.age" value=""  placeholder="请输入年龄"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">身高</view>
			<view class="input"><input type="text" class="apply_input" v-model="best.height" value=""  placeholder="请输入身高 单位cm"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">体重</view>
			<view class="input"><input type="text" class="apply_input" v-model="best.weight" value=""  placeholder="请输入体重 单位kg"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">微信号</view>
			<view class="input"><input type="text" class="apply_input" v-model="best.wechat" value=""  placeholder="请输入微信号"/></view>
		</view>
		
		<!-- <view class="info-input">
			<view class="title">电话</view>
			<view class="input"><input type="text" class="apply_input" v-model="best.phone" value=""  placeholder="请输入电话"/></view>
		</view> -->
		
		<view class="info-input">
			<view class="title">城市</view>
			<view class="input">
				<uni-data-select
				      v-model="best.city"
				      :localdata="cityData"
					  placeholder="请选择城市"
					  :clear="false"
				    ></uni-data-select>
				<!-- <input type="text" class="apply_input" v-model="best.city" value=""  placeholder="请输入城市"/> -->
				</view>
		</view>
		
		<view class="info-input">
			<view class="title">星座</view>
			<view class="input"><input type="text" class="apply_input" v-model="best.constellation" value=""  placeholder="请输入星座"/></view>
		</view>
		
		<view class="info-title">
			<view class="info-title-m">个人签名</view>
		</view>
		<view class="info-content">
			<textarea v-model="best.remark" placeholder="说点什么,让大家看到不一样的..." />
		</view>
		
		<view class="info-title">
			<view class="info-title-m">封面照片</view>
		</view>
		
		<view class="upload-content">
			<view class="upload-item" style="position: relative;" v-if="pic">
				<image mode="aspectFill" class="uploadImage" :src="imagebaseurl+pic" style="width: 100%;height: 100%;" @click="preview(item,pic)"></image>
				<uni-icons type="close" size="30" color="#red" class="clearDiv" @click="delimg(99)"></uni-icons>
			</view>
			<view class="upload-item" @click="upLoadPhoto(1)" v-if="!pic">
				<uni-icons type="camera-filled" size="45" color="#c5d8f3"></uni-icons>
				<view class="upload-text">上传图片</view>
			</view>
		</view>
		
		<view class="info-title">
			<view class="info-title-m">个人照片</view>
			<view class="info-title-b">(建议自拍全身 半身照素材越全面越容易接到订单哦)</view>
		</view>
		
		<view class="upload-content">
			<view class="upload-item" v-for="(item, i) in imgs" :key="i" style="position: relative;">
				<image class="uploadImage" mode="aspectFill" :src="imagebaseurl+item" style="width: 100%;height: 100%;" @click="preview(item,imgs)"></image>
				<uni-icons type="close" size="30" color="#red" class="clearDiv" @click="delimg(i)"></uni-icons>
			</view>
			<view class="upload-item" @click="upLoadPhoto(2)" v-if="imgs.length < 9">
				<uni-icons type="camera-filled" size="45" color="#c5d8f3"></uni-icons>
				<view class="upload-text">上传图片</view>
			</view>
		</view>
		
		<view class="info-title">
			<view class="info-title-m">个人视频</view>
			<view class="info-title-b">(建议上传30秒以内的视频)</view>
		</view>
		
		<view class="upload-content">
			
			<view class="upload-item" style="position: relative;" v-if="video" @click="preview(video,video)">
				<video id="myVideo"
				:src="imagebaseurl+video"
				:poster="imagebaseurl + video + '?x-oss-process=video/snapshot,t_0,f_jpg'"
				:enable-progress-gesture="false" :controls="false" @play="pay"></video>
				<uni-icons type="close" size="40" color="#ccc" class="clearVideoDiv" @click="delVideo"></uni-icons>
			</view>
			<view class="upload-item" @click="upLoadVideo()" v-if="!video">
				<uni-icons type="camera-filled" size="45" color="#c5d8f3"></uni-icons>
				<view class="upload-text">上传视频</view>
			</view>
		</view>
		
		
		<view class="form-submit">
		    <button formType="submit" type="primary" class="submit" @tap="submitApply()">提交</button>
		</view>
		
		<q-previewImage ref="previewImage" :urls="image_list"></q-previewImage>
		
	</view>
	
</template>

<script>
// pages/search/search.js
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const TOOLS = require('../../utils/tools');
export default {
    components: {
    },
    data() {
        return {
			best: {
				id:0,
				name:'',
				// phone:'',
				height:'',
				weight:'',
				wechat:'',
				city:'',
				remark:'',
				age:'',
				constellation:'',
			},
			image_list:[],
			imagebaseurl: getApp().globalData.fileDomain,
			pic:'',
			imgs:[],
			video:'',
			videoContext:'',
			cityData: [],
			// selectedValue:''
        };
    },
	watch: {
		imgs(newValue, oldValue) {
			console.log('值发生了变化:', newValue);
	
			this.$emit('update:imgsUrl', newValue)
			if(newValue.length == 9) {
				this.upload = false;
			} else {
				this.upload = true;
			}
		}
	},
	
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
		this.videoContext = uni.createVideoContext('myVideo');
		this.getCity();
		WXAPI.bestAlbum().then((res) => {
		    if (res.code == 200) {
				this.pic = res.data.pic;
				this.best = res.data.best;
				if (res.data.imgs) {
					res.data.imgs.forEach((item,index)=>{
						if (item.includes('video')) {
							this.video = item;
						} else {
							this.imgs.push(item);
						}
					});
				}
		    }
		});
	},
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
		uni.showLoading({
		    title: '加载中'
		});
		WXAPI.bestAlbum().then((res) => {
		    if (res.code == 200) {
				this.pic = res.data.pic;
				this.img = res.data.imgs;
		    } else {
				uni.navigateTo({
					url:'/pages/index/index'
				})
			}
		});
		uni.hideLoading();
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {},
	
    methods: {
		getCity() {
			let _this = this;
			WXAPI.citys().then((res) => {
				if(res.code == 200){
					let array = res.data;
					for(var key in array){
						_this.cityData.push({
							"value": array[key].title,
							"text": array[key].title
						})
					}
				}
			});
		},
		changeCity(e) {
			console.log("e:", e.target.value);
			// this.postForm.city = this.cityData[e].value;
		  },
		preview(url, imgs) {
			this.image_list = [];
			if (typeof(imgs) == 'string') {
				this.image_list.push(imgs);
			} else {
				this.image_list = imgs;
			}
			console.info(this.image_list);
		    this.$refs.previewImage.open(url); // 传入当前选中的图片地址
		},
		delVideo(){
			this.video = '';
		},
		pay() {
			this.videoContext.pause();;
		},
		delimg(i){
			if (i == 99) {
				this.pic = ''
			} else {
				this.imgs.splice(i, 1);
			}
		},
		upLoadVideo() {
			let _this = this;
			uni.chooseVideo({
				maxDuration: 30,
			    sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
			    sourceType: ['album'], //从相册选择
			    success: function(res) {
					
					let videoFile = res.tempFilePath;
					if (res.size > 50*1024*1024) {
						uni.showToast({
							title:'视频大小不得高于50M',
							icon:"none"
						})
						return;
					}
					uni.showLoading({
						title: "上传中"
					});
					uni.uploadFile({
						url: app.globalData.api_root + '/upload', //接口地址
						filePath: videoFile,
						name: 'file',
						formData:{  //后台所需除图片外的参数可以写在这里面 ，单张多张都可
						    "type": 2, 
						},
						success: (res) => {
							let data = JSON.parse(res.data);
							uni.hideLoading();
							if(data.code == 200){
								_this.video = data.msg;
							}else {
								uni.showToast({
									 icon: 'none',
									 title: data.msg
								}); 
							}
						}
					});
				}
			})
		},
		upLoadPhoto(n){
			if(n == 2 && this.imgs.length >= 9){
				uni.showToast({
					title:'图片最多上传9张'
				})
				return;
			}
			let _this = this;
			uni.chooseImage({
			    count: 4,
			    sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
			    sourceType: ['album'], //从相册选择
			    success: function(res) {
					
					if(n == 2 &&  _this.imgs.length + res.tempFilePaths.length > 9){
						uni.showToast({
							title:'图片数量不能大于9张',
							icon:'none'
						})
						return;
					}
					var item = res.tempFiles.find(item=>{
						return item.size > 10*1024*1024
					})
					if(item){
						uni.showToast({
							title:'单张图片大小不得高于10M',
							icon:"none"
						})
						return;
					}
					
					const tempFilePaths = res.tempFilePaths;
					uni.showLoading({
						title: "上传中"
					});
					
					 for (let i = 0; i < tempFilePaths.length; i++) {
						 
						uni.uploadFile({
							url: app.globalData.api_root + '/upload', //接口地址
							filePath: tempFilePaths[i],
							name: 'file',
							formData:{  //后台所需除图片外的参数可以写在这里面 ，单张多张都可
							    //"token": uni.getStorageSync('bestpw-Token'), 
							},
							success: (res) => {
								
								let data = JSON.parse(res.data);
								uni.hideLoading();
								if(data.code == 200){
									if (n == 1) {
										_this.pic = data.msg;
									} else {
										_this.imgs.push(data.msg);
									}
								}else {
									_this.value.pop();
									uni.showToast({
										 icon: 'none',
										 title: data.msg
									}); 
								}
							}
						});
					 }
				}
			})
		},
        
		submitApply(){

			let _this = this;
			let param = {};
			if (this.pic == '') {
				uni.showToast({icon: 'none',title: '请上传封面图'});
				return false;
			}
			// this.best.find
			Object.assign(param, this.best);
			param.pic = this.pic;
			param.imgs = this.imgs;
			param.video = this.video;
			// param.best = JSON.stringify(this.best);
			uni.showLoading();
			WXAPI.bestSaveAlbum(param).then((result) => {
				uni.hideLoading();
				if(result.code == 200){
					uni.showToast({
						 title: '提交成功'
					}); 
					setTimeout(() => {
						uni.hideToast();
						//关闭提示后跳转
						uni.navigateTo({
							url: "/pages/my/index"
						});
					  }, 2000);
				}
			});
		}

       
    }
};
</script>
<style>
@import './album.css';
</style>