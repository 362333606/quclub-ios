<template>
    <view style="height: 100%">
        
        <navigator :url="'/pages/activity/detail?id=' + item.id" v-for="(item, index) in activity_list" :key="index">
			
            <view class="list1 shadow bg-white">
				
				<view style="height: 140px;">
					<image class="img" mode="aspectFill" :src="item.img" style="float: left;"></image>
					
					<view class="goods-info" style="float: left;">
						<view class="address" style="font-size: 16px;font-weight: bolder;">{{ item.name }}</view>
						
						<view class="address" style="font-size: 12px;">{{item.number}}<text class="item-time" v-if="item.time != ''">{{item.time}}</text></view>
						<!-- <view class="address" style="font-size: 12px;">{{item.time}}</view> -->
						<view class="num" v-if="item.label != ''">
							<text class="info-desc" v-for="(mk,index) in (item.label || '').split('|')">{{mk}}</text>
						</view>
						<view style="font-size: 12px;white-space:nowrap;text-overflow: ellipsis;">{{item.represent}}</view>
					</view>
				</view>
				<view style="margin-top: 20px;">
					<view style="border-bottom: 0.5px solid black;width: 78%;"></view>
					<view style="float: right;margin-top: -10px;font-size: 12px;color: black;margin-right: 20rpx;">{{ item.num }}人已拼成</view>
				</view>
				<view class="address" style="margin-top: 15px;display: flex;width: 100%;">
					<view class="item-btn-msg">{{ item.from_dt }} 至 {{ item.end_dt }} </view>
						<!-- <view class="list-one" v-if="item.is_over == 1"><view class="btn_in">进行中</view></view> -->
						<!-- <view class="list-one" v-else><view class="btn_end">已结束</view></view> -->
						
					<view class="list-one" v-if="item.is_join == 1"><view class="btn_join_in">已参与</view></view>
					<view class="list-one" v-else><view class="btn_join">未参与</view></view>
				</view>
            </view>
        </navigator>

        <view v-if="activity_list.length == 0" class="no-more-goods">
            <image src="/static/images/empty_goods.png" class="no-order-img"></image>
            <view class="text">没有活动</view>
        </view>
		
    </view>
</template>

<script>
const app = getApp();
export default {
    data() {
        return {
            //活动列表
            activity_list: [],
        };
    },
    onLoad: function (options) {
        
        this.search();
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {},
    methods: {
       
        async search() {
            
            uni.showLoading({
                title: '加载中'
            });
			
			var loginToken = uni.getStorageSync('bestpw-Token');
			
			let url =  app.globalData.api_root + 'fireshop/activity/my';
				
			app.globalData._post_form(url, {
				token:loginToken
			}, result => {
				 console.log(result);
				 if(result.code == 1){
					this.activity_list = result.data;
				 }
				 uni.hideLoading();
			});
			
        },

        
    }
};


	
</script>
<style>
@import './activity.css';
</style>

