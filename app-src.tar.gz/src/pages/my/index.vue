<style>
	.cu-item image{
		margin-right: 20rpx!important;
		width:20px!important;
		height: 20px!important;
	}
	.cu-item:after{
		border-bottom: 0px !important;
	}
	.cu-list.menu>.cu-item{
		padding: 0px;
		background-color: transparent !important;
	}

	.cu-list.grid{
		background-color: #fcfcfc;
	}

	.cu-list.grid.no-border{
		padding: 0px;
	}
	.cu-list.grid>.cu-item{
		display: block;
	}

	.cu-item.arrow:before{
		right: 0px !important;
	}
	.text-grey{
		color: black;
		font-size: 28rpx;
	}
</style>
<template>
    <view class="container">
        <view class="userinfo" v-if="userInfoStatus == 2">
            <view class="userinfo-inner">
                <!-- <open-data class="userinfo-avatar" type="userAvatarUrl"></open-data> -->
				<image :src="imagebaseurl + pic" class="userinfo-avatar" v-if="pic" @click="upLoadPhoto()"></image>
                <view class="iser-info-box">
                    <view class="userinfo-nickname" v-if="userInfoStatus == 2" @click="updateName()">
                        <text>{{nick}}</text>
                    </view>
					<view class="status-switch" v-if="best_id > 0">在线<switch color="#a9d8f0" :checked="isSwitchOn" @change="switchChange" style="transform: scale(0.6,0.5)"></switch></view>
                </view>
            </view>
            <!-- <image src="/static/images/user-bg.jpg"></image> -->
        </view>
		 <view class="login-btn" v-else @tap="updateUserInfo">立即登录</view>
		 
		 <view class="my-content">
			 <view class="userinfo-item" @tap="navigateToPage" data-url="/pages_order/order-list/index">
				 <image class="item-icon" src="/static/images/nav/all_order.png"></image>
				 <text class="user-title-item">我的订单</text>
				 <image class="arrow-right" src="/static/images/arrow-right.png"></image>
			 </view>
			 <view class="userinfo-item" style="margin-top: 20rpx;background-image: url(static/images/bg/my_bg1.png);background-size: 100% 100%;background-color: transparent;box-shadow:none;" @tap="navigateToPage" data-url="/pages_partner/types/index">
				 <image class="item-icon" src="/static/images/nav/crown.png"></image>
				 <text class="user-title-item">申请成为搭档</text>
				 <image class="arrow-right" src="/static/images/arrow-right.png"></image>
			 </view>
			 
			 <view class="my-icon-menu">
				 <view class="cu-load loading" style="height: 300rpx;" v-if="navMenu.length == 0"></view>
				 <view class="my-icon-menu-item" @tap="navigateToPage" :data-url="item.link" v-for="(item, index) in navMenu">
					 <view class="my-icon-menu-img">
						 <image :src="imagebaseurl + item.img" />
					 </view>
					 <text>{{item.title}}</text>
				 </view>
			 </view>
			 
			 <view class="my-menu">
			 	
			 	<view class="cu-list menu sm-border" style="width: 100%">
			 		
			 		<view class="cu-item arrow">
			 		    <navigator class="content" url="/pages/news/index?id=8" hover-class="none">
			 		        <image src="/static/images/nav/help.png"></image>
			 		        <text class="text-grey">用户帮助</text>
			 		    </navigator>
			 		</view>
			 		
			 		<view class="cu-item arrow">
			 		    <navigator class="content" url="/pages/news/index?id=7" hover-class="none">
			 		        <image src="/static/images/nav/about.png"></image>
			 		        <text class="text-grey">关于我们</text>
			 		    </navigator>
			 		</view>
					
					<view class="cu-item arrow">
					    <navigator class="content" url="/pages/none" @tap="openAppDownloadLink" hover-class="none">
					        <image src="/static/images/nav/app1.png" style="width: 18px !important;height: 18px !important;"></image>
					        <text class="text-grey">App下载</text>
					    </navigator>
					</view>
			 		
			 		<view class="cu-item arrow">
			 		    <navigator class="content" url="/pages_invite/index" hover-class="none">
			 		        <image src="/static/images/nav/invite.png"></image>
			 		        <text class="text-grey">邀请好友一起来玩吧</text>
			 		    </navigator>
			 		</view>
					
			 		<view class="cu-item arrow" v-if="userInfoStatus == 2">
			 		    <navigator class="content" @click="logout" hover-class="none">
			 		        <image src="/static/images/nav/exit.png"></image>
			 		        <text class="text-grey">退出登录</text>
			 		    </navigator>
			 		</view>
			 		
			 	</view>
			 </view>
			 
			 <!-- <view class="banner-bottom">
				 防诈骗公告
			 </view> -->
			 <view class="swiper-container">
			     <swiper :class="'screen-swiper ' + (dotStyle ? 'square-dot' : 'round-dot')" :circular="true" :autoplay="true" :indicator-dots="true" interval="5000" duration="500">
			         <swiper-item @tap="tapNav" :data-url="item.link" v-for="(item, index) in banners" :key="index">
			             <image :src="imagebaseurl + item.img"></image>
			         </swiper-item>
			     </swiper>
			 </view>
		 </view>
		 <uni-popup ref="inpuAlipayDialog" type="dialog">
		 	<uni-popup-dialog ref="inputClose"  mode="input" title="修改昵称" :value="nick"
		 		placeholder="请输入昵称" @confirm="updateConfirm">
		 	</uni-popup-dialog>
		 </uni-popup>
		
		

		
      
    </view>
</template>

<script>
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const CONFIG = require('../../config.js');
const TOOLS = require('../../utils/tools.js');
const AUTH = require('../../utils/auth');
export default {
    data() {
        return {
            balance: 0,
            userInfo: null,
            token: null,
            version: null,
            loaded: false,
			imagebaseurl: getApp().globalData.fileDomain,
            // 0 未读取 1 没有详细信息 2 有详细信息
            userInfoStatus: 0,
			nick:'小恩熙',
			pic:'/static/images/ic_logo.png',
            notransfer: '',
            noconfirm: '',
            noreputation: '',
			best_id: 0,
			type: 0,
			navMenu:[],
			isSwitchOn: true,
			banners: [],
			dotStyle: 'square-dot',
        };
    },
    onLoad: function () {
        this.initPage();
    },
    onShow() {
        AUTH.checkHasLogined().then((isLogined) => {
            console.log('----------1. check login---------------------');
            if (isLogined) {
                this.getUserApiInfo();
                //	this.checkScoreSign()
                this.setData({
                    loaded: true
                });
            } else {
                console.log('----------2. No login ---------------------');
                AUTH.authorize().then((res) => {
                    console.log('----------3. start getUserApiInfo ---------------------');
                    this.getUserApiInfo();
                    //this.checkScoreSign()
                    this.setData({
                        loaded: true
                    });
                });
            }
        });
        this.setData({
            version: CONFIG.version
        });
        //更新订单状态
    },
    methods: {
		// 打开外部链接
		openAppDownloadLink() {
			window.location.href = 'https://top.qiuyu8.cn/download';
		},
		tapNav(e) {
		    const url = e.currentTarget.dataset.url;
		    uni.navigateTo({
		        url: url
		    });
		},
		switchChange(event) {
		    this.isSwitchOn = event.detail.value;
			let isSwitchOn = this.isSwitchOn ? 1 : 2;
			WXAPI.bestStatus({status: isSwitchOn}).then((res) => {
			    if (res.code == 200) {
					uni.showToast({
					    title: '设置成功'
					});
			    }
			});
		  },
		async initPage() {
		    uni.showLoading();
			//获取轮播
			const navRes = await WXAPI.menuList({type: 6});
			if (navRes.code == 200) {
			    this.navMenu = navRes.data;
			} 
			//获取轮播
			const bannerRes = await WXAPI.menuList({type: 1});
			if (bannerRes.code == 200) {
			     this.banners = bannerRes.data;
			}
		    uni.hideLoading();
		},
        logout(){
			uni.removeStorageSync('bestpw-Token');
			uni.removeStorageSync('best_id');
			uni.removeStorageSync('user_pic');
			uni.removeStorageSync('user_op');
			uni.showToast({
			    title: '退出成功'
			});
			
			setTimeout(function () {
				window.location.reload();
			}, 1000);
        },
        updateUserInfo(e) {
			this.isWeiXinLogin() ? window.location.href = "/#/pages/login/index" : uni.navigateTo({url: "/pages/login/login"})
        },
		isWeiXinLogin() {
		    var ua = window.navigator.userAgent.toLowerCase();
		    if (ua.match(/MicroMessenger/i) == 'micromessenger') {
		        return true; // 微信中打开
		    } else {
		        return false; // 普通浏览器中打开
		    }
		},
        async updateUserInfoFun(userInfo) {
            const postData = {
                
            };
            const res = await WXAPI.userUpdate(postData);
            if (res.code != 0) {
                uni.showToast({
                    title: res.msg,
                    icon: 'none'
                });
                return;
            }
            uni.showToast({
                title: '登陆成功'
            });
            this.getUserApiInfo();
        },

        async getUserApiInfo() {
            console.log('--------getUserApiInfo-------------------------');
            const res = await WXAPI.userDetail();
            let _data = {};
			if (res.data.avatarUrl) {
				_data.pic = res.data.avatarUrl;
			}
            if (res.data.name) {
                _data.userInfoStatus = 2;
				_data.nick = res.data.name;
            } else {
                _data.userInfoStatus = 1;
            }
			_data.best_id = res.data.bestId;
			uni.setStorageSync('bestpw-bestId',res.data.bestId)
			_data.type = res.data.type;
            this.setData(_data);
        },
        navigateToPage(e) {
			AUTH.checkHasLogined().then((isLogined) => {
				if(isLogined) {
					let url = e.currentTarget.dataset.url;
					if (this.best_id == 0 && this.type == 0 && url == "/pages_partner/index") {
						uni.showToast({
						    title: '无权限，请申成为搭档后再继续操作',
						    icon: 'none'
						});
						return;
					}
					if (this.best_id == 0 && (url == '/pages/my/album' || url == '/pages_monad/monad/list')) {
						uni.showToast({
						    title: '无权限，请申成为搭档后再继续操作',
						    icon: 'none'
						});
						return;
					}
					if (url.includes('http')) {
						window.location.href = url;
					} else {
						uni.navigateTo({
						    url: url
						});
					}
				} else {
					uni.showToast({
					    title: '请登录后再操作',
					    icon: 'none'
					});
				}
			})
            
        },
		updateName() {
			this.$refs.inpuAlipayDialog.open();
		},
		updateConfirm(val) {
			let _this = this;
			if (val == '') {
				uni.showToast({title:'昵称不能为空',icon:"none"})
				return;
			}
			WXAPI.userUpdate({name: val}).then((res) => {
				if (res.code == 200) {
				    _this.nick = val;
				    uni.showToast({title: '昵称修改成功'}); 
				}
			});
		},
		upLoadPhoto(){
			let _this = this;
			uni.chooseImage({
			    count: 1,
			    sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
			    sourceType: ['album'], //从相册选择
			    success: function(res) {
					const tempFilePaths = res.tempFilePaths[0];
					if(tempFilePaths.size > 10*1024*1024){
						uni.showToast({title:'图片大小不得高于10M',icon:"none"})
						return;
					}
					uni.showLoading({
						title: "上传中"
					});
					uni.uploadFile({
						url: app.globalData.api_root + '/upload', //接口地址
						filePath: tempFilePaths,
						name: 'file',
						success: (res) => {
							let data = JSON.parse(res.data);
							if(data.code == 200){
								uni.hideLoading();
								WXAPI.userUpdate({pic: data.msg}).then((res) => {
									if (res.code == 200) {
									    _this.pic = data.msg;
									    uni.showToast({title: '头像上传成功'}); 
									}
								});
							}else {
								uni.showToast({icon: 'none',title: data.msg}); 
							}
						}
					});
				}
			})
		},
    }
};
</script>
<style>
@import './index.css';
</style>
