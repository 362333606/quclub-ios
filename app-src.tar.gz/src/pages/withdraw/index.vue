<template>
    <view class="container">
        <view class="tixian-bg">
            <image class="tixian-img" src="/static/images/withdraw.png"></image>
            <view class="tixian-name">
                我的余额
                <text class="money">¥{{ balance }}</text>
                <text class="tips">付款时优先选择余额进行支付</text>
            </view>
        </view>
        <form @submit="bindSave">
            <view class="form-box">
                <view class="row-wrap">
                    <view class="label">提现金额</view>
                    <view class="label-right">
                        <text class="lable-amount">¥</text>
                        <input name="amount" class="input" type="number" />
                    </view>
                    <view class="lable-text">提现金额100元起，1～5个工作日到账</view>
                </view>
            </view>
            <button class="save-btn" formType="submit">确认提现</button>
            <button type="default" class="cancel-btn" @tap="bindCancel">取消</button>
        </form>
    </view>
</template>

<script>
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
export default {
    data() {
        return {
            balance: 0,

            //是否隐藏登录弹窗
            wxlogin: true,

            freeze: ''
        };
    }
    /**
     * 生命周期函数--监听页面加载
     */,
    onLoad: function () {},
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        AUTH.checkHasLogined().then((isLogined) => {
            this.setData({
                wxlogin: isLogined
            });
            if (isLogined) {
                this.getUserBalance();
            }
        });
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {},
    methods: {
        getUserBalance() {
            WXAPI.userAmount(uni.getStorageSync('bestpw-Token')).then((res) => {
                if (res.code == 0) {
                    this.setData({
                        balance: res.data.balance,
                        freeze: res.data.freeze
                    });
                }
            });
        },

        bindCancel: function () {
            uni.navigateBack({});
        },

        bindSave: function (e) {
            var that = this;
            var amount = e.detail.value.amount;
            if (amount == '' || amount * 1 < 100) {
                uni.showModal({
                    title: '错误',
                    content: '请填写正确的提现金额',
                    showCancel: false
                });
                return;
            }
            WXAPI.withDrawApply(uni.getStorageSync('bestpw-Token'), amount).then((res) => {
                if (res.code == 0) {
                    uni.showModal({
                        title: '成功',
                        content: '您的提现申请已提交，等待财务打款',
                        showCancel: false,
                        success: function (res) {
                            if (res.confirm) {
                                that.bindCancel();
                            }
                        }
                    });
                } else {
                    uni.showModal({
                        title: '错误',
                        content: res.msg,
                        showCancel: false
                    });
                }
            });
        }
    }
};
</script>
<style>
@import './index.css';
</style>
