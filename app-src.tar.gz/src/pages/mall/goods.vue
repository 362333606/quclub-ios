<template>
    <view style="height: 100%">
        <view style="padding:10rpx 20rpx;">
			<view class="swiper-container" v-if="banners.length > 0">
			    <swiper class="screen-swiper" :circular="true" :autoplay="true" :indicator-dots="true" interval="5000" duration="500">
			        <swiper-item @tap="tapNav" :data-url="item.link" v-for="(item, index) in banners" :key="index" style="border-radius: 20rpx;">
			            <image :src="imagebaseurl + item.img"></image>
			        </swiper-item>
			    </swiper>
			</view>
			<!-- <image src="/static/images/huodong_banner.jpeg" style="width: 100%;height: 160px;border-radius: 40rpx;"></image> -->
		</view>
		<view class="cate-list">
			<text class="cate-item" :class="cateIndex == 0 ? 'cate-active' : ''" @click="preview('')">全部商品</text>
			<!-- <text class="cate-item" :class="cateIndex == item.id ? 'cate-active' : ''" @click="preview(item.id)" v-for="(item, index) in cate_list" :key="index">
				{{item.title}}
			</text> -->
		</view>
        <navigator style="padding:10rpx 20rpx;" :url="'/pages/mall/goodsDetail?id=' + item.id" v-for="(item, index) in goodsList" :key="index">
			
            <view class="list-item" v-if="item.img != null">
				<view class="list1 shadow">
					<image class="img" mode="aspectFill" :src="imagebaseurl + item.img"></image>
					<view class="goods-info">
						<view class="address" style="font-size: 16px;font-weight: bolder;">{{ item.title }}</view>
						<view class="num" v-if="item.label != ''">
							<text class="info-desc" v-for="(mk,index) in (item.tags || '').split(',')">{{mk}}</text>
						</view>
						<!-- <view style="font-size: 12px;color: white;white-space:nowrap;text-overflow: ellipsis;">{{item.description}}</view> -->
						<view class="goods-price">¥{{item.price}}</view>
					</view>
				</view>
				
				
            </view>
			
        </navigator>
		
		 <view v-if="goodsList.length != 0" :class="'cu-load  ' + (loadingMoreHidden ? 'loading' : 'over')"></view>

        <view v-if="goodsList.length == 0" class="no-more-goods">
            <image src="/static/images/empty_goods.png" class="no-order-img"></image>
            <view class="text">没有商品</view>
        </view>
		
    </view>
</template>

<script>
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
export default {
    data() {
        return {
            //活动列表
            goodsList: [],
			cate_list: [],
			cateIndex : '',
			curPage: 1,
			pageSize: 5,
			totalPages:0,
			banners: [],
			loadingMoreHidden: true,
			imagebaseurl: getApp().globalData.fileDomain,
        };
    },
    onLoad: function (options) {
       
        this.initPage();
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
        // 滚动刷新
		if (this.curPage == this.totalPages) {
			return;
		}
        this.setData({
            curPage: this.curPage + 1
        });
        this.mallGoodsList();
    },
    methods: {
		tapNav(e) {
		    const url = e.currentTarget.dataset.url;
			if (url.includes("http")) {
				// #ifdef H5
				window.location.href = url;
				// #endif
				// #ifdef APP-PLUS
				plus.runtime.openURL(url);
				// #endif
			} else {
				uni.navigateTo({
				    url: url
				});
			}
		},
		async initPage() {
			//获取轮播
			const bannerRes = await WXAPI.menuList({type: 11});
			if (bannerRes.code == 200) {
			     this.banners = bannerRes.data;
			}
			this.balanceList = [];
		    await this.mallGoodsList();
		},
       preview(id){
		   this.cateIndex = id;
		   this.curPage = 1;
		   this.goodsList = []
		   this.mallGoodsList();
	   },
        async mallGoodsList() {
            
            uni.showLoading({
                title: '加载中'
            });
			WXAPI.mallGoodsList({
				pageSize: this.pageSize,
				page: this.curPage,
				categoryId: this.cateIndex
			}).then((res) => {
				
				if(res.code==200){
					var newArray = res.data.goods.content;
					this.goodsList=[...this.goodsList,...newArray]
					this.totalPages = res.data.goods.totalPages;
					this.cate_list = res.data.category;
					this.loadingMoreHidden = false;
				}
				uni.hideLoading();
			});
        },
    }
};
</script>
<style>
@import './goods.css';
</style>

