<template>
    <view style="height: 100%">
        <view class="container">
            <view class="goods-list">
                <view class="list-title">商品信息</view>
                <view class="a-goods">
                    <view class="img-box">
                        <image :src="imagebaseurl + goodsDetail.img" class="img" />
                    </view>

                    <view class="text-box">
                        <view class="arow arow01">
                            <view class="goods-name">{{ goodsDetail.title }}</view>
                            
                        </view>
                        <view class="arow">
							<view class="goods-price">¥ {{ goodsPrice }}</view>
                            <view class="goods-num">
								<view class="right-text num-box">
								   <view class="num-jian" @click="buyNumberTap(0)">-</view>
								   <view class="num-input">
								   	<input type="number" :value="buyNumber" disabled />
								   </view>
								   <view class="num-jia" @click="buyNumberTap(1)">+</view>
								</view>
							</view>
                        </view>
                    </view>
                </view>
            </view>
            <view class="peisong-way">
                
				<view class="a-goods">
					<view class="row-box">
					    <view class="row-label">收货人</view>
					    <view class="right-text">
					        <input v-model="consignee" type="text" class="liuyan" placeholder="请输入您的名字" />
					    </view>
					</view>
					<view class="row-box">
					    <view class="row-label">手机号</view>
					    <view class="right-text">
					        <input v-model="phone" type="text" class="liuyan" placeholder="请输入您的联系方式" />
					    </view>
					</view>
					<view class="row-box">
					    <view class="row-label">详细地址</view>
					    <view class="right-text">
					        <input v-model="address" type="text" class="liuyan" placeholder="请输入您的地址" />
					    </view>
					</view>
					<view class="row-box">
					    <view class="row-label">备注</view>
					    <view class="right-text">
					        <input v-model="remark" type="text" class="liuyan" placeholder="如需备注请输入" />
					    </view>
					</view>
				</view>
         
				<!-- <view class="notice">
				    <block>
				        <rich-text :nodes="activityDetail"></rich-text>
				    </block>
				</view> -->
            </view>

            <view class="jiesuan-box safeAreaOldPaddingBttom safeAreaNewPaddingBttom">
                <view class="left-price">
                    <view class="total">合计：¥ {{ payAmount }}</view>
                </view>
                <button class="to-pay-btn" @tap="createOrder">提交订单</button>
            </view>
        </view>
		<view class="show-popup" v-if="isPay">
			<view class="popup-mask" @click="closePay"></view>
			<view class="popup-contents">
				<payment @toCancel="closePay" @okPay="okPay" :payTypeId="6" :payOrderId="payOrderId" :payAmount="payAmount"></payment>
			</view>
		</view>
    </view>
</template>

<script>
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
import payment from '@/components/payment';
export default {
	components: {
		payment
	},
    data() {
        return {
            wxlogin: true,
			goodsId: 0,
            goodsList: [],
			imagebaseurl: getApp().globalData.fileDomain,
            buyType: 1,
            remark: '',
            consignee: '',
            phone: '',
			address:'',
            showModal: false,
			activityDetail: '',
			isPay:false,
			payOrderId:0,
			goodsPrice:0,
			payAmount:0,
			buyNumber:1,
			goodsDetail:''
        };
    },
    onShow() {
        AUTH.checkHasLogined().then((isLogined) => {
            this.setData({
                wxlogin: isLogined
            });
            if (isLogined) {
                this.doneShow();
            }
        });
    },
    onLoad(e) {
		this.goodsId = e.goodsId;
    },
    methods: {
		closePay: function() {
			this.isPay = false;
		},
		okPay: function() {
			this.isPay = false;
			uni.redirectTo({
				url: "/pages_order/order-list/index"
			});
		},
        doneShow() {
			WXAPI.mallGoodsDetail(this.goodsId).then((res) => {
				if(res.code==200){
					this.goodsDetail = res.data;
					this.goodsPrice = this.goodsDetail.price.toFixed(2);
					this.payAmount = (this.goodsPrice * this.buyNumber).toFixed(2);
				}
				uni.hideLoading();
			});
        },
		buyNumberTap: function(type) {
			if (type == 0) {
				if (this.buyNumber > 1) {
					this.buyNumber --;
				} else {
					// uni.showToast({icon: 'none',title: '时长最少1小时起'}); 
				}
			} else {
				this.buyNumber ++;
			}
			this.payAmount = (this.goodsPrice * this.buyNumber).toFixed(2);
		},
        createOrder: function (e) {
            var _this = this;
			let postData = [];
			
			if (_this.name =='') {
				uni.showToast({icon: 'none',title: '请输入收货人'}); 
			    return false;
			} 
			if (_this.phone =='') {
				uni.showToast({icon: 'none',title: '请输入收货手机号'}); 
			    return false;
			} 
			if (_this.address =='') {
				uni.showToast({icon: 'none',title: '请输入收货地址'}); 
			    return false;
			} 
			uni.showLoading();
			postData.goodsId = this.goodsId;
			postData.address = this.address;
			postData.remark = this.remark;
			postData.consignee = this.consignee;
			postData.phone = this.phone;
			postData.amount = this.payAmount;
            postData.num = this.buyNumber;
            WXAPI.goodsOrderCreate(postData).then(function (res) {
				uni.hideLoading();
                if (res.code == 200) {
                    _this.payOrderId = res.data.payOrderId;
                    _this.payAmount = res.data.payAmount;
                    _this.isPay = true;
                } else {
					uni.showModal({
					    title: '错误',
					    content: res.msg,
					    showCancel: false
					});
				}
                
            });
        },
    }
};
</script>
<style>
@import './payOrder.css';
</style>
