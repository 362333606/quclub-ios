<template>
    <view style="height: 100%">
        <view class="container">
            
            <view class="no-order" v-if="orderList.length == 0">
                <image src="/static/images/no-order.png" class="no-order-img"></image>
                <view class="text">暂无订单</view>
            </view>
            <view class="order-list" v-if="orderList.length > 0">
                <view class="order-item" v-for="(item, index) in orderList" :key="index">
					<navigator :url="currentType == 0 ? '/pages/mall/orderDetail?id=' + item.id : '/pages_monad/monad/detail?id='+item.id">
						<view class="goods-content">
							<view class="goods-img">
								<image class="img" mode="aspectFill" :src="imagebaseurl+item.goodsImg"></image>
							</view>
							<view class="goods-info">
								<view>
									<text class="goods-name">{{item.goodsName}}</text>
								</view>
								<view style="margin-top: 30rpx;">
									<text style="font-size: 36rpx;margin-right: 10rpx;">¥{{item.price}}</text>
									<text>x {{item.num}}</text>
								</view>
							</view>
						</view>
					</navigator>
					<view class="order-bottom">
						<view>{{item.createDate}}</view>
						<view class="price-box">
						    <text class="btn" v-if="item.status==0"  @click="cancelOrderTap(item)" >取消订单</text>
						    <text class="btn" v-if="item.status==0"  @click="toPayTap(item)">待支付</text>
							<text class="btn okpay" v-if="item.status==1">已支付</text>
							<text v-if="item.status==-1">已取消</text>
						</view>
					</view>
					
                </view>
            </view>
            <view class="safeAreaOldMarginBttom safeAreaNewMarginBttom"></view>
        </view>
		
		<view class="show-popup" v-if="isPay">
			<view class="popup-mask" @click="closePay"></view>
			<view class="popup-contents">
				<payment @toCancel="closePay" @okPay="okPay" :payTypeId="6" :payOrderId="payOrderId" :payAmount="payAmount"></payment>
			</view>
		</view>
    </view>
</template>

<script>
const wxpay = require('../../utils/pay.js');
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
import payment from '@/components/payment';
export default {
	components: {
		payment
	},
    data() {
        return {
			imagebaseurl: getApp().globalData.fileDomain,
            hasRefund: false,
            currentType: 0,
            tabClass: ['', '', '', '', ''],
            wxlogin: true,
            orderList: [],
			curPage: 1,
			pageSize: 10,
			totalPages:0,
			isPay:false,
			payOrderId:0,
			payAmount:0
        };
    },
    onLoad: function (options) {
        if (options && options.type) {
            if (options.type == 99) {
                this.setData({
                    hasRefund: true,
                    currentType: options.type
                });
            } else {
                this.setData({
                    hasRefund: false,
                    currentType: options.type
                });
            }
        }
		this.onShowClone();
    },
    onReady: function () {
        // 生命周期函数--监听页面初次渲染完成
    },
    onShow: function () {
        
    },
    onHide: function () {
        // 生命周期函数--监听页面隐藏
    },
    onUnload: function () {
        // 生命周期函数--监听页面卸载
    },
    onPullDownRefresh: function () {
        // 页面相关事件处理函数--监听用户下拉动作
    },
    onReachBottom: function () {
        // 滚动刷新
        if (this.curPage == this.totalPages) {
        	return;
        }
        this.setData({
            curPage: this.curPage + 1
        });
        this.doneShow();
    },
    methods: {
		closePay: function() {
			this.isPay = false;
		},
		okPay: function() {
			this.isPay = false;
			this.initPage();
		},
		
		initPage: function() {
			this.curPage = 1;
			this.orderList = [];
			this.doneShow();
		},
		initDemandPage: function() {
			this.curPage = 1;
			this.orderList = [];
			this.doneDemandShow();
		},
		formatDate: function(date){
			let newDate = new Date(date);
			let year = newDate.getFullYear();
			let month = (newDate.getMonth()+1).toString().padStart(2,0);
			let day = newDate.getUTCDate().toString().padStart(2,0);
			return year + '.' + month + '.' + day;
		},
        onShowClone: function () {
			 
            AUTH.checkHasLogined().then((isLogined) => {
                this.setData({
                    wxlogin: isLogined
                });
                if (isLogined) {
                    this.doneShow();
                }
            });
        },
        cancelOrderTap: function (item) {
            const that = this;
            const orderId = item.id;
            uni.showModal({
                title: '确定要取消该订单吗？',
                content: '',
                success: function (res) {
                    if (res.confirm) {
						uni.showLoading();
                        WXAPI.goodsOrderClose({orderId: orderId}).then(function (res) {
							uni.hideLoading();
                            if (res.code == 200) {
								uni.showToast({title: '取消成功'});
								setTimeout(() => {
								   that.doneShow();
								}, 1500);
                            } else {
								uni.showToast({
									 icon: 'none',
									 title: res.msg
								}); 
							}
                        });
                    }
                }
            });
        },



        toPayTap: function (item) {
			
			this.payOrderId = item.id;
			this.payAmount = item.totalPrice;
			this.isPay = true;
        },

        toPayTapFun: function (orderId, money) {
            const that = this;
            if (money <= 0) {
                // 直接使用余额支付
                WXAPI.orderPay(uni.getStorageSync('bestpw-Token'), orderId).then(function (res) {
                    that.onShowClone({});
                });
            } else {
                wxpay.wxpay('order', money, orderId, '/pages/order-list/index');
            }
        },

        doneShow: function () {
            // 获取订单列表
            let that = this;
    
			uni.showLoading({
			    title: '加载中'
			});
            WXAPI.goodsOrderList({
				pageSize: this.pageSize,
				page: this.curPage
			}).then(function (res) {
                if (res.code == 200) {
					var newArray = res.data.content;
					that.orderList = [...that.orderList,...newArray];
					that.totalPages = res.data.totalPages;
                } else {
                    that.setData({
                        orderList: null,
                    });
                }
				uni.hideLoading();
            });
        },
    }
};
</script>
<style>
@import './orderList.css';
</style>
