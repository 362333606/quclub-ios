<template>
    <view style="height: 100%">
        <view class="container">
            <view class="sec-wrap">
                <view class="order-status">
                    <view class="icon-box">
                        <image v-if="orderDetail.status == -1" class="icon" src="/static/images/order-details/icon-ddgb.png"></image>
                        <image v-else-if="orderDetail.status == 0" class="icon" src="/static/images/order-details/icon-ddfk.png"></image>
                        <image
                            v-else-if="orderDetail.status == 1"
                            class="icon"
                            src="/static/images/order-details/icon-jycg.png"
                        ></image>
                    </view>
                    <view class="right-text">
                        <view class="status red">
							<text v-if="orderDetail.status == -1">已取消</text>
							<text v-if="orderDetail.status == 0">待支付</text>
							<text v-if="orderDetail.status == 1">已支付</text>
						</view>
                        <view class="des" v-if="false">请于11时59分59秒内付款，超时订单将自动关闭</view>
                    </view>
                </view>

            </view>
			<view class="goods-list">
			    <view class="list-title">收货信息</view>
			   <view class="address-list">
				   <view>
						<text>{{orderDetail.consignee}}</text>
						<text style="margin-left: 40rpx;">{{orderDetail.phone}}</text>
					</view>
				   <view style="margin-top: 20rpx;">{{orderDetail.address}}</view>
			   </view>
			</view>
            <view class="goods-list">
                <view class="list-title">商品信息</view>
               <view class="a-goods" @tap="toDetail">
					<view class="img-box">
						<image :src="imagebaseurl+ orderDetail.goodsImg" class="img" />
					</view>
					<view class="text-box">
						<view class="arow arow01">
							<view class="goods-name">{{ orderDetail.goodsName }}</view>
						</view>
						<view class="arow">
							<view class="goods-price">¥ {{orderDetail.price}}</view>
							<view class="goods-num">x {{orderDetail.num}}</view>
						</view>
					</view>
				</view>
            </view>
            <view class="goods-info">
                <view class="row-box">
                    <view class="row-label">订单金额</view>
                    <view class="right-text">¥ {{ orderDetail.totalPrice }}</view>
                </view>
				<view class="row-box">
				    <view class="row-label">订单编号</view>
				    <view class="right-text">{{ orderDetail.code }}</view>
				</view>
				<view class="row-box">
				    <view class="row-label">支付方式</view>
				    <view class="right-text">在线支付</view>
				</view>
				<view class="row-box">
				    <view class="row-label">下单时间</view>
				    <view class="right-text">{{ orderDetail.createDate }}</view>
				</view>
				
            </view>
        </view>
    </view>
</template>

<script>
const app = getApp();
const CONFIG = require('../../config.js');
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
export default {
    data() {
        return {
            orderId: 0,
            goodsList: [],
            appid: '',
			imagebaseurl: getApp().globalData.fileDomain,
            orderDetail: {
                orderInfo: {
                    status: '',
                    statusStr: '',
                    orderNumber: '',
                    amount: '',
                    amountReal: ''
                },

                goods: []
            }
        };
    },
    onLoad: function (e) {
        var orderId = e.id;
        this.orderId = orderId;
        this.setData({
            orderId: orderId,
            appid: uni.getStorageSync('wxAppid')
        });
    },
    onShow: function () {
        this.onShowClone();
    },
    methods: {
		toDetail: function() {
			uni.navigateTo({
			    url: '/pages/mall/goodsDetail?id='+ this.orderDetail.goodsId
			});
		},
        onShowClone: function () {
			uni.showLoading({
			    title: '加载中'
			});
            var that = this;
            WXAPI.goodsOrderDetail(that.orderId).then(function (res) {
                if (res.code == 200) {
					that.orderDetail = res.data
					uni.hideLoading();
                }
            });
        },
    }
};
</script>
<style>
@import './orderDetail.css';
</style>
