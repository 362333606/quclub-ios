<template>
	
	<view class="contain" >
		<view class="img-list">
			<view style="margin-left: 30rpx;margin-bottom: 10rpx;">*第一张默认活动封面图</view>
			<upload_img :imgsUrl.sync="form.content"></upload_img>
		</view>
		<view class="info-title">
			<view class="info-title-m">基础资料</view>
		</view>
		<view class="info-input">
			<view class="title">活动名称</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.name" value=""  placeholder="请输入活动名称"/></view>
		</view>
		<view class="info-input">
			<view class="title">活动地点</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.address" value=""  placeholder="请输入活动地点"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">活动描述</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.description" value=""  placeholder="请输入活动描述"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">活动开始时间</view>
			<view class="input">
				<uni-datetime-picker class="apply_input" v-model="form.startTime" :border="false" />
			</view>
		</view>
		
		<view class="info-input">
			<view class="title">活动结束时间</view>
			<view class="input">
				<uni-datetime-picker class="apply_input" v-model="form.endTime" :border="false" />
			</view>
		</view>
		
		<view class="info-input">
			<view class="title">活动参加金额</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.price" value=""  placeholder="请输入活动参加金额"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">活动人数</view>
			<view class="input"><input type="text" class="apply_input" v-model="form.number" value=""  placeholder="请输入活动人数"/></view>
		</view>
		
		<view class="info-title">
			<view class="info-title-m">标签</view>
		</view>
		<view class="select-tags">
			<text class="tag-item" 
			v-for="tag in tagLists"
			:class="form.tags.includes(tag) ? 'select-tag' : 'default-tag'" 
			@click="chooseTags(tag)">{{tag}}</text>
		</view>
		
		<view class="info-title">
			<view class="info-title-m">类型</view>
		</view>
		
		<view class="project-list">
			<view class="project-item"
			v-for="(item,indexx) in projectList" 
			:class="form.categoryId == item.id ? 'active' : 'default'"
			@click="onProject(item)">
				<view class="my-icon-menu-img">
					 <image :src="imagebaseurl + item.logo" style=""></image>
				</view>
				<text>{{item.title}}</text>
			</view>
		</view>
		
		
		<view class="form-submit">
		    <button formType="submit" type="primary" class="submit" @tap="submitApply()">确认发布</button>
		</view>
		
		<q-previewImage ref="previewImage" :urls="image_list"></q-previewImage>
		
	</view>
	
</template>

<script>
// pages/search/search.js
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const TOOLS = require('../../utils/tools');
import upload_img from '@/components/upload_img.vue';
export default {
    components: {
		upload_img
    },
    data() {
        return {
			projectList:[],
			image_list:[],
			tagLists:[],
			imagebaseurl: getApp().globalData.fileDomain,
			form:{
				name:'',
				address:'',
				description:'',
				startTime:'',
				endTime:'',
				price:'',
				number:'',
				categoryId:'',
				category:'',
				tags:[],
				content:[]
			}
        };
    },
	
	
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {},
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
		uni.showLoading({
		    title: '加载中'
		});
		this.getProjects();
		this.getTagList();
		uni.hideLoading();
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {},
	
    methods: {
		onProject(item) {
			this.form.categoryId = item.id
			this.form.category = item.title
		},
		preview(url) {
		    this.$refs.previewImage.open(url); // 传入当前选中的图片地址
		},

		chooseTags: function(tag) {
			if (this.form.tags.includes(tag)) {
				this.form.tags = this.form.tags.filter(function(item) {
				  return item !== tag;
				});
			} else {
				if (this.form.tags.length == 3) {
					uni.showToast({icon: 'none',title: '最多选3个标签哦'}); 
					return;
				}
				this.form.tags.push(tag);
			}
		},
		getTagList(){
			WXAPI.getData('Activity_Tags').then((res) => {
				if(res.code==200){
					this.tagLists = res.data;
				}
			});
		},
		getProjects(){
			
			WXAPI.serveList().then((res) => {
				if(res.code==200){
					this.projectList = res.data;
				}
			});
		},
        
		submitApply(){
			var loginToken = uni.getStorageSync('bestpw-Token');
			if (!loginToken) {
			    uni.showModal({
			        title: '友情提示',
			        content: '用户未登录，请登录后再操作！',
			        showCancel: false
			    });
			    return;
			}
			let _this = this;
			
			if (_this.form.name =='') {
				uni.showToast({icon: 'none',title: '请填写活动名称'}); 
			    return false;
			} 
			if (_this.form.address =='') {
				uni.showToast({icon: 'none',title: '请填写活动地点'}); 
			    return false;
			} 
			if (_this.form.description =='') {
				uni.showToast({icon: 'none',title: '请填写活动描述'}); 
			    return false;
			} 
			if (_this.form.startTime =='') {
				uni.showToast({icon: 'none',title: '请选择活动开始时间'}); 
			    return false;
			} 
			if (_this.form.endTime =='') {
				uni.showToast({icon: 'none',title: '请选择活动结束时间'}); 
			    return false;
			} 
			if (_this.form.price =='') {
				uni.showToast({icon: 'none',title: '请填写活动参加金额'}); 
			    return false;
			} 
			if (_this.form.number =='') {
				uni.showToast({icon: 'none',title: '请填写活动人数'}); 
			    return false;
			} 
			if (_this.form.tags =='') {
				uni.showToast({icon: 'none',title: '请选择标签'}); 
			    return false;
			} 
			if (_this.form.categoryId =='') {
				uni.showToast({icon: 'none',title: '请填写活动类型'}); 
			    return false;
			} 
			uni.showLoading();
			WXAPI.postActivity(_this.form).then((result) => {
				uni.hideLoading();
				if(result.code == 200){
					uni.showToast({title: '申请成功'});
					setTimeout(() => {
						uni.navigateTo({
							url:'/pages/my/index'
						})
					  }, 2000);
					} else {
						uni.showToast({
							 icon: 'none',
							 title: result.msg
						}); 
					}
				});
			 
		}

       
    }
};
</script>
<style>
@import './post.css';
</style>
