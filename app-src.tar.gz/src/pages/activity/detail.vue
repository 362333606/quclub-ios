<template>
    <view style="width: 100%;height: 100%;padding: 15px">
        
		<view style="width: 100%;display: flex;margin-bottom: 10px;">
			<view class="head-img" style="width: 35%;display: inline-block;">
				<image class="img" mode="aspectFill" :src="imagebaseurl + detail.img"></image>
			</view>
			<view class="content" style="width: 65%;display: inline-block;">
				<view class="title">{{ detail.name}}</view>
				<view class="address" style="font-size: 14px;margin-left: 32rpx;">{{detail.number}}<text class="item-time" v-if="detail.time != ''">{{detail.time}}</text></view>
				<!-- <view class="address" style="font-size: 12px;">{{item.time}}</view> -->
				<view class="num" style="margin-top: 20rpx;margin-left: 32rpx;" v-if="detail.tags != ''">
					<text class="info-desc" v-for="(mk,index) in (detail.tags || '').split(',')">{{mk}}</text>
				</view>
				<view class="list price" style="margin-top: 20rpx;">¥{{ detail.price}}<span class="mark">起/人</span></view>
				
			</view>
		</view>
		<view style="font-size: 12px;">{{ detail.startTime}} 至 {{ detail.endTime}}</view>
		
		<view class="cu-bar" style="display: inline-block;">
		    <view class="action" style="margin-left: 0px;">
				 <image src="/static/images/bg/zy31.png" style="width: 5px;height:20px;margin-right: 5px;"> </image>
		        活动地址
		    </view>
			<view style="padding-bottom: 10px;">{{ detail.address}}</view>
		</view>
		
		<view class="cu-bar">
		    <view class="action" style="margin-left: 0px;">
				 <image src="/static/images/bg/zy31.png" style="width: 5px;height:20px;margin-right: 5px;"> </image>
		        活动简介
		    </view>
			<view style="padding-bottom: 10px;">{{ detail.description}}</view>
		</view>
		
		
		<view class="cu-bar">
		    <view class="action" style="margin-left: 0px;">
				 <image src="/static/images/bg/zy31.png" style="width: 5px;height:20px;margin-right: 5px;"> </image>
		        活动详情
		    </view>
			<view style="padding-bottom: 10px;"><mp-html :content="detail.content"></mp-html></view>
		</view>
		
        
		<view class="footer-box">
			<view class="box-title" v-if="detail.is_over == 1 && detail.is_join == 0">
				<view class="box-shop-cart npx bg-orange" @click="tobuy">立即参加</view>
			</view>
			
			<view class="box-title" v-if="detail.is_over == 0 && detail.is_join == 0">
				<view class="box-shop-cart npx bg-gray">活动已结束</view>
			</view>
			
			<view class="box-title" v-if="detail.is_join == 1">
				<view class="box-shop-cart npx bg-blue">已参加</view>
			</view>
			
		</view>
		<view class="show-popup" v-if="isPay">
			<view class="popup-mask" @click="closePay"></view>
			<view class="popup-contents">
				<payment @toCancel="closePay" @okPay="okPay" :payTypeId="3" :payOrderId="payOrderId" :payAmount="payAmount"></payment>
			</view>
		</view>
    </view>
</template>

<script>
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
import payment from '@/components/payment';
export default {
	components: {
		payment
	},
    data() {
        return {
            //需求列表
            detail: [],
			activity_id:'',
			imagebaseurl: getApp().globalData.fileDomain,
			isPay:false,
			payOrderId:0,
			payAmount:0
        };
    },
    onLoad: function (options) {
        
		this.activity_id = options.id;
        this.search();
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {},
    methods: {
       
        async search() {
            
            uni.showLoading({
                title: '加载中'
            });
			var activity_id = this.activity_id;
		
			WXAPI.activityDetail(activity_id).then((res) => {
				if(res.code==200){
					this.detail = res.data;
				}
				uni.hideLoading();
			});
        },
		closePay: function() {
			this.isPay = false;
		},
		okPay: function() {
			this.isPay = false;
			this.search();
		},
		tobuy(){
			var loginToken = uni.getStorageSync('bestpw-Token');
			if (!loginToken) {
			    uni.showModal({
			        title: '提示',
			        content: '用户未登录，请登录后再参加！',
			        showCancel: false
			    });
			    return;
			}
			uni.showLoading({
			    title: '加载中'
			});
			WXAPI.activityRez({
				activityId : this.activity_id,
			}).then((res) => {
				uni.hideLoading();
				if(res.code==200){
					var id = res.data;
					this.payOrderId = res.data.id;
					this.payAmount = res.data.price;
					this.isPay = true;
				} else {
					uni.showModal({
						title: '提示',
						content: result.msg,
						showCancel: false
					});
				}
			});
		}
    }
};
</script>
<style>
@import './detail.css';
</style>

