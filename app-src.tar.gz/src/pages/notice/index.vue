<template>
    <view style="height: 100%">
        <navigator :url="'/pages/notice/show?id=' + item.id" v-for="(item, index) in noticeList" :key="index">
            <view class="cashlogs">
                <view class="profile">
                    <view class="typeStr">{{ item.title }}</view>
                    <view class="dateAdd">{{ item.dateAdd }}</view>
                </view>
                <view class="amount">查看 ></view>
            </view>
        </navigator>
    </view>
</template>

<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
export default {
    data() {
        return {
            noticeList: ''
        };
    }
    /**
     * 生命周期函数--监听页面加载
     */,
    onLoad: function (options) {
        WXAPI.noticeList().then((res) => {
            this.setData({
                noticeList: res.data.dataList
            });
        });
    },
    onShow: function () {},
    methods: {}
};
</script>
<style>
@import './index.css';
</style>
