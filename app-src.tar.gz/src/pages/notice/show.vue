<template>
    <view class="notice">
        <view class="title">{{ notice.title }}</view>
        <view class="text">
            <!-- <template is="wxParse" :data="wxParseData:article.nodes"/> -->
            <mp-html :content="article"></mp-html>
        </view>
    </view>
</template>

<script>
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
export default {data() {
            return {
             notice: {
              title: ""
             },

             article: ""
            };
        },/**
 * 生命周期函数--监听页面加载
 */
onLoad: function (options) {
  var that = this;
  WXAPI.noticeDetail(options.id).then(function (res) {
    if (res.code == 0) {
      that.setData({
        notice: res.data
      });
      //WxParse.wxParse('article', 'html', res.data.content, that, 5)
      that.article = that.escape2Html(res.data.content);;
    }
  });
},
/**
 * 生命周期函数--监听页面初次渲染完成
 */
onReady: function () {},
/**
 * 生命周期函数--监听页面显示
 */
onShow: function () {},
/**
 * 生命周期函数--监听页面隐藏
 */
onHide: function () {},
/**
 * 生命周期函数--监听页面卸载
 */
onUnload: function () {},
/**
 * 页面相关事件处理函数--监听用户下拉动作
 */
onPullDownRefresh: function () {},
/**
 * 页面上拉触底事件的处理函数
 */
onReachBottom: function () {},
/**
 * 用户点击右上角分享
 */
onShareAppMessage: function () {},
methods: {}};
</script>
<style>
@import './show.css';
</style>
