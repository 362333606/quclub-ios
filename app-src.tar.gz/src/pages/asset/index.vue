<template>
    <view style="height: 100%">
        <view v-if="rechargeOpen" class="flex text-center bg-red padding">
            <view class="flex-sub">
                <view>可用余额(元)</view>
                <view>{{ balance }}</view>
            </view>
            <view class="flex-sub">
                <view>冻结金额(元)</view>
                <view>{{ freeze }}</view>
            </view>
            <view class="flex-sub">
                <view>累计消费(元)</view>
                <view>{{ totleConsumed }}</view>
            </view>
        </view>
        <view class="flex padding bg-red justify-end" v-if="rechargeOpen">
            <navigator url="/pages/recharge/index" class="cu-btn line-white">充值</navigator>
            <navigator url="/pages/withdraw/index" class="cu-btn line-white margin-left">提现</navigator>
            <navigator url="/pages/deposit/pay" class="cu-btn line-white margin-left">押金</navigator>
        </view>
        <scroll-view scroll-x class="bg-white nav">
            <view class="flex text-center">
                <view
                    :class="'cu-item flex-sub ' + (activeIndex == index ? 'text-red cur' : '')"
                    @tap="tabClick"
                    :data-id="index"
                    :id="index"
                    v-for="(item, index) in tabs"
                    :key="index"
                >
                    {{ item }}
                </view>
            </view>
        </scroll-view>
        <view class="tab-content" v-if="activeIndex == 0">
            <view class="no-data" v-if="!cashlogs">暂无资金明细~</view>
            <view class="cashlogs bg-white padding-top-xs" v-if="cashlogs" v-for="(item, index) in cashlogs" :key="index">
                <view class="profile">
                    <view class="typeStr">{{ item.typeStr }}</view>
                    <view class="dateAdd">{{ item.dateAdd }}</view>
                </view>

                <view class="amount" :style="'color: ' + (item.behavior == 0 ? 'red' : 'green')">{{ item.behavior == 0 ? '+' : '-' }} {{ item.amount }}</view>
            </view>
        </view>
        <view class="tab-content" v-if="activeIndex == 1">
            <view class="no-data" v-if="!withDrawlogs">暂无提现记录~</view>
            <view class="cashlogs bg-white padding-top-xs" v-if="withDrawlogs" v-for="(item, index) in withDrawlogs" :key="index">
                <view class="profile">
                    <view class="typeStr">{{ item.statusStr }}</view>
                    <view class="dateAdd">{{ item.dateAdd }}</view>
                </view>

                <view class="amount" style="color: red">{{ item.money }}</view>
            </view>
        </view>
        <view class="tab-content" v-if="activeIndex == 2">
            <view class="no-data" v-if="!depositlogs">暂无押金记录~</view>
            <view class="cashlogs bg-white padding-top-xs" v-if="depositlogs" v-for="(item, index) in depositlogs" :key="index">
                <view class="profile">
                    <view class="typeStr">{{ item.statusStr }}</view>
                    <view class="dateAdd">{{ item.dateAdd }}</view>
                </view>

                <view class="amount" style="color: red">{{ item.amount }}</view>
            </view>
        </view>
        <float-menu />
    </view>
</template>

<script>
const app = getApp();
// const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
// import ApifmLogin from '../../template/login/index.js';
var sliderWidth = 96; // 需要设置slider的宽度，用于计算中间位置

export default {
    data() {
        return {
            wxlogin: true,
            balance: 0,
            freeze: 0,
            score: 0,
            score_sign_continuous: 0,
            cashlogs: undefined,
            tabs: ['资金明细', '提现记录', '押金记录'],
            activeIndex: 0,
            sliderOffset: 0,
            sliderLeft: 0,
            withDrawlogs: undefined,
            depositlogs: undefined,

            // 是否开启充值[预存]功能
            rechargeOpen: false,

            totleConsumed: ''
        };
    }
    /**
     * 生命周期函数--监听页面加载
     */,
    onLoad: function (options) {
        // ApifmLogin.init(this);
        const that = this;
        uni.getSystemInfo({
            success: function (res) {
                that.setData({
                    sliderLeft: (res.windowWidth / that.tabs.length - sliderWidth) / 2,
                    sliderOffset: (res.windowWidth / that.tabs.length) * that.activeIndex
                });
            }
        });
        let rechargeOpen = uni.getStorageSync('RECHARGE_OPEN');
        if (rechargeOpen && rechargeOpen == '1') {
            rechargeOpen = true;
        } else {
            rechargeOpen = false;
        }
        this.setData({
            rechargeOpen: rechargeOpen
        });
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        AUTH.checkHasLogined((isLogined) => {
            this.setData({
                wxlogin: isLogined
            });
            if (isLogined) {
                this.doneShow();
            }
        });
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {},
    methods: {
        doneShow: function () {
            const that = this;
            const token = uni.getStorageSync('bestpw-Token');
            if (!token) {
                this.setData({
                    wxlogin: false
                });
                return;
            }
            WXAPI.userAmount(token).then(function (res) {
                if (res.code == 700) {
                    uni.showToast({
                        title: '当前账户存在异常',
                        icon: 'none'
                    });
                    return;
                }
                if (res.code == 2000) {
                    this.setData({
                        wxlogin: false
                    });
                    return;
                }
                if (res.code == 0) {
                    that.setData({
                        balance: res.data.balance.toFixed(2),
                        freeze: res.data.freeze.toFixed(2),
                        totleConsumed: res.data.totleConsumed.toFixed(2),
                        score: res.data.score
                    });
                }
            });
            this.fetchTabData(this.activeIndex);
        },

        fetchTabData(activeIndex) {
            if (activeIndex == 0) {
                this.cashLogs();
            }
            if (activeIndex == 1) {
                this.withDrawlogsFun();
            }
            if (activeIndex == 2) {
                this.depositlogsFun();
            }
        },

        cashLogs() {
            const _this = this;
            WXAPI.cashLogs({
                token: uni.getStorageSync('bestpw-Token'),
                page: 1,
                pageSize: 50
            }).then((res) => {
                if (res.code == 0) {
                    _this.setData({
                        cashlogs: res.data
                    });
                }
            });
        },

        withDrawlogsFun() {
            const _this = this;
            WXAPI.withDrawLogs({
                token: uni.getStorageSync('bestpw-Token'),
                page: 1,
                pageSize: 50
            }).then((res) => {
                if (res.code == 0) {
                    _this.setData({
                        withDrawlogs: res.data
                    });
                }
            });
        },

        depositlogsFun() {
            const _this = this;
            WXAPI.depositList({
                token: uni.getStorageSync('bestpw-Token'),
                page: 1,
                pageSize: 50
            }).then((res) => {
                if (res.code == 0) {
                    _this.setData({
                        depositlogs: res.data.result
                    });
                }
            });
        },

        tabClick: function (e) {
            this.setData({
                sliderOffset: e.currentTarget.offsetLeft,
                activeIndex: e.currentTarget.id
            });
            this.fetchTabData(e.currentTarget.id);
        },

        cancelLogin() {
            uni.switchTab({
                url: '/pages/my/index'
            });
        },

        processLogin(e) {
            if (!e.detail.userInfo) {
                uni.showToast({
                    title: '已取消',
                    icon: 'none'
                });
                return;
            }
            AUTH.register(this);
        }
    }
};
</script>
<style>
@import './index.css';
</style>
