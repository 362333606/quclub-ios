<template>
    <view style="height: 100%">
        <navigation id="Navigation" :show-search="true" :disable-search-jump="disableSearchJump" :animation="fadeAni" @selectCity="changeCity" @seachSex="seachSex"></navigation>
		
		<view class="swiper-container">
		    <swiper :class="'screen-swiper ' + (dotStyle ? 'square-dot' : 'round-dot')" :circular="true" :autoplay="true" :indicator-dots="true" interval="5000" duration="500">
		        <swiper-item @tap="tapNav" :data-url="item.link" v-for="(item, index) in banners" :key="index">
		            <image :src="imagebaseurl + item.img" :lazy-load="true"></image>
		        </swiper-item>
		    </swiper>
		</view>
		
		<view class="home-menu">
			<view class="home-menu-item" @tap="tapNav" :data-url="item.link" v-for="(item, index) in navList" :key="index">
				<view class="home-menu-title">{{item.title}}</view>
				<view>
					<image :src="imagebaseurl + item.img" :lazy-load="true" />
				</view>
			</view>
		</view>
		
	<!-- 	<div>
		    <button @click="openConversationList">打开会话列表</button>
		    <button @click="openContact">打开联系人</button>
		  </div> -->
		
		<view class="home-list">
			<view class="home-list-title">
				<text v-if="sex === 1">颜值男神</text>
				<text v-else>颜值女神</text>
			</view>
			<view class="home-list-title-border"></view>
			
			 <navigator :url="'/pages_details/goods-details/index?id=' + item.id" v-for="(item, index) in bestList" :key="index">
				 <view class="best-item">
					<view :class="item.auths.includes('真人认证') || item.auths.includes('视频认证') ? 'best-item-head head-active' : 'best-item-head'">
						  <image class="img" mode="aspectFill" :src="imagebaseurl+item.pic+'?x-oss-process=image/resize,m_fill,h_200,w_200'" :lazy-load="true"></image>
						  <text v-if="item.auths.includes('真人认证') && !item.auths.includes('视频认证')">真人认证</text>
						  <text v-if="item.auths.includes('视频认证')">视频认证</text>
					</view>
					<view class="best-item-content">
						<view class="best-item-content-head">
							
							<view class="best-item-tags">
								<text class="best-item-name">{{item.name}}</text>
								<text class="best-item-tag" :class="item.sex == 1 ? 'man':'woman'">
									<image v-if="item.sex == 2" mode="aspectFill" class="sex" src="/static/images/nav/woman.png"></image>
									<image v-if="item.sex == 1" mode="aspectFill" class="sex" src="/static/images/nav/man.png"></image>
									<text>{{item.age}}</text>
								</text>
								<text class="best-item-tag" :class="item.sex == 1 ? 'man':'woman'" v-if="item.auths.includes('颜值认证')">
									<image mode="aspectFill" class="sex" src="/static/images/nav/yz_auth.png"></image>
									<text style="margin-left: 6rpx;">颜值认证</text>
								</text>
							</view>
							<view class="best-item-content-right">
								<text class="best-item-tag" style="background-color: #88ccf1;">
									<text class="status-point online" v-if="item.activity==1"></text>
									<text class="status-point busy" v-if="item.activity==2"></text>
									<text v-if="item.activity==1">在 线</text>
									<text v-else>忙 碌</text>
								</text>
							</view>
						</view>
						<view class="best-item-content-info">
							<text>{{item.height}} cm</text>
							<text>{{item.weight}} kg</text>
							<text v-if="item.constellation">{{item.constellation}}</text>
							<text v-if="item.profession">{{item.profession}}</text>
						</view>
						<view class="best-item-content-tag">
							<text v-for="(tag,index) in (item.tags || '').split(',')">{{tag}}</text>
						</view>
						<view class="best-imgs">
							 <image mode="aspectFill" :src="imagebaseurl+img+'?x-oss-process=image/resize,m_fill,h_300,w_300'" v-for="(img, index) in item.imgs" :lazy-load="true"></image>
						</view>
					</view>
				</view>
			 </navigator>
		
		</view>

        <view :class="'cu-load  ' + (loadingMoreHidden ? 'loading' : 'over')"></view>
    </view>
</template>
<script>
import navigation from '@/components/navigation/navigation';
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const CONFIG = require('../../config.js');
const TOOLS = require('../../utils/tools.js');
const AUTH = require('../../utils/auth');
// import { TUILogin } from '@tencentcloud/tui-core';
// import { TUIChatKit } from '../../TUIKit';
// TUIChatKit.init();
let vueVersion = 2;
// #ifdef VUE3
vueVersion = 3;
// #endif
// uni.$SDKAppID = 1600065675; // Your SDKAppID
// uni.$userID = 'dll'; // Your userID
// uni.$userSig = 'eJyrVgrxCdYrSy1SslIy0jNQ0gHzM1NS80oy0zLBwik5OVDh4pTsxIKCzBQlK0MzAwMDM1Mzc1OITGpFQWZRKlDc1NTUCCgFES3JzAWJmRsbm5uaGFpC1RZnpgNNLSzzLovR9y8rscx2KfM3cPOJMA2p8vBP9o7wKDJ1c8tILkl0MQnyKTV3Ncu3VaoFAOIVMOA_'; // Your userSig
// uni.$userID = 'zxc'; // Your SDKAppID
// uni.$userSig = 'eJyrVgrxCdYrSy1SslIy0jNQ0gHzM1NS80oy0zLBwlUVyVDh4pTsxIKCzBQlK0MzAwMDM1Mzc1OITGpFQWZRKlDc1NTUCCgFES3JzAWJmRsbm5uamJqbQ03JTAea6hvkFBmU4*xZ4RQeEaOfbF5pkOpdkp2UFZwV5WqRl1OZ6ursF5RhEJLiWOJqq1QLAOpcMTc_'
//获取应用实例
var app = getApp();
export default {
    components: {
        navigation
    },
	
	// onLaunch: function () {
	// 	 TUILogin.login({
	// 	   SDKAppID: 16000656751,
	// 	   userID: 'zxc1', 
	// 	   userSig: '1eJyrVgrxCdYrSy1SslIy0jNQ0gHzM1NS80oy0zLBwlUVyVDh4pTsxIKCzBQlK0MzAwMDM1Mzc1OITGpFQWZRKlDc1NTUCCgFES3JzAWJmRsbm5uamJqbQ03JTAea6hvkFBmU4*xZ4RQeEaOfbF5pkOpdkp2UFZwV5WqRl1OZ6ursF5RhEJLiWOJqq1QLAOpcMTc_', 
	// 	   useUploadPlugin: true, // If you need to send rich media messages, please set to true.
	// 	   framework: `vue${vueVersion}` // framework used vue2 / vue3
	// 	 }).catch(() => {});
	//   },
    data() {
        return {
            inputVal: '',
            // 搜索框内容
            bestList: [],
            selectCurrent: 0,
            scrollTop: 0,
            loadingMoreHidden: true,
            coupons: [],
            curPage: 1,
            pageSize: 5,
			sex: 2,
			totalPages:0,
			imagebaseurl: getApp().globalData.fileDomain,
            disableSearchJump: true,
            aliveRooms: [],
            fadeAni: '',
			navList:[],
			banners: [],
			dotStyle: 'square-dot',
        };
    },
    onLoad: function (e) {
		
        uni.showShareMenu({
            withShareTicket: true,
            menus: ['shareAppMessage', 'shareTimeline']
        });
        // const that = this
        // if (e && e.query && e.query.inviter_id) {
        //   wx.setStorageSync('referrer', e.query.inviter_id)
        // }
        if (e && e.scene) {
            const scene = decodeURIComponent(e.scene);
            if (scene) {
                uni.setStorageSync('referrer', scene.substring(11));
            }
        }
        this.initPage();
		// #ifdef H5
			
			
		// #endif
		if(this.isWeiXinLogin() && (!uni.getStorageSync('user_op') || uni.getStorageSync('user_op') == '0')) {
			this.getCode();
		}
    },
    onShow: function (e) {
        app.globalData.fadeInOut(this, 'fadeAni', 0);
    },
    onPageScroll(e) {
        let scrollTop = this.scrollTop;
        this.setData({
            scrollTop: e.scrollTop
        });
        if (e.scrollTop >= 180) {
            uni.setNavigationBarColor({
                frontColor: '#000000',
                backgroundColor: '#ffffff'
            });
            app.globalData.fadeInOut(this, 'fadeAni', 1);
            this.setData({
                disableSearchJump: false
            });
        } else {
            uni.setNavigationBarColor({
                frontColor: '#ffffff',
                backgroundColor: '#ffffff'
            });
            app.globalData.fadeInOut(this, 'fadeAni', 0);
            this.setData({
                disableSearchJump: true //隐藏自定义导航栏时点击到搜索框区域时不跳转搜索页面
            });
        }
    },
    onShareAppMessage: function () {
        return {
            title: '"' + uni.getStorageSync('mallName') + '" ' + CONFIG.shareProfile,
            path: '/pages/index/index?inviter_id=' + uni.getStorageSync('uid'),
            imageUrl: 'https://oss.bestpw.cn/ic_logo.png'
        };
    },
    //转发到朋友圈
    onShareTimeline: function () {
        return {
            title: '"' + uni.getStorageSync('mallName') + '" ' + CONFIG.shareProfile,
            query: '/pages/index/index?inviter_id=' + uni.getStorageSync('uid')
        };
    },
    onReachBottom: function () {
        // 滚动刷新
		if (this.curPage == this.totalPages) {
			return;
		}
        this.setData({
            curPage: this.curPage + 1
        });
        this.getBestList(true);
    },
    methods: {
		 // 打开会话列表
		    openConversationList() {
		      uni.navigateTo({ url: '/TUIKit/components/TUIConversation/index' });
		    },
		    // 打开联系人
		    openContact() {
		      uni.navigateTo({ url: '/TUIKit/components/TUIContact/index' });
		    },
		//判断是否微信登陆
		isWeiXinLogin() {
		    var ua = window.navigator.userAgent.toLowerCase();
		    if (ua.match(/MicroMessenger/i) == 'micromessenger') {
		        return true; // 微信中打开
		    } else {
		        return false; // 普通浏览器中打开
		    }
		},
		getCode () {
			const code = this.getUrlParam('code');
			//截取路径中的code，如果没有就去微信授权，如果已经获取到了就直接传code给后台获取openId
			const local = window.location.href;
			if (code == null || code === '') {
				window.location.href = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx5a64ae4cbfea3f43&redirect_uri=' + encodeURIComponent(local) + '&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect'
			} else {
				this.getOpenId(code) //把code传给后台获取用户信息
			}
		},
		getOpenId (code) { // 通过code获取 openId等用户信息
			let _this = this;
			WXAPI.getOpenId({
				code: code,
			}).then((res) => {
			    if (res.code == 200) {
					uni.setStorageSync("openid",res.msg);
				}
			})
		},
        tapNav(e) {
			let url = e.currentTarget.dataset.url;
			AUTH.checkHasLogined().then((isLogined) => {
				if(!isLogined && url == '/pages_release/release/index') {
					uni.showToast({
					    title: '请登录后再操作',
					    icon: 'none'
					});
				} else {
					if (url.includes("http")) {
						window.location.href = url;
					} else {
						uni.navigateTo({
						    url: url
						});
					}
				}
			})
        },

        tabClick: function (e) {
            uni.navigateTo({
                url: '/pages/goods/list?categoryId=' + e.currentTarget.id
            });
        },
		
		// 解析URL 参数
		getUrlParam(name) {
			let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)');
			let r = window.location.search.substr(1).match(reg);
			if (r != null) {
				return unescape(r[2]);
			}
			return null;
		},

        toDetailsTap: function (e) {
            uni.navigateTo({
                url: '/pages_details/goods-details/index?id=' + e.currentTarget.dataset.id
            });
        },
		changeCity(){
			this.curPage = 1;
			this.curPage2 = 1;
			this.bestList = [];
			this.getBestList();
		},
        async initPage() {
            uni.showLoading();
			//获取轮播
			const bannerRes = await WXAPI.menuList({type: 1});
			if (bannerRes.code == 200) {
			     this.banners = bannerRes.data;
			}
			const navRes = await WXAPI.menuList({type: 2});
			if (navRes.code == 200) {
			    this.navList = navRes.data;
			} 
            this.getBestList();
            uni.hideLoading();
        },
		seachSex(sex) {
			this.curPage = 1;
			this.curPage2 = 1;
			this.bestList = [];
			this.sex = sex;
			uni.setStorageSync("sex_mark",sex);
			this.getBestList();
		},


        async getBestList() {
			uni.showLoading();
            const res = await WXAPI.goods({
                pageSize: this.pageSize,
                page: this.curPage,
				sex: this.sex,
				city:uni.getStorageSync('cityindex')?uni.getStorageSync('cityindex'):'武汉',
            });
			uni.hideLoading();
			let newArray = res.data.content;
			this.bestList = [...this.bestList,...newArray]
            this.setData({
				totalPages: res.data.totalPages,
                loadingMoreHidden: true,
            });
			if (this.curPage == this.totalPages || this.totalPages == 0) {
				this.loadingMoreHidden = false;
			}
        },

        /*  上拉刷新
      onPullDownRefresh: function() {
          this.setData({
              curPage: 1,
          curPage2: 1,
          });
          this.initPage()
          wx.stopPullDownRefresh()
      },
    */

        bindinput(e) {
            this.setData({
                inputVal: e.detail.value
            });
        },

        bindconfirm(e) {
            this.setData({
                inputVal: e.detail.value
            });
            uni.navigateTo({
                url: '/pages/goods/list?name=' + this.inputVal
            });
        },

        handleTap: function (e) {

            let id = e.currentTarget.dataset.id;			
			console.log(id);
            if (id) {
                this.setData({
                    currentId:id
                });
            }
        }
    }
};
</script>
<style>
@import './index.css';
</style>
