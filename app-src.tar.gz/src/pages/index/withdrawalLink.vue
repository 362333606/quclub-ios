<template>
    <view class="partner-container">
		
		<view class="Withdrawal-content" v-if="status == 200 && !success">
			<view style="text-align: center;margin-top: 200rpx;margin-bottom: 80rpx;">
				<image :src="imagebaseurl + pic" class="userinfo-avatar"></image>
			</view>
			<view class="wallet" >
				<view class="wallet-info">
					<view class="wallet-all">
						<text class="wallet-title">钱包余额</text>
						<view class="wallet-balance">{{balance.toFixed(2)}}</view>
					</view>
				</view>
			</view>
			<view class="info-input">
				<view class="title" style="font-size: 32rpx;">提现支付宝</view>
				<view class="input"><input v-model="aliPay" type="text" class="apply_input"  placeholder="请输入提现支付宝"/></view>
			</view>
			<view style="text-align: center;">
				<text class="time-btn" @tap="txConfirm()">确认提现</text>
			</view>
		</view>
		
		
		<view v-if="status != 200 && status != 0" style="font-size: 32rpx;margin-top: 50rpx;">链接已使用或失效</view>
		<view style="text-align: center;margin-top: 100rpx;" v-if="success">
			<image src="/static/images/success.png" style="width: 120rpx;height: 120rpx;"></image>
			<view style="font-size: 32rpx;margin-top: 20rpx;">提现成功，等待审核</view>
		</view>
    </view>
	
</template>

<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
//index.js
//获取应用实例
export default {
    data() {
        return {
			status:0,
			code:'',
			pic:'ic_logo.png',
			balance:0,
			txBalance:0,
			imagebaseurl: getApp().globalData.fileDomain,
			address:'',
			aliPay:'',
			success:false
        };
    },
    onLoad: function (e) {
		
		if (e.code) {
			this.code = e.code;
			uni.showLoading();
			let that = this;
			WXAPI.withdrawalLinkDetail({
				code: e.code,
			}).then((res) => {
				uni.hideLoading();
				that.status = res.code
			    if (res.code == 200) {
					that.balance = res.data.amount;
				} else {
					that.balance = 0;
				}
			})
			this.onLocate();
		}
		
		// this.getNotice();
		// AUTH.checkHasLogined().then((isLogined) => {
		// if (isLogined) {
		// 		this.initPage();
		// 		this.wxlogin = true;
		// 		this.onLocate("自动访问");
		// 	}
		// });
    },
	onReachBottom: function () {},
    methods: {
		onLocate() {
			let _this = this;
			uni.getLocation({
				type: 'gcj02',
				geocode: true,
				isHighAccuracy: true,
				success: function(location) {
					uni.request({
						url: "/ws/geocoder/v1/",
						data: {
							key: "3QHBZ-UQXYJ-OWAFU-DFBJH-X6DS7-PXFU7",
							location: location.latitude + "," + location.longitude
						},
						success: (res) => {
							var result = eval("(" + JSON.stringify(res) + ")");
							// v2.1.9: 腾讯逆地理返回结构判空——配额超限/异常返回时不再裸链报错
							if (result.data && result.data.result && result.data.result.formatted_addresses) {
								_this.address = result.data.result.formatted_addresses.recommend + "(" + result.data.result.formatted_addresses.standard_address + ")"
							}
						},
						fail: (err) => {
							console.log(t);
						}
					})
				},
				fail: function(t) {
					console.log('获取当前位置的经纬度-失败');
					console.log(t);
				}
			})
		},
		
		txConfirm() {
			let _this = this;
			if (this.aliPay == '') {
				uni.showToast({icon: 'none',title: '请输入提现支付宝'}); 
			    return false;
			}
			uni.showLoading();
			WXAPI.withdrawalLink({
				code: this.code,
				aliPay: this.aliPay,
				address: this.address
			}).then((res) => {
				uni.hideLoading();
				if (res.code == 200) {
					// uni.showToast({title: '提现成功，等待审核'});
					setTimeout(() => {
						_this.success = true
					}, 500);
				} else {
					uni.showToast({
					    title: res.msg,
					    icon: 'none'
					});
				}
			})
		},
    }
};
</script>
<style>
@import './withdrawalLink.css';
</style>
