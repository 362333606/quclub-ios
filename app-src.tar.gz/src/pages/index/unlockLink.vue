<template>
    <view class="partner-container" style="padding-top: 50%">
		
		<view class="Withdrawal-content" v-if="balance > 0 && !success">
			<view style="text-align: center;margin-bottom: 80rpx;">
				<image :src="imagebaseurl + pic" class="userinfo-avatar"></image>
			</view>
			<view class="wallet" >
				<view class="wallet-info" >
					<view class="wallet-all" v-if="paySuccess">
						<text class="wallet-title">我的微信</text>
						<view class="wallet-balance" style="margin-top: 10rpx;">
							<text>{{unlockInfo}}</text>
							<text @click="handleCopy" style="float: right;font-size: 32rpx;border: 1px solid #fff;padding: 4rpx 20rpx;border-radius: 10rpx;">复制</text>
						</view>
						
					</view>
					<view class="wallet-all" v-else>
						<text class="wallet-title">解锁后查看</text>
						<view class="wallet-title" style="margin-top: 10rpx;">解锁金额: {{balance}}</view>
					</view>
					
				</view>
			</view>
			
			<view class="info-input" v-if="paySuccess">
				<view class="title" style="font-size: 32rpx;">你的微信</view>
				<view class="input"><input v-model="aliPay" type="text" class="apply_input"  placeholder="请输入你的微信"/></view>
			</view>
			<view style="text-align: center;margin-top: 100rpx;" v-if="!paySuccess">
				<text class="time-btn" @tap="payConfirm()" style="padding: 10px 50px;">立即支付</text>
			</view>
			<view style="text-align: center;margin-top: 100rpx;" v-if="paySuccess">
				<text class="time-btn" @tap="txConfirm()" style="padding: 10px 50px;">确认</text>
			</view>
		</view>
		
		
		<view v-if="status != 200 && status != 0" style="font-size: 40rpx;margin-top: 50rpx;margin-left: 30rpx;">链接失效或不存在</view>
		<view style="text-align: center;margin-top: 100rpx;" v-if="success">
			<image src="/static/images/success.png" style="width: 120rpx;height: 120rpx;"></image>
			<view style="font-size: 32rpx;margin-top: 20rpx;">确认成功</view>
		</view>
		
		<view class="show-popup" v-if="isPay">
			<view class="popup-mask" @click="closePay"></view>
			<view class="popup-contents">
				<payment @toCancel="closePay" @okPay="okPay" :payTypeId="8" :payOrderId="payOrderId" :payAmount="payAmount"></payment>
			</view>
		</view>
    </view>
	
</template>

<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
import payment from '@/components/payment';
import { copyToClipboard } from '@/utils/copy.js';
//index.js
//获取应用实例
export default {
	components: {
		payment
	},
    data() {
        return {
			status:0,
			code:'',
			pic:'ic_logo.png',
			balance:0,
			unlockInfo:'',
			imagebaseurl: getApp().globalData.fileDomain,
			address:'',
			aliPay:'',
			isPay:false,
			paySuccess:false,
			success:false,
			payOrderId:0,
			payAmount:0
        };
    },
    onLoad: function (e) {
		
		if(this.isWeiXinLogin() && (!uni.getStorageSync('user_op') || uni.getStorageSync('user_op') == '0')) {
			this.getCode();
		}
		var loginToken = uni.getStorageSync('bestpw-Token');
		if (loginToken) {
		    if (e.msg) {
		    	this.code = e.msg;
		    	uni.showLoading();
		    	let that = this;
		    	WXAPI.unlockLinkDetail({
		    		code: e.msg,
		    	}).then((res) => {
		    		uni.hideLoading();
		    		that.status = res.code
		    	    if (res.code == 200) {
		    			that.balance = res.data.price;
						that.pic = res.data.pic;
		    			if (res.data.status == 1) {
		    				that.paySuccess = true;
		    				that.unlockInfo = res.data.info
		    			}
		    		} else {
		    			that.balance = 0;
		    		}
		    	})
		    }
		}
    },
	onReachBottom: function () {},
    methods: {
		async handleCopy() {
		   await copyToClipboard(this.unlockInfo);
		},
		payConfirm() {
			let that = this;
			uni.showLoading();
			WXAPI.orderCreate({code: that.code, type: 10}).then(function (res) {
				uni.hideLoading();
			    if (res.code == 200) {
			        that.payOrderId = res.data.id;
			        that.payAmount = res.data.amount;
			        that.isPay = true;
			    } else {
					uni.showModal({
					    title: '错误',
					    content: res.msg,
					    showCancel: false
					});
				}
			    
			});
		},
		closePay: function() {
			this.isPay = false;
		},
		okPay: function() {
			this.paySuccess = true;
			this.isPay = false;
			// #ifdef H5
			window.location.reload();
			// #endif
			// #ifdef APP-PLUS
			uni.reLaunch({ url: '/pages/index/index' });
			// #endif
		},
		getCode () {
			const code = this.getUrlParam('code');
			//截取路径中的code，如果没有就去微信授权，如果已经获取到了就直接传code给后台获取openId
			const local = window.location.href;
			if (code == null || code === '') {
				window.location.href = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx5a64ae4cbfea3f43&redirect_uri=' + encodeURIComponent(local) + '&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect'
			} else {
				this.wxLogin(code) //把code传给后台获取用户信息
			}
		},
		wxLogin: function(t) {
			uni.showLoading(),
			WXAPI.wxLogin({
				code: t
			}).then((res) => {
				uni.hideLoading();
				if (res.code == 200) {
					uni.setStorageSync('bestpw-Token',res.data.token)
					uni.setStorageSync('user_pic',res.data.pic);
					uni.setStorageSync('user_op',res.data.openid);
					// #ifdef H5
					window.location.reload();
					// #endif
					// #ifdef APP-PLUS
					uni.reLaunch({ url: '/pages/index/index' });
					// #endif
				} else {
					uni.showToast({
						icon: "none",
						title: res.msg
					})
				}
			})
		},
		//判断是否微信登陆
		isWeiXinLogin() {
			// #ifdef APP-PLUS
			return false; // APP非微信环境,wx oauth流程整体跳过(v2.1.2)
			// #endif

		    var ua = window.navigator.userAgent.toLowerCase();
		    if (ua.match(/MicroMessenger/i) == 'micromessenger') {
		        return true; // 微信中打开
		    } else {
		        return false; // 普通浏览器中打开
		    }
		},
		// 解析URL 参数
		getUrlParam(name) {
			let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)');
			let r = window.location.search.substr(1).match(reg);
			if (r != null) {
				return unescape(r[2]);
			}
			return null;
		},
		
		txConfirm() {
			let _this = this;
			if (this.aliPay == '') {
				uni.showToast({icon: 'none',title: '请输入你的微信'}); 
			    return false;
			}
			uni.showLoading();
			WXAPI.unlockLink({
				code: this.code,
				aliPay: this.aliPay
			}).then((res) => {
				uni.hideLoading();
				if (res.code == 200) {
					// uni.showToast({title: '提现成功，等待审核'});
					setTimeout(() => {
						_this.success = true
					}, 500);
				} else {
					uni.showToast({
					    title: res.msg,
					    icon: 'none'
					});
				}
			})
		},
    }
};
</script>
<style>
@import './withdrawalLink.css';
</style>
