<template>
    <view class="goods-container">
		<view class="message-list">
			<view class="message-item" @tap="navToPage(item)" v-for="(item, index) in messageList" :key="index" v-if="item.type == 1 || item.type == 4 || ((item.type == 0 || item.type == 2 || item.type == 3) && item.best)">
				<view class="message-time">
					<text>{{item.createDate}}</text>
				</view>
				<view class="message-item-content">
					<view class="message-item-head">
						<view>
							<image v-if="item.type == 1" src="/static/images/nav/message_dongt.png"></image>
							<image v-if="item.type == 2 || item.type == 3" src="/static/images/nav/message_fadan.png"></image>
							<image v-if="item.type == 0" src="/static/images/nav/message_baog.png"></image>
						</view>
						<view class="message-item-title">{{item.title}}</view>
						<view class="message-item-head-info">查看详情></view>
					</view>
					<view class="message-item-bottom" v-if="item.type == 1 || item.type == 4">
						{{item.remark}}
					</view>
					<view class="message-item-best" v-if="(item.type == 0 || item.type == 2 || item.type == 3) && item.best">
						<view class="best-content">
							<view class="best-logo">
								<image :src="imagebaseurl + item.best.pic" mode="aspectFill"></image>
							</view>
							<view class="best-info">
								<text class="best-name">{{item.best.name}}</text>
								<text class="best-item-tag" :class="item.best.sex == 1 ? 'man':'woman'">
									<image v-if="item.best.sex == 2" class="sex" src="/static/images/nav/woman.png"></image>
									<image v-if="item.best.sex == 1" class="sex" src="/static/images/nav/man.png"></image>
									<text>{{item.best.age}}</text>
								</text>
								<image src="/static/images/nav/message_ok.png" class="icon"></image>
							</view>
							<view class="best-info">
								<text>{{item.best.height}} cm</text>
								<text>｜</text>
								<text>{{item.best.weight}} kg</text>
								<text>｜</text>
								<text>{{item.best.constellation}}</text>
								<text>｜</text>
								<text>{{item.best.profession}}</text>
							</view>
							<view class="best-imgs">
								<image  v-for="(img,index) in (item.imgs)" :src="imagebaseurl + img" class="slide-image" mode="aspectFill" :lazy-load="true"  />
							</view>
						</view>
						<view class="best-play">去约玩</view>
					</view>
				</view>
			</view>
			
		</view>
		
		
		
       
        <!-- <view v-if="!(loadingMoreHidden ? true : false)" class="no-more-goods">
            <image src="/static/images/empty_collection.png" class="no-order-img"></image>
            <view class="text">还没有任何动态呢</view>
        </view> -->

    </view>
</template>

<script>
//index.js
//获取应用实例
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
const tools = require('../../utils/tools.js');
export default {
    data() {
        return {
			imagebaseurl: getApp().globalData.fileDomain,
            wxlogin: false,
            loadingMoreHidden: false,
			curPage: 1,
			pageSize: 10,
			totalPages:0,
			messageList: [],
			platform:0,
        };
    },
    onLoad: function (options) {
		if (options?.platform) {
			let title = "";
			if (options.platform == 0) {
				title = "系统消息";
			} else {
				title = "约玩列表";
			}
			uni.setNavigationBarTitle({
				title: title
			});
			this.platform = options.platform;
			this.getList();
		}
    },
	onReachBottom: function () {
		// 滚动刷新
		if (this.curPage == this.totalPages) {
			return;
		}
		this.setData({
		    curPage: this.curPage + 1
		});
		this.getList();
	},
    methods: {
		navToPage(item) {
			let url = "";
			if (item.type == 0) {
				url = "/pages_details/goods-details/index?id=" + item.keyId;
			} else if (item.type == 1) {
				getApp().globalData.id = 1;
				uni.switchTab({
				    url: '/pages/plaza-list/index'
				});
				return;
			} else if (item.type == 2) {
				// url = "/pages_release/release/best?id=" + item.keyId;
				url = "/pages_details/goods-details/index?id=" + item.keyId;
			} else if (item.type == 3) {
				url = "/pages_details/goods-details/index?id=" + item.keyId;
			}
			uni.navigateTo({
			    url: url
			});
		},
        closeAuth() {
            uni.navigateBack();
        },

        getList() {
			
			uni.showLoading({
			    title: '加载中'
			});
            WXAPI.messageList({
				page: this.curPage,
				pageSize: this.pageSize,
				platform: this.platform
			}).then((res) => {
                if (res.code == 200) {
					var newArray = res.data.content;
					this.messageList = [...this.messageList,...newArray]
					this.totalPages = res.data.totalPages;
                }
				uni.hideLoading();
            });
        }
    }
};
</script>
<style>
@import './list.css';
</style>
