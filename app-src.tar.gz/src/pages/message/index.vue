<template>
    <view class="goods-container">
		<view :style="{ 'padding-top' : statusBarHeight +'rpx',  }"></view>
		<view class="gc-head">
			<text class="gc-head-title">消息</text>
		</view>
		
		<uni-list :border="false">
			<uni-list-chat 
				:avatar-circle="true" title="系统消息" 
				avatar="/static/images/nav/message_1.png" 
				:note="title1" :time="time1" 
				badge-positon="left" :badge-text="unReadCount"
				:clickable="clickable"
				@click="onMessage(0)" />
			<uni-list-chat 
				:avatar-circle="true" title="约玩列表"
				avatar="/static/images/nav/message_2.png" 
				:note="title2" :time="time2" 
				badge-positon="left" :badge-text="unReadCount1"
				:clickable="clickable1"
				@click="onMessage(1)" />
			<uni-list-chat
				:avatar-circle="true" title="聊天消息"
				avatar="/static/images/nav/im.png" 
				:note="title3"
				badge-positon="left" :badge-text="unReadCount2"
				:clickable="clickable2"
				@click="openConversationList()" />
		</uni-list>

    </view>
</template>

<script>
//index.js
//获取应用实例
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
import { TUILogin } from '@tencentcloud/tui-core';
// #ifdef APP-PLUS || H5
import { TUIChatKit } from '../../TUIKit';
TUIChatKit.init();
// #endif
let vueVersion = 2;
// #ifdef VUE3
vueVersion = 3;
// #endif
export default {
    data() {
        return {
            wxlogin: false,
            unReadCount: 0,
			unReadCount1: 0,
			unReadCount2: 0,
			title1:'登录后查看',
			title2:'登录后查看',
			title3:'登录后查看',
			time1:'',
			time2:'',
			clickable:false,
			clickable1:false,
			clickable2:false,
            loadingMoreHidden: false,
			statusBarHeight: uni.getMenuButtonBoundingClientRect().bottom,
        };
    },
	onLoad: function () {
		WXAPI.initIM().then((res) => {
		    if (res.code == 200) {
				TUILogin.login({
				  SDKAppID: res.data.appId,
				  userID: res.data.userId, 
				  userSig: res.data.userSig, 
				  useUploadPlugin: true, // If you need to send rich media messages, please set to true.
				  framework: `vue2` // framework used vue2 / vue3
				}).catch(() => {});
				this.title3 = "查看聊天消息";
				this.unReadCount2 = res.data.unreadMsgNum;
				this.clickable2 = true;
		    } else {
				this.title3 = res.msg
			}
		});
	},
    onShow: function () {
		AUTH.checkHasLogined().then(isLogined => {
			this.setData({
			    wxlogin: isLogined
			});
			if(isLogined){
				uni.showLoading({
					title: '加载中'
				});
				this.getList();
				this.getCount();
				uni.hideLoading();
			}
		});
    },
    methods: {
       // 打开会话列表
		openConversationList() {
			// 自研聊天(令曦2026-09-03): 跳webview会话列表
			uni.navigateTo({ url: '/pages/chat/webview?mode=conv' });
		},
		onMessage(type) {
			uni.navigateTo({
			    url: '/pages/message/list?platform=' + type
			});
		},
        getCount() {
			WXAPI.messageUnReadCount({
				type : 0
			}).then((res) => {
				if (res.code == 200) {
					this.unReadCount = res.data;
				}
			});
			WXAPI.messageUnReadCount({
				type : 1
			}).then((res) => {
				if (res.code == 200) {
					this.unReadCount1 = res.data;
				}
			});
		},
		getList() {
			WXAPI.messageList({
				page: 1,
				pageSize: 1,
				platform: 0
			}).then((res) => {
			    if (res.code == 200) {
					if (res.data.content.length == 0) {
						this.title1 = "暂无消息";
						return;
					}
					let message = res.data.content[0];
					this.title1 = message.title;
					this.time1 = message.createDate;
					this.clickable = true;
			    }
				uni.hideLoading();
			});
			WXAPI.messageList({
				page: 1,
				pageSize: 1,
				platform: 1
			}).then((res) => {
			    if (res.code == 200) {
					if (res.data.content.length == 0) {
						this.title2 = "暂无消息";
						return;
					}
					let message = res.data.content[0];
					this.title2 = message.title;
					this.time2 = message.createDate;
					this.clickable1 = true;
			    }
				uni.hideLoading();
			});
		}
    }
};
</script>
<style>
@import './index.css';
</style>
