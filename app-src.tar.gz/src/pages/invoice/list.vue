<template>
    <view style="height: 100%">
        <view v-if="invoiceList.length <= 0" class="weui-loadmore weui-loadmore_line" style="margin-top: 200rpx">
            <view class="weui-loadmore__tips weui-loadmore__tips_in-line">暂无数据</view>
        </view>
        <view v-else class="weui-panel weui-panel_access">
            <view class="weui-panel__bd">
                <view class="weui-media-box weui-media-box_text" v-for="(item, index) in invoiceList" :key="index">
                    <view class="weui-media-box__title weui-media-box__title_in-text">
                        <text style="color: red">￥ {{ item.amount }}</text>
                        <view class="weui-badge" style="margin-left: 5px">{{ item.consumption }}</view>
                        <text v-if="item.status == 0" style="color: gray; margin-left: 10px; font-size: 14px">待处理</text>
                        <text v-if="item.status == 1" style="color: red; margin-left: 10px; font-size: 14px">不通过</text>
                        <text v-if="item.status == 2" style="color: orange; margin-left: 10px; font-size: 14px">开票中</text>
                        <text v-if="item.status == 3" style="color: green; margin-left: 10px; font-size: 14px">已开票</text>
                    </view>

                    <view class="weui-media-box__desc">{{ item.comName }}</view>

                    <view class="weui-media-box__desc" style="margin-top: 10rpx">{{ item.dateAdd }}</view>
                </view>
            </view>
        </view>
        <float-menu />
    </view>
</template>

<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
export default {
    data() {
        return {
            invoiceList: []
        };
    }
    /**
     * 生命周期函数--监听页面加载
     */,
    onLoad: function (options) {},
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        const that = this;
        AUTH.checkHasLogined().then((isLogined) => {
            if (isLogined) {
                WXAPI.invoiceList({
                    token: uni.getStorageSync('bestpw-Token')
                }).then((res) => {
                    if (res.code == 0) {
                        that.setData({
                            invoiceList: res.data.result
                        });
                    } else {
                        that.setData({
                            invoiceList: []
                        });
                    }
                });
            } else {
                uni.showModal({
                    title: '提示',
                    content: '本次操作需要您的登录授权',
                    cancelText: '暂不登录',
                    confirmText: '前往登录',
                    success(res) {
                        if (res.confirm) {
                            uni.switchTab({
                                url: '/pages/my/index'
                            });
                        } else {
                            uni.navigateBack();
                        }
                    }
                });
            }
        });
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {},
    methods: {}
};
</script>
<style>
@import './list.css';
</style>
