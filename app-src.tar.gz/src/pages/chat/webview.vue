<template>
	<view class="page">
		<web-view :src="chatUrl" @message="onMessage"></web-view>
	</view>
</template>

<script>
/**
 * 自研聊天webview页（令曦 2026-09-03）
 * APP内加载线上自研聊天页，聊天页更新无需发版
 * 参数: bestId=陪玩id(mode=chat默认) / mode=conv会话列表
 */
export default {
	data() {
		return {
			chatUrl: ''
		}
	},
	onLoad(q) {
		const token = encodeURIComponent(uni.getStorageSync('bestpw-Token') || '');
		if (q.mode === 'conv') {
			this.chatUrl = 'https://best.qiuyu8.cn/chat-api/conversations.html?token=' + token + '&v=220';
		} else {
			this.chatUrl = 'https://best.qiuyu8.cn/chat-api/chat.html?bestId=' + (q.bestId || '') + '&token=' + token + '&v=220';
		}
		uni.setNavigationBarTitle({ title: '聊天' });
	},
	onMessage(e) {
		// 预留: 聊天页postMessage通知APP(如未读数/退出)
		const d = e && e.detail && e.detail.data && e.detail.data[0];
		if (d && d.action === 'back') {
			uni.navigateBack();
		}
	}
}
</script>

<style>
.page { width: 100%; height: 100vh; background: #fff; }
</style>
