<template>
	<view class="content">
		<view class="header">
			<image src="https://oss.bestpw.cn/ic_logo.png"></image>
		</view>
		<view class="list">
			
			<view class="list-call">
				<input class="biaoti" v-model="form.phone" placeholder="请输入绑定手机号" />
			</view>
			<view class="list-call input-new ">
				<input class="biaoti"  placeholder="请输入短信验证码" v-model="form.code" />
				<view  @click="getCodTime">
					<view class="get-code-text row-center code-new" >{{msgCodeText}}</view>
				</view>
			</view>
			<view class="list-call">
				<input class="biaoti" v-model="form.password" type="text" maxlength="15" placeholder="请输入8到16位包含字母和数字密码" :password="!showPassword" />
				<image class="img" :src="showPassword?'/static/images/op.png':'/static/images/cl.png'" @tap="display"></image>
			</view>
			<view class="list-call">
				<input class="biaoti" v-model="form.confirmPassword" type="text" maxlength="15" placeholder="请再次输入密码" :password="!hide" />
				<image class="img" :src="hide?'/static/images/op.png':'/static/images/cl.png'" @tap="hide_two"></image>
			</view>
			
		</view>
		
		<view class="dlbutton" hover-class="dlbutton-hover" @tap="postReset">
			<text>确认重置</text>
		</view>
		
	</view>
</template>

<script>
	const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
	const app = getApp();
	export default {
		onLoad(){
		},
		onUnload(){
			clearInterval(js)
			this.second = 0;
		},
		data() {
			return {
				form: {
					phone:'',
					code:'',
					password:'',
					confirmPassword:'',
				},
				showPassword:false,
				hide:false,
				singSong:3,
				msgCodeText:'获取验证码',
				hasSend:false
			};
		},
		computed:{
			},
			
		methods: {
			display() {
			    this.showPassword = !this.showPassword
			},
			hide_two:function () {
				this.hide = !this.hide
			} ,
			
			/**
			   * 获取倒计时
			   */
			getCodTime(){
				if(this.form.phone ==''){
					uni.showToast({
						title:"请输入绑定手机号",
						icon:"none"
					})
					return;
				}
				if(this.hasSend){
					return;
				}
				uni.showLoading();
				WXAPI.getMsgCode({phone: this.form.phone, type:2}).then((res) => {
					uni.hideLoading()
				    if (res.code == 200) {
						uni.showToast({title: '验证码已发送'}); 
						let code=60
						this.msgCodeText=code + ' S'
						this.hasSend=true
						this.codeInterval=setInterval(()=>{
						  code--
						  this.msgCodeText=code+ ' S'
						  if(code<0){
						    clearInterval(this.codeInterval)
						    this.msgCodeText='重新发送'
						    this.hasSend=false
						  }
						},1000)
				    } else {
						uni.showToast({
						    icon: 'none',
						    title: res.msg
						}); 
					}
				});
			  },
			  postReset() {
				  if (this.form.phone=="") {
				      uni.showToast({
				          icon: 'none',
				          title: '请输入绑定手机号'
				      });
				      return;
				  }
				  if(this.form.code==''){
				  	uni.showToast({
				  		title:'请输入短信验证码',
				  		icon:'none'
				  	});
				  	return;
				  }
				  if(this.form.password==''){
				  	uni.showToast({
				  		title:'请输入密码',
				  		icon:'none'
				  	});
				  	return;
				  }
				  if(this.form.confirmPassword==''){
				  	uni.showToast({
				  		title:'请再次输入密码',
				  		icon:'none'
				  	});
				  	return;
				  }
				  if(this.form.password != this.form.confirmPassword){
				  	uni.showToast({
				  	    icon: 'none',
				  	    title:'两次密码不一样'
				  	});
				  	return;
				  }
				  uni.showLoading();
				  WXAPI.resetPwd(this.form).then((res) => {
				  	uni.hideLoading();
				  	if(res.code == 200){
				  		uni.showToast({title: '重置密码成功'}); 
				  		setTimeout(() => {
				  		   uni.navigateTo({
				  		   	url:'/pages/login/login'
				  		   })
				  		}, 1500);
				  		
				  	}else{
				  		uni.showToast({
				  		    icon: 'none',
				  		    title: res.msg
				  		}); 
				  	}
				      
				  });
			  }
		}
	}
</script>

<style scoped lang="scss">
	.content {
		display: flex;
		flex-direction: column;
		justify-content:center;
		background-color: white;
	}

	.content { height: 100vh; }

	.header {
		width:161upx;
		height:161upx;
		border-radius:50%;
		margin-top: 30upx;
		margin-left: auto;
		margin-right: auto;
	}
	.header image{
		width:161upx;
		height:161upx;
		border-radius:50%;
	}
	
	.list {
		display: flex;
		flex-direction: column;
		padding-top: 50upx;
		padding-left: 70upx;
		padding-right: 70upx;
	}
	.list-call{
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		height: 100upx;
		color: #333333;
		border-bottom: 1upx solid rgba(230,230,230,1);
	}
	.list-call image{
		width: 34upx;
		height: 28upx;
	}
	.list-call .biaoti{
		flex: 1;
		text-align: left;
		font-size: 15px;
		line-height: 100upx;
		margin-left: 16upx;
	}
	.get-code-text{
		    background: #68AFEF;
		    padding: 5px 10px;
		    color: #fff;
		    border-radius: 25px;
		    font-size: 12px;
	}
	.yzm {
		color: #FF7D13;
		font-size: 24upx;
		line-height: 64upx;
		padding-left: 10upx;
		padding-right: 10upx;
		width:auto;
		height:64upx;
		border:1upx solid #FFA800;
		border-radius: 50upx;
	}
	.yzms {
		color: #999999 !important;
		border:1upx solid #999999;
	}
	.dlbutton {
		color: #FFFFFF;
		font-size: 34upx;
		width:470upx;
		height:80upx;
		background-image: none!important;
		background-color: #68AFEF!important;
		border-radius:50upx;
		line-height: 80upx;
		text-align: center;
		margin-left: auto;
		margin-right: auto;
		margin-top: 100upx;
	}
	.dlbutton-hover {
		background:linear-gradient(-90deg,rgba(63,205,235,0.9),rgba(188,226,158,0.9));
	}
	.suggest{
		color: #DB0112;
		padding:20px 30px;
		line-height: 25px;
		font-size: 16px;
	}
	.suggest span{
		color: #666;
	}
	
	.mask-style{
		position: fixed;
		top: 0;
		left:0;
		width: 100%;
		height: 100%;
		z-index:888;
		background-color: rgba(0, 0, 0, 0.6);
	}
	.btn{
		height: 120rpx;
		display: flex;
		flex-direction: row;
		border-top:1px solid #eeeeee;
		.cancel{
			display: flex;
			flex: 1;
			justify-content: center;
			align-items: center;
			margin: 10px 10px;
			border: 1px solid #eeeeee;
			border-radius: 25px;
		}
		.confirm{
			display: flex;
			flex: 1;
			justify-content: center;
			align-items: center;
			margin: 10px 10px;
			background-color: #FFC107;//DB0112
			color: #fff;
			border-radius: 25px;
		}
	}
	.wxbox{
		position: fixed;
		top:30%;
		z-index: 998;
		width:80%;
		left:10%;
		background-color: #fff;
		border-radius:20rpx;
		.close{
			position: absolute;
			top:10px;
			right:10px;
			z-index: 999;
			text-align: center;
		}
		.weixin{
			font-size: 17px;
			padding: 15px 0;
			color: #333333;
			text-align: center;
			border-bottom: 1px solid #f5f5f5;
			
		}
		.tips{
			padding:10rpx 25rpx;
			font-size:15px;
			color:#666;
			display: flex;
			.left-title{
				width: 80px;
			}
			.right-name{
				flex: 1;
			}
		}
	}
</style>

<style>
	/* v2.1.5: APP上uni-page高度链断裂致flex居中失效(H5默认有高度) */

	page { height: 100%; }
	uni-page-body { height: 100%; }

</style>
