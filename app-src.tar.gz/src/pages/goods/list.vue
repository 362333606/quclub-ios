<template>
    <view style="height: 100%">
        <view class="header">
			<view class="content" @click="useOutClickSide">
				<!-- <image class="search-box-image" src="/static/images/icon/location.png" style="width: 26px;height: 26px;"></image> -->
				<easy-select ref="easySelect" style="width: 52px;position: relative;" :options="options" :windowHeight="800" :value="selecValue" @selectOne="selectOne"></easy-select>
				<image class="search-box-image" src="/static/images/nav/sanjiao.png" style="width: 8px;height: 8px;"></image>
			</view>
            <view class="search">
                <view class="search-box" @tap="headerSearch">
					 <text class="search-box-text">搜索 名字/城市/性别</text>
                    <image class="search-box-image" src="/static/images/search.png"></image>
                </view>
            </view>
        </view>

        <view class="list2-box">
            <navigator :url="'/pages_details/goods-details/index?id=' + item.id" class="top" v-for="(item, index) in goods" :key="index" v-if="index < 3">
                <view class="list2 shadow bg-white" style="position: relative;">
                    <!-- <image class="topicon" :src="'/images/nav/king' + index + '.png'"></image> -->
                    <image class="img" mode="aspectFill" :src="imagebaseurl + item.pic+'?x-oss-process=image/resize,m_fill,h_220,w_220'" :lazy-load="true"></image>
                    <view class="goods-info">
                        <view class="buy-info">
							<view class="title best-item-tag" :class="item.sex == 1 ? 'man':'woman'">
							    <image v-if="item.sex == 2" mode="aspectFill" class="sex" src="/static/images/nav/woman.png"></image>
							    <image v-if="item.sex == 1" mode="aspectFill" class="sex" src="/static/images/nav/man.png"></image>
								<text style="margin-left: 10rpx">{{item.age}}</text>
							</view>
                            <view class="yuyue">马上预约</view>
                        </view>
                    </view>
					<view class="top-goods-name">{{item.name}}</view>
                </view>
            </navigator>
        </view>

        <view class="listall">
            <navigator :url="'/pages_details/goods-details/index?id=' + item.id" class="shadow goods-new-item" v-for="(item, index) in goods" :key="index" v-if="index > 2">
			
				<view class="list1">
					<view :class="item.auths.includes('真人认证') || item.auths.includes('视频认证') ? 'best-item-head head-active' : 'best-item-head'">
						  <image class="img" mode="aspectFill" :src="imagebaseurl+item.pic+'?x-oss-process=image/resize,m_fill,h_200,w_200'" :lazy-load="true"></image>
						  <text v-if="item.auths.includes('真人认证') && !item.auths.includes('视频认证')">真人认证</text>
						  <text v-if="item.auths.includes('视频认证')">视频认证</text>
					</view>
				    <view class="goods-info">
				        <view class="title">
							<text class="goods-name">{{ item.name }}</text>
							<view class="best-item-tag" :class="item.sex == 1 ? 'man':'woman'">
								<image v-if="item.sex == 2" mode="aspectFill" class="sex" src="/static/images/nav/woman.png"></image>
								<image v-if="item.sex == 1" mode="aspectFill" class="sex" src="/static/images/nav/man.png"></image>
								<text style="margin-left: 10rpx">{{item.age}}</text>
							</view>
							<view class="best-item-tag" :class="item.sex == 1 ? 'man':'woman'" v-if="item.auths.includes('颜值认证')">
								<image mode="aspectFill" class="sex" src="/static/images/nav/yz_auth.png"></image>
									<text style="margin-left: 6rpx;">颜值认证</text>
							</view>
				        </view>
						<view class="goods-tags">
						    <view class="num" style="white-space:nowrap;">
								<text class="info-desc" v-for="(mk,index) in (item.tags || '').split(',')">{{mk}}</text>
							</view>
						</view>
				    </view>
					<view class="yuyue2">预约TA</view>
				</view>
				<view class="swiper-container" v-if="item.imgs.length > 0">
					<swiper>
						<swiper-item v-for="(yun,index) in (item.imgs)" style="width: 31%;" :key="index" @touchmove.stop="stopTouchMove">
				
							<image :src="imagebaseurl + yun+'?x-oss-process=image/resize,m_fill,h_500,w_300'" class="slide-image" mode="aspectFill" :lazy-load="true"  />
						</swiper-item>
					</swiper>
				</view>
				
            </navigator>
        </view>

        <view v-if="goods.length == 0" class="no-more-goods">
            <image src="/static/images/empty_goods.png" class="no-order-img"></image>
            <view class="text">还没有推荐呢</view>
        </view>

        <!-- float-menu / -->
    </view>
</template>

<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
export default {
    data() {
        return {
            listType: 2,
			imagebaseurl: getApp().globalData.fileDomain,
			image_list:[],
            // 1为1个商品一行，2为2个商品一行
            name: '',
            // 搜索关键词
            orderBy: '',
            // 排序规则
            goods: [],
			page: 1,
			totalPages: 0,
            top: [],
			selecValue: uni.getStorageSync('cityindex')?uni.getStorageSync('cityindex'):'武汉',
			options:[],		
        };
    },
    onLoad: function (options) {
        this.setData({
            name: options.name,
        });
        this.search();
		this.getCitys();
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
		// 滚动刷新
		if (this.page == this.totalPages) {
			return;
		}
		this.setData({
		    page: this.page + 1
		});
		this.search();
	},
    methods: {
		useOutClickSide() {
			this.$refs.easySelect.hideOptions && this.$refs.easySelect.hideOptions()
		},
		stopTouchMove(){
			return false;
		},
		selectOne(options) {
		    this.selecValue = options.title;
			uni.setStorageSync('cityindex',options.title);
			this.changeCtity();
		},
		getCitys(){
			WXAPI.citys().then((res) => {
				if(res.code == 200){
					this.options = res.data;
				}
				// uni.setStorageSync('bestpw-Token',res.data[0].base.token);
			});
		},
        /**
         * 生命周期函数--监听页面加载
         */
        headerSearch() {
            uni.navigateTo({
                url: '/pages/search/index'
            });
        },
		changeCtity(){
			this.page = 1;
			this.goods = [];
			this.search();
			
		},
        async search() {
            // 搜索商品
            uni.showLoading({
                title: '加载中'
            });
            const _data = {
                page: this.page,
                pageSize: 7,
				recommend: 1,
				sex: uni.getStorageSync('sex_mark')?uni.getStorageSync('sex_mark'):2,
				city:uni.getStorageSync('cityindex')?uni.getStorageSync('cityindex'):'武汉',
            };
            if (this.name) {
                _data.nameLike = this.name;
            }
            
            const res = await WXAPI.goods(_data);
            uni.hideLoading();
            if (res.code == 200) {
				let newArray = res.data.content;
				this.goods = [...this.goods,...newArray];
				this.setData({
					totalPages: res.data.totalPages,
				});
            }
        },

        bindinput(e) {
            this.setData({
                name: e.detail.value
            });
        },

        bindconfirm(e) {
            this.setData({
                name: e.detail.value
            });
            this.search();
        },

        filter(e) {
            this.setData({
                orderBy: e.currentTarget.dataset.val
            });
            this.search();
        }
    }
};
</script>
<style>
@import './list.css';
</style>
