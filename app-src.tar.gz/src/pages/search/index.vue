<style>
	.header-search-btn{
		color: #68AFEF!important;
	}
	.goods-box{
		border: 0.5px solid #68AFEF;
		border-radius: 20px;
		padding: 10px;
		/* width: 190px !important; */
	}
	.goods-title{
		/* width: 180px!important; */
		font-size: 12px!important;
	}
	.goods-price{
		width: 30px!important;
		float: right;
		margin-right: 3px;
	}
	.item{
		margin-right: 50px!important;
		color: #000000!important;
	}
	.search-box{
		background-color: white;
	}
</style>
<template>
    <view style="height: 100%">
        <!-- pages/search/search.wxml -->
        <view class="container">
            <view class="type-header-menu">
                <view class="type-search">
                    <image src="/static/images/search.png" />
                    <input
                        :class="'input ' + (searchInput == true ? 'active' : '')"
                        type="text"
						v-model="searchValue"
                        confirm-type="search"
                        placeholder="搜索 名字/城市/性别"
                        @focus="searchFocus"
                        @confirm="searchFun"
                        :focus="true"
                    />
                    <view v-if="!search" @tap="searchClose" class="header-search-btn">取消</view>
                </view>
            </view>
            <view class="search-cont-box" v-if="tags" style="width: 100%">
                <view class="title-and-btn">
                    <view class="title">标签</view>
                    <!-- <view class="btn" @tap="clearHistory">
                        <image src="/static/images/del.png" />
                    </view> -->
                </view>
                <view class="keywords-li">
                    <block v-for="(item, index) in tags" :key="index">
                        <view @tap="goSearch" class="item" :data-text="item">{{ item }}</view>
                    </block>
                </view>
            </view>
        </view>
        <view v-if="!search" :class="'search-box ' + iponesc">
            <navigator :url="'/pages_details/goods-details/index?id=' + item.id" v-if="!searchHidden" class="goods-box" v-for="(item, index) in searchs" :key="index">
                <view class="img-box">
                    <image :src="imagebaseurl+item.pic" class="image" style="height: 220px;" :lazy-load="true" />
                    <view class="goods-characteristic">
                        <text>{{ item.tags }}</text>
                    </view>
                </view>

                <view class="goods-title">
					<text>{{ item.name }} </text>
					<text class="goods-price best-item-tag" :class="item.sex == 1 ? 'man':'woman'">
						<image v-if="item.sex == 2" mode="aspectFill" class="sex" src="/static/images/nav/woman.png"></image>
						<image v-if="item.sex == 1" mode="aspectFill" class="sex" src="/static/images/nav/man.png"></image>
						<text style="margin-left: 10rpx">{{item.age}}</text>
					</text>
				</view>

            </navigator>
            <view v-if="searchs.length == 0" class="goods-none">
                <image src="/static/images/search_empty.png" />
                <text>没有找到符合条件的陪玩</text>
            </view>
        </view>
        <view class="top-line"></view>
        <view class="bottom-lin"></view>
    </view>
</template>

<script>
import navigation from '@/components/navigation/navigation';
// pages/search/search.js
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const TOOLS = require('../../utils/tools');
export default {
    components: {
        navigation
    },
    data() {
        return {
			page: 1,
			pageSize: 10,
			totalPages: 0,
            search: true,
            noneHidden: true,
            searchHidden: true,
            recentSearch: [],
            searchValue: '',
            searchs: [],
            searchInput: false,
            iponesc: '',
			tags:[],
			loadingMoreHidden: true,
			imagebaseurl: getApp().globalData.fileDomain,
        };
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {},
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.getRecentSearch();
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
		if (this.curPage == this.totalPages) {
			return;
		}
    	this.setData({
    	    page: this.page + 1
    	});
    	this.searchFun();
    },
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {},
    methods: {
        getRecentSearch: function () {
            let recentSearch = uni.getStorageSync('recentSearch');
            this.setData({
                recentSearch
            });
			WXAPI.getData('Search_Keywords').then((res) => {
				if(res.code==200){
					this.tags = res.data;
				}
			});
        },

        clearHistory: function () {
            uni.clearStorageSync('recentSearch');
            this.setData({
                recentSearch: []
            });
        },

        goSearch: function (e) {
			this.searchs = [];
			this.page = 1;
			this.searchValue = e.currentTarget.dataset.text;
            this.searchFun();
			
        },

        searchFun: function () {
            let that = this;
            let keywords = this.searchValue;
            // if (e != null && e.detail.value) {
            //     keywords = e.detail.value;
            // } else {
            //     keywords = e.currentTarget.dataset.text;
            // }
            // that.searchValue = keywords;
            if (that.searchValue) {
                // 记录最近搜索
                let recentSearch = uni.getStorageSync('recentSearch') || [];
                if (!TOOLS.isStrInArray(keywords, recentSearch)) {
                    recentSearch.unshift(that.searchValue);
                    uni.setStorageSync('recentSearch', recentSearch);
                    that.setData({
                        recentSearch: recentSearch
                    });
                }
            }
			uni.showLoading({
			    title: '加载中'
			});
            WXAPI.goods({
				page: this.page,
				pageSize : this.pageSize,
                keyword: keywords,
				city:uni.getStorageSync('cityindex')?uni.getStorageSync('cityindex'):'武汉'
            }).then((res) => {
                if (res.code == 200) {
					var newArray = res.data.content;
					this.searchs = [...this.searchs,...newArray]
					this.totalPages = res.data.totalPages;
					this.searchHidden = false;
                    if (newArray.length == 0) {
						this.noneHidden = false;
					}
                } else {
                    that.setData({
						page:1,
						searchs:[],
                        searchHidden: true,
                        noneHidden: false
                    });
                }
				uni.hideLoading();
            });
        },

        searchFocus: function () {
            this.setData({
                search: false,
				searchs:[],
				page:1,
                searchInput: true
            });
        },

        searchClose: function () {
            // this.getRecentSearch()
            this.setData({
                search: true,
				searchs:[],
				page:1,
                searchInput: false,
                searchHidden: true
            });
        }
    }
};
</script>
<style>
@import './index.css';
</style>
