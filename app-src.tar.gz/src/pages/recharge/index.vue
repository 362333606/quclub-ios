<template>
    <view class="recharge-container">
		<view class="recharge-head">
			<text>充值</text>
			<text class="balance-info">余额：<text>{{balance}}</text></text>
		</view>
		<view class="recharge-list">
			<view class="recharge-item" 
			v-for="(item,index) in rechargeList" 
			@tap="balanceId = item.id"
			:class="balanceId === item.id ? 'active' : 'default'">
				<view class="recharge-give-price">赠<text style="font-size: 36rpx;">{{item.give_price}}</text>元</view>
				<view class="recharge-price">充值{{item.price}}</view>
			</view>
		</view>
		<view class="recharge-btn" @tap="pay">确认支付</view>
		<view class="recharge-desc">
			<checkbox value="bb" checked="" style="transform: scale(0.7)" />
			同意<text style="color: black" @click="tapNav">《充值服务协议》</text>,充值使用遇到问题？<text style="color: #b2e2f5;" @click="openKefu">在线客服</text>
		</view>
		
		<view class="show-popup" v-if="isPay">
			<view class="popup-mask" @click="closePay"></view>
			<view class="popup-contents">
				<payment @toCancel="closePay" @okPay="okPay" :payTypeId="0" :payOrderId="payOrderId" :payAmount="payAmount"></payment>
			</view>
		</view>
    </view>
</template>

<script>
//index.js
//获取应用实例
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
const tools = require('../../utils/tools.js');
import payment from '@/components/payment';
export default {
	components: {
		payment
	},
    data() {
        return {
            wxlogin: false,
            favList: '',
            loadingMoreHidden: false,
			rechargeList:[],
			balance: 0,
			balanceId: '',
			isPay:false,
			payOrderId:0,
			payAmount:0
        };
    },
    onShow: function () {
        this.getList();
		this.initBalance();
    },
    methods: {
		tapNav() {
		    uni.navigateTo({
		        url: '/pages/news/index?id=14'
		    });
		},
		openKefu() {
		    // #ifdef H5
		    window.location.href = 'https://work.weixin.qq.com/kfid/kfcb1cc156237257592';
		    // #endif
		    // #ifdef APP-PLUS
		    plus.runtime.openURL('https://work.weixin.qq.com/kfid/kfcb1cc156237257592');
		    // #endif
		},
		closePay: function() {
			this.isPay = false;
		},
		okPay: function() {
			this.isPay = false;
			this.initBalance();
		},
		async initBalance() {
			const res = await WXAPI.balance();
			if (res.code == 200) {
			    this.balance = res.data.toFixed(2);
			} 
		},
        afterAuth(e) {
            this.setData({
                wxlogin: true
            });
            this.getList();
        },

        closeAuth() {
            uni.navigateBack();
        },
		pay() {
			if (this.balanceId == '') {
				uni.showToast({icon: 'none',title: '请选择充值套餐'}); 
			    return false;
			}
			let param = {};
			param.pid = this.balanceId;
			param.amount = this.rechargeList[this.balanceId-1].price;
			WXAPI.balanceDeposit(param).then((res) => {
				if (res.code == 200) {
					this.payOrderId = res.data.id;
					this.payAmount = res.data.balance;
					this.isPay = true;
					// uni.showToast({
					//     title: '充值成功'
					// });
				} else {
					uni.showToast({
					    title: res.msg,
					    icon: 'none'
					});
				}
			});
			
			// uni.showToast({icon: 'none',title: this.rechargeList[this.balanceId].price}); 
		},
        getList() {
			var _that = this;
			uni.showLoading({
			    title: '加载中'
			});
			WXAPI.rechargePackage().then((res) => {
			    if (res.code == 200) {
					var packageArray = []
					var array = res.data;
					for(var key in array){
						packageArray.push({
							"id": key,
							"price": array[key].split("_")[0],
							"give_price": array[key].split("_")[1]
						})
					}
					_that.rechargeList = packageArray;
			    }
				uni.hideLoading();
			});
        }
    }
};
</script>
<style>
@import './index.css';
</style>
