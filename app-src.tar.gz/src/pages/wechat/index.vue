<template>
    <view style="height: 100%">
        <web-view src="https://mp.weixin.qq.com/s/6g5ZBkFhIvZKGjRxgPtYGg"></web-view>
    </view>
</template>

<script>
// pages/freshman/freshman.js
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
const TOOLS = require('../../utils/tools.js');
export default {data() {
            return {
              wxlogin: true,
              bgPic: null,
              bgColor: null,
              wxlogin: true,
              activityDetail: ""
            };
        },/**
 * 生命周期函数--监听页面加载
*/
onLoad: function (options) {
  this.onShowClone3389({});

  /*
  if(app.globalData.iphone){
  this.setData({
  iphone: 'iphone'
  })
  } */

  //获取指定活动
  WXAPI.activityDetail(options.id).then(res => {
    if (res.code == 0) {
      this.setData({
        activityDetail: res.data
      });
      const that = this;
      console.log(res.data);
      // WxParse.wxParse('activity', 'html', res.data.title, this, 5);
      //WxParse.wxParse('activity', 'html', res.data.info, this, 5)
      this.article_activity = this.escape2Html(res.data.info);;
    }
  });
},
/**
 * 生命周期函数--监听页面初次渲染完成
 */
onReady: function () {},
onShow() {
  this.onShowClone3389();
},
/**
 * 生命周期函数--监听页面隐藏
 */
onHide: function () {},
/**
 * 生命周期函数--监听页面卸载
 */
onUnload: function () {},
/**
 * 页面相关事件处理函数--监听用户下拉动作
 */
onPullDownRefresh: function () {},
/**
 * 页面上拉触底事件的处理函数
 */
onReachBottom: function () {},
/**
 * 用户点击右上角分享
 */
onShareAppMessage: function () {},
methods: {
    onShowClone3389() {
      AUTH.checkHasLogined().then(isLogined => {
        if (isLogined)
          {} else {
          this.setData({
            wxlogin: isLogined
          });
        }
      });
    },

    afterAuth() {
      this.setData({
        wxlogin: true
      });
    },

    cancelLogin() {
      this.setData({
        wxlogin: true
      });
    },

    processLogin(e) {
      if (!e.detail.userInfo) {
        uni.showToast({
          title: '已取消',
          icon: 'none'
        });
        return;
      }
      AUTH.register(this);
    }
}};
</script>
<style>
@import './index.css';
</style>
