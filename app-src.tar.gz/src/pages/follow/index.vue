<template>
    <view class="goods-container">
        <navigator class="goods-new-item" :url="'/pages_details/goods-details/index?id=' + item.bestId" v-for="(item, index) in favList" :key="index">
             <view class="goods-content">
				 <view class="img-box">
				     <image :src="imagebaseurl+item.best.pic" class="image" mode="aspectFill" :lazy-load="true" />
				 </view>
				 <view class="goods-title" style="width: 58%;">
					<view>
						{{ item.best.name }}
						<view class="best-item-tag" :class="item.best.sex == 1 ? 'man':'woman'">
							<image v-if="item.best.sex == 2" mode="aspectFill" class="sex" src="/static/images/nav/woman.png"></image>
							<image v-if="item.best.sex == 1" mode="aspectFill" class="sex" src="/static/images/nav/man.png"></image>
							<text style="margin-left: 10rpx">{{item.best.age}}</text>
						</view>
						<view class="best-item-tag" :class="item.best.sex == 1 ? 'man':'woman'" v-if="item.best.auths.includes('颜值认证')">
							<image mode="aspectFill" class="sex" src="/static/images/nav/yz_auth.png"></image>
							<text style="margin-left: 6rpx;">颜值认证</text>
						</view>
					</view>
					<view class="goods-tags">
						<text v-for="(tag,index) in (item.best.tags || '').split(',')">{{tag}}</text>
					</view>
				</view>
				 <view class="title-opacity" style="width: 20%;">查看详细</view>
             </view>
			 <view class="goods-imgs">
				 <view class="goods-img" v-for="(img,index) in (item.imgs)">
					 <image :src="imagebaseurl + img" class="slide-image" mode="widthfix" :lazy-load="true" />
				 </view>
			 </view>
        </navigator>
        <view v-if="favList.length == 0" class="no-more-goods">
            <image src="/static/images/empty_collection.png" class="no-order-img"></image>
            <view class="text">还没有任何收藏呢</view>
        </view>

    </view>
</template>

<script>
//index.js
//获取应用实例
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
export default {
    data() {
        return {
			imagebaseurl: getApp().globalData.fileDomain,
            wxlogin: true,
            favList: '',
			curPage: 1,
			pageSize: 5,
			totalPages:0,
            loadingMoreHidden: false
        };
    },
    onShow: function () {
        AUTH.checkHasLogined().then((isLogined) => {
            if (isLogined) {
				this.curPage = 1;
				this.favList = [];
                this.getList();
            }
        });
    },
	onReachBottom: function () {
	    // 滚动刷新
		if (this.curPage == this.totalPages) {
			return;
		}
	    this.setData({
	        curPage: this.curPage + 1
	    });
	    this.getList();
	},
    methods: {
        afterAuth(e) {
            this.setData({
                wxlogin: true
            });
			
            this.getList();
        },

        closeAuth() {
            uni.navigateBack();
        },

        async getList() {
			uni.showLoading({
			    title: '加载中'
			});
            WXAPI.followList({
				pageSize: this.pageSize,
				page: this.curPage
			}).then((res) => {
                if (res.code == 200) {
					var newArray = res.data.content;
					this.favList = [...this.favList,...newArray]
					this.totalPages = res.data.totalPages;
                    this.setData({
                        loadingMoreHidden: true
                    });
                } else{
                   this.setData({
                       favList: null,
                       loadingMoreHidden: false
                   }); 
                }
				uni.hideLoading();
            });
        }
    }
};
</script>
<style>
@import './index.css';
</style>
