<template>
    <view style="height: 100%">
        <view class="container">
            <form @submit="bindSave" :report-submit="true">
                <view class="form-box">
                    <view class="row-wrap">
                        <view class="label">押金金额</view>
                        <view class="label-right">
                            <input name="amount" class="input" type="digit" :value="amount" placeholder="请输入押金金额" />
                        </view>
                    </view>
                </view>
                <button type="warn" class="save-btn" formType="submit">立即支付</button>
            </form>
        </view>
        <float-menu />
    </view>
</template>

<script>
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const app = getApp();
const AUTH = require('../../utils/auth');
export default {
    data() {
        return {
            wxlogin: true,
            amount: ''
        };
    }
    /**
     * 生命周期函数--监听页面加载
     */,
    onLoad: function (options) {},
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        AUTH.checkHasLogined((isLogined) => {
            this.setData({
                wxlogin: isLogined
            });
        });
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {},
    methods: {
        afterAuth() {
            this.setData({
                wxlogin: true
            });
        },

        bindSave: function (e) {
            const that = this;
            const amount = e.detail.value.amount;
            if (amount == '' || amount * 1 < 0) {
                uni.showModal({
                    title: '错误',
                    content: '请填写正确的押金金额',
                    showCancel: false
                });
                return;
            }
            WXAPI.payDeposit(
                {
                    token: uni.getStorageSync('bestpw-Token'),
                    amount: amount
                },
                'post'
            ).then((res) => {
                if (res.code == 40000) {
                    uni.showModal({
                        title: '请先充值',
                        content: res.msg,
                        showCancel: false,
                        success(res) {
                            uni.navigateTo({
                                url: '/pages/recharge/index'
                            });
                        }
                    });
                    return;
                }
                if (res.code != 0) {
                    uni.showModal({
                        title: '错误',
                        content: res.msg,
                        showCancel: false
                    });
                    return;
                }
                uni.showModal({
                    title: '成功',
                    content: '押金支付成功',
                    showCancel: false,
                    success(res) {
                        uni.navigateTo({
                            url: '/pages/asset/index'
                        });
                    }
                });
            });
        }
    }
};
</script>
<style>
@import './pay.css';
</style>
