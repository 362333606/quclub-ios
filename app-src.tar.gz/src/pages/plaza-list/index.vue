<template>
    <view class="goods-container">
		<view class="custom-nav-head" :style="{ 'padding-top' : statusBarHeight == 0 ? 30 : statusBarHeight +'px',  }">
			<view class="custom-nav-left">
				<text :class="tabIndex == 0 ? 'plaza-all action' : 'plaza-all'" @click="search(0)">此时</text>
				<text :class="tabIndex == 1 ? 'plaza-all-city action' : 'plaza-all-city'" @click="search(1)">此地</text>
			</view>
			<view class="custom-nav-right">
				<view @tap="choosePost" class="post-btn">
					<image src="/static/images/nav/post_icon.png" class="post-icon"></image>
					<text>发布</text>
				</view>
			</view>
		</view>
		
		<view class="yui" :style="{ 'padding-top' : statusBarHeight == 0 ? 40 : statusBarHeight +'px',  }">
			<view class="swiper-container" v-if="banners.length > 0">
			    <swiper :class="'screen-swiper ' + (dotStyle ? 'square-dot' : 'round-dot')" :circular="true" :autoplay="true" :indicator-dots="true" interval="5000" duration="500">
			        <swiper-item @tap="tapNav" :data-url="item.link" v-for="(item, index) in banners" :key="index">
			            <image :src="imagebaseurl + item.img" :lazy-load="true"></image>
			        </swiper-item>
			    </swiper>
			</view>
		</view>
		
		
        <view class="goods-new-item" v-for="(item, index) in plazaList" :key="index">
             <view class="gc-content-item">
				 <view class="gc-item-head">
					<view class="best-item-head">
						<navigator class="content" :url="'/pages_details/goods-details/index?id='+item.best.id" hover-class="none" v-if="item.best">
							 <image class="img" mode="aspectFill" :src="imagebaseurl+item.best.pic" v-if="item.best" :lazy-load="true"></image>
						</navigator>
						<image class="img" mode="aspectFill" :src="imagebaseurl + item.userPic" :lazy-load="true" v-else></image>
					</view>
					 <view class="best-item-content">
						 <view class="best-item-content-head">
							<text class="best-item-name" v-if="item.best">{{item.best.name}}</text>
							<text class="best-item-name" v-else>{{item.userName}}</text>
							<text class="best-item-tag" v-if="item.best" :class="item.best.sex == 1 ? 'man':'woman'">
								<image v-if="item.best.sex == 2" mode="aspectFill" class="sex" src="/static/images/nav/woman.png"></image>
								<image v-if="item.best.sex == 1" mode="aspectFill" class="sex" src="/static/images/nav/man.png"></image>
								<text style="margin-left: 10rpx">{{item.best.age}}</text>
							</text>
							<text class="best-item-tag" v-if="item.best && item.best.auths.includes('颜值认证')" :class="item.best.sex == 1 ? 'man':'woman'">
								<image mode="aspectFill" class="sex" src="/static/images/nav/yz_auth.png"></image>
								<text style="margin-left: 10rpx;">颜值认证</text>
							</text>
							
						</view>
						<view class="best-item-content-info">
							<text>{{item.createTime}}</text>
							<text class="status-point"></text>
							<text>{{item.city}}</text>
						</view>
					 </view>
					 <view class="my-remove" @click="removePlaza(item.id)" v-if="item.isRemove == 1">
					 	<image class="remove-icon" src="/static/images/nav/remove.png"></image>
					 </view>
				 </view>
				 <view class="gc-item-text">{{item.content}}</view>
				 <view class="gc-item-imgs" v-if="item.imgs != ''">
					 <view class="gc-item" v-for="(img,indexx) in (item.imgs || '').split(',')" :key="indexx" @click="preview(item.imgs,indexx)">
						 <video :id="'myVideo'+indexx" :src="imagebaseurl + img" class="myVideo slide-image" mode="aspectFill"
						 :lazy-load="true" v-if="img.includes('video')" :enable-progress-gesture="false"
						 :controls="false" @play="pay(indexx,img)" :poster="imagebaseurl + img + '?x-oss-process=video/snapshot,t_0,f_jpg'" />
						 <image class="img" mode="aspectFill" :src="imagebaseurl + img" :lazy-load="true" v-else></image>
					 </view>
				 </view>
				 <view class="gc-project" v-if="item.prices">
					 <view class="project-img">
						 <image :src="imagebaseurl + item.prices.logo" :lazy-load="true"></image>
					 </view>
					 <view class="project-content">
						 <view class="project-name">{{item.prices.title}}</view>
						 <view class="project-time" v-if="item.date && item.date">
							<text>{{item.date}}</text>
							<text>{{item.time}}</text>
						</view>
						  <view class="project-tags" v-if="item.tags">
							<text v-for="tag in (item.tags || '').split(',')">#{{tag}}</text>
						</view>
					 </view>
					 <view class="project-option" @click="ywChange(item.bestId, item.id)">
					 	<view class="option-btn" v-if="item.bestId > 0">邀约</view>	
						<view class="option-btn" v-if="item.bestId == 0">报名</view>	
					 </view>
				 </view>
			 </view>
        </view>
        <view v-if="plazaList.length == 0" class="no-more-goods">
            <image src="/static/images/empty_record.png" class="no-order-img"></image>
            <view class="text">还没有任何动态呢</view>
        </view>
		
		<q-previewImage :urls="previewImgs" ref="previewImage"></q-previewImage>
		
		<view class="show-popup yw-show-popup" v-if="showYw">
			<view class="popup-mask" @click="closeYw"></view>
			<view class="popup-contents yw-popup-contents">
				<view class="yw-content">
					 <image src="/static/images/nav/yuewan.png"></image>
					 <view class="yw-text">报名成功～</view>
					 <view class="yw-ok" @click="closeYw">确定</view>
				</view>
			</view>
		</view>
		
		<view class="show-popup" v-if="chooseUpload">
			<view class="popup-mask" @click="closeUpload"></view>
			<view class="popup-contents choose-upload-content">
				<!-- <view class="choose-upload-item">选择发布类型</view> -->
				<view class="choose-upload-item" @click="toPost(0)">发布文字或图片</view>
				<view class="choose-upload-item" @click="toPost(1)">发布视频</view>
				<view class="choose-upload-cancel" @click="closeUpload">取消</view>
			</view>
		</view>
    </view>
</template>

<script>
//index.js
//获取应用实例
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
const tools = require('../../utils/tools.js');
export default {
    data() {
        return {
			curPage: 1,
			pageSize: 5,
			totalPages: 0,
			imagebaseurl: getApp().globalData.fileDomain,
            wxlogin: false,
            plazaList: '',
            loadingMoreHidden: false,
			statusBarHeight: getApp().globalData.statusBarHeight,
			banners: [],
			dotStyle: 'square-dot',
			previewImgs:[],
			showYw: false,
			city:'',
			tabIndex:0,
			chooseUpload:false
        };
    }, 
	onLoad: function (options) {
	},
    onShow: function () {
		if (getApp().globalData.id) {
			this.tabIndex = getApp().globalData.id;
		}
       this.afterAuth();
    },
	onPullDownRefresh: function() {
	
	  this.getList();
	  wx.stopPullDownRefresh();
	},
	onReachBottom: function () {
		// 滚动刷新
		if (this.curPage == this.totalPages) {
			return;
		}
	    this.setData({
	        curPage: this.curPage + 1
	    });
	    this.getList();
	},
    methods: {
		pay(index,img) {
			console.info(0);
			const videoContext = uni.createVideoContext('myVideo'+index, this);
			videoContext.pause();
			this.previewImgs = [];
			this.previewImgs.push(img)
			this.$refs.previewImage.open(this.previewImgs[0]);
		},
		ywChange(pid, id) {
			let _that = this;
			if (pid > 0) {
				uni.navigateTo({
				    url: '/pages_details/goods-details/index?id=' + pid
				});
			} else {
				AUTH.checkHasLogined().then((isLogined) => {
					if(isLogined) {
						uni.showLoading();
						WXAPI.plazaSign({plazaId: id}).then(function (res) {
							uni.hideLoading();
						    if (res.code == 200) {
								_that.showYw = true;
								// uni.showToast({title: '报名成功'});
								setTimeout(() => {
								   // _this.afterAuth();
								}, 1500);
						    } else {
								uni.showToast({
									 icon: 'none',
									 title: res.msg
								}); 
							}
						});
					} else {
						uni.showToast({
						    title: '请登录后再操作',
						    icon: 'none'
						});
					}
				})
			}
		},
		closeYw() {
			this.showYw = false;
		},
		closeUpload() {
			this.chooseUpload = false;
		},
		search(type) {
			this.tabIndex = type;
			if (type == 0) {
				this.city = '';
			} else {
				this.city = uni.getStorageSync('cityindex');
			}
			this.curPage = 1;
			this.plazaList = [];
			this.getList();
		},
		tapNav(e) {
		    const url = e.currentTarget.dataset.url;
			if (url.includes("http")) {
				// #ifdef H5
				window.location.href = url;
				// #endif
				// #ifdef APP-PLUS
				plus.runtime.openURL(url);
				// #endif
			} else {
				uni.navigateTo({
				    url: url
				});
			}
		},
        async afterAuth(e) {
            this.setData({
                wxlogin: true
            });
			this.curPage = 1;
			this.plazaList = [];
            this.getList();
			//获取轮播
			const bannerRes = await WXAPI.menuList({type: 10});
			if (bannerRes.code == 200) {
			     this.banners = bannerRes.data;
			}
        },
		preview(imgs,index) {
			this.previewImgs = imgs.split(",");
			this.$refs.previewImage.open(this.previewImgs[index]);
		},
		choosePost() {
			AUTH.checkHasLogined().then((isLogined) => {
				if(isLogined) {
					this.chooseUpload = true;
				} else {
					uni.showToast({
					    title: '请登录后再操作',
					    icon: 'none'
					});
				}
			})
		},
		toPost(type) {
			this.chooseUpload = false;
			uni.navigateTo({
				url: '/pages/plaza-post/index?type='+type
			});
		},
        closeAuth() {
            uni.navigateBack();
        },
		removePlaza(pid) {
			let _this = this;
			uni.showModal({
			    title: '确定要删除该动态吗？',
			    content: '',
			    success: function (res) {
			        if (res.confirm) {
						uni.showLoading();
			            WXAPI.plazaRemove({plazaId: pid}).then(function (res) {
							uni.hideLoading();
			                if (res.code == 200) {
								uni.showToast({title: '删除成功'});
								setTimeout(() => {
								   _this.afterAuth();
								}, 1500);
			                } else {
								uni.showToast({
									 icon: 'none',
									 title: res.msg
								}); 
							}
			            });
			        }
			    }
			});
		},
        getList() {
			uni.showLoading({
			    title: '加载中'
			});
            WXAPI.plazaList({
				pageSize: this.pageSize,
				page: this.curPage,
				city: this.city
			}).then((res) => {
                if (res.code == 200) {
					res.data.content.map(item=>{
						item.createTime = tools.timeago(item.createDate);
					});
					let newArray = res.data.content;
					this.plazaList = [...this.plazaList,...newArray]
                    this.setData({
						totalPages: res.data.totalPages,
                        loadingMoreHidden: true
                    });
                } else {
                    this.setData({
                        plazaList: [],
                        loadingMoreHidden: false
                    });
                }
				uni.hideLoading();
            });
        }
    }
};
</script>
<style>
@import './index.css';
</style>
