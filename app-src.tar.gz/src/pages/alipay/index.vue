<template>
    <view>
		
    </view>
</template>

<script>
//index.js
//获取应用实例
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
export default {
    data() {
        return {
            wxlogin: false,
            html:''
        };
    },
    onShow: function () {
		
    },
	mounted(){
		// this.alipay()
	},
    methods: {
		
		// #ifdef H5
		async alipay(){
			//这里是获取支付宝返回的表单用的接口，那两个地址我在api里面写了默认值，所以这个地方就不传了，接口详细内容就和普通调接口一样，该传传，该接接
			const res = await WXAPI.alipayOrder(this.orderNum,this.price,this.couponId)
			//将表单渲染进页面
			document.querySelector('body').innerHTML = res;
			//在渲染完立即提交表单，就会进入支付宝支付的界面
			this.$nextTick(()=>{
				utils.setStorage("weixinCallback", 3);
				window.document.forms[0].submit()
			})
		},
		// #endif
       
		onMessage(type) {
			uni.navigateTo({
			    url: '/pages/message/list?platform=' + type
			});
		},
        getCount() {
			WXAPI.messageUnReadCount({
				type : 0
			}).then((res) => {
				if (res.code == 200) {
					this.unReadCount = res.data;
				}
			});
			WXAPI.messageUnReadCount({
				type : 1
			}).then((res) => {
				if (res.code == 200) {
					this.unReadCount1 = res.data;
				}
			});
		},
    }
};
</script>