<template>
	
	<view class="contain" >
		<view class="info-tip">
			<view class="info-tip-img">
				 <image src="/static/images/icon/zhaoxiangji.png" class="no-order-img"></image>
			</view>
			<view class="info-tip-msg">
				提示：照片用于展示用户，请上传个人照片4张以上进行报名审核，可关注公众号:武汉陪玩(接收订单通知)申请后添加官微:Quclub-7(查看审核情况)
			</view>
		</view>
		<view class="info-title">
			<view class="info-title-m">基础资料</view>
			<view class="info-title-b">(请真实填写生日、身高、体重数据)</view>
		</view>
		<view class="info-input">
			<view class="title">昵称</view>
			<view class="input"><input type="text" class="apply_input" v-model="postForm.name" value=""  placeholder="请输入昵称"/></view>
		</view>
	
		
		<view class="info-input">
			<view class="title">年龄</view>
			<view class="input"><input type="text" class="apply_input" v-model="postForm.age" value=""  placeholder="请输入年龄"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">身高</view>
			<view class="input"><input type="text" class="apply_input" v-model="postForm.height" value=""  placeholder="请输入身高 单位cm"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">体重</view>
			<view class="input"><input type="text" class="apply_input" v-model="postForm.weight" value=""  placeholder="请输入体重 单位kg"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">微信号</view>
			<view class="input"><input type="text" class="apply_input" v-model="postForm.wechat" value=""  placeholder="请输入微信号"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">电话</view>
			<view class="input"><input type="text" class="apply_input" v-model="postForm.phone" value=""  placeholder="请输入电话"/></view>
		</view>
		
		<view class="info-input">
			<view class="title">城市</view>
			<view class="input">
				<uni-data-select
				      v-model="postForm.city"
				      :localdata="cityData"
					  placeholder="请选择城市"
					  :clear="false"
				    ></uni-data-select>
				<!-- <input type="text" class="apply_input" v-model="postForm.city" value=""  placeholder="请输入城市"/> -->
				
				</view>
		</view>
		
		<view class="info-input">
			<view class="title">星座</view>
			<view class="input"><input type="text" class="apply_input" v-model="postForm.constellation" value=""  placeholder="请输入星座"/></view>
		</view>
		
		<view class="info-title">
			<view class="info-title-m">接单类型</view>
		</view>
		
		<view class="project-list">
			<view class="project-item"
			v-for="(item,indexx) in projectList" 
			:class="postForm.serveType.includes(item.title) ? 'active' : 'default'"
			@click="chooseProject(item.title)">
				<view class="my-icon-menu-img">
					 <image :src="imagebaseurl + item.logo"></image>
				</view>
				<text>{{item.title}}</text>
			</view>
		</view>
		
		<view class="info-title">
			<view class="info-title-m">个人标签</view>
		</view>
		<view class="select-tags">
			<text class="tag-item" 
			v-for="tag in tagLists"
			:class="postForm.tags.includes(tag) ? 'select-tag' : 'default-tag'" 
			@click="chooseTags(tag)">{{tag}}</text>
		</view>
		
		<view class="info-title">
			<view class="info-title-m">个人签名</view>
		</view>
		<view class="info-content">
			<textarea v-model="postForm.remark" placeholder="说点什么,让大家看到不一样的..." />
		</view>
		
		<view class="info-title">
			<view class="info-title-m">个人照片</view>
			<view class="info-title-b">(照片必须上传4张起，否则将无法通过审核)</view>
		</view>
		
		<upload_img :imgsUrl.sync="postForm.imgs"></upload_img>
		
		
		<!-- <view style="text-align: center;">点击上方 上传照片</view> -->
		
		<view class="info-title">
			<view class="info-title-m">个人视频</view>
			<view class="info-title-b">(建议上传30秒以内的视频)</view>
		</view>
		<view class="upload-content">
			<view class="upload-item" style="position: relative;margin-left: 10px;" v-if="postForm.video" @click="previews(postForm.video)">
				<video id="myVideo"
				:src="imagebaseurl+postForm.video"
				:poster="imagebaseurl + postForm.video + '?x-oss-process=video/snapshot,t_0,f_jpg'"
				:enable-progress-gesture="false" :controls="false" @play="pay"></video>
				<uni-icons type="close" size="40" color="#ccc" class="clearVideoDiv" @click="delVideo"></uni-icons>
			</view>
			<view class="upload-item" style="margin-left: 10px;" @click="upLoadVideo()" v-if="!postForm.video">
				<uni-icons type="camera-filled" size="45" color="#c5d8f3"></uni-icons>
				<view class="upload-text">上传视频</view>
			</view>
		</view>
		
		<view class="form-submit">
		    <button formType="submit" type="primary" class="submit" @tap="submitApply()">提交</button>
		</view>
		
		<view class="recharge-desc" style="margin-top: 20rpx;text-align: center;">
			<checkbox-group @click="changeChecked">
				<label style="color: #9c9d9d;">
					<checkbox value="bb" :checked="checkboxMark" style="transform: scale(0.8)"  />
					已知晓并同意<text style="color: #6ea2ff" @click="tapNav('/pages/news/index?id=18')">《接单协议》</text>
				</label>
			</checkbox-group>
		</view>
		
		
		
		<q-previewImage ref="previewImage" :urls="image_list"></q-previewImage>
		
	</view>
	
</template>

<script>
// pages/search/search.js
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const TOOLS = require('../../utils/tools');
import upload_img from '@/components/upload_img.vue';
export default {
    components: {
		upload_img
    },
    data() {
        return {
			image_list:[],
			imagebaseurl: getApp().globalData.fileDomain,
			postForm: {
				sex:'',
				name:'',
				phone:'',
				height:'',
				weight:'',
				wechat:'',
				city:'',
				serveType:[],
				tags:[],
				remark:'',
				imgs:[],
				age:'',
				constellation:'',
				video:'',
			},
			tagLists:[],
			projectList:[],
			videoContext:'',
			value: '',
			cityData: [],
			checkboxMark: true
        };
    },
	
	
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
		this.getNotice();
		this.getCity();
	},
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
		uni.showLoading({
		    title: '加载中'
		});
		this.getProjects();
		this.getTagList();
		uni.hideLoading();
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {},
	
    methods: {
		changeChecked(){
			this.checkboxMark = !this.checkboxMark;
		},
		tapNav(url) {
		    uni.navigateTo({
		        url: url
		    });
		},
		getNotice() {
			WXAPI.newsNotice(4).then(res => {
			  if (res.code == 200 && res.data.popStatus == 1) {
				uni.showModal({
					title: '官方提醒',
					content: res.data.content,
					showCancel: false,
					confirmText: '我已知晓',
					success: function (res) {
						if (res.confirm) {
							console.log('用户点击确定');
						}
					}
				});
			  }
			});
		},
		getCity() {
			let _this = this;
			WXAPI.citys().then((res) => {
				if(res.code == 200){
					let array = res.data;
					for(var key in array){
						_this.cityData.push({
							"value": array[key].title,
							"text": array[key].title
						})
					}
				}
			});
		},
		changeCity(e) {
			// console.log("e:", e.value);
			this.postForm.city = e;
		  },
		preview(url) {
		    this.$refs.previewImage.open(url); // 传入当前选中的图片地址
		},
		previews(url) {
			this.image_list.push(url);
			this.$refs.previewImage.open(url);
		},
		delVideo(){
			this.postForm.video = '';
		},
		chooseProject: function(projectItem) {
			if (this.postForm.serveType.includes(projectItem)) {
				this.postForm.serveType = this.postForm.serveType.filter(function(item) {
				  return item !== projectItem;
				});
			} else {
				this.postForm.serveType.push(projectItem);
			}
		},
		chooseTags: function(tag) {
			if (this.postForm.tags.includes(tag)) {
				this.postForm.tags = this.postForm.tags.filter(function(item) {
				  return item !== tag;
				});
			} else {
				if (this.postForm.tags.length == 3) {
					uni.showToast({icon: 'none',title: '最多选3个标签哦'}); 
					return;
				}
				this.postForm.tags.push(tag);
			}
		},
		getTagList(){
			WXAPI.getData('BEST_TAGS').then((res) => {
				if(res.code==200){
					this.tagLists = res.data;
				}
			});
		},
		getProjects(){
			WXAPI.serveList().then((res) => {
				if(res.code==200){
					this.projectList = res.data;
				}
			});
		},
		delimg(i){
			this.img.splice(i, 1);
			this.image_list.splice(i, 1);
		},
		upLoadVideo() {
			let _this = this;
			uni.chooseVideo({
				maxDuration: 30,
			    sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
			    sourceType: ['album'], //从相册选择
			    success: function(res) {
					
					let videoFile = res.tempFilePath;
					if (res.size > 50*1024*1024) {
						uni.showToast({
							title:'视频大小不得高于50M',
							icon:"none"
						})
						return;
					}
					uni.showLoading({
						title: "上传中"
					});
					uni.uploadFile({
						url: app.globalData.api_root + '/upload', //接口地址
						filePath: videoFile,
						name: 'file',
						formData:{  //后台所需除图片外的参数可以写在这里面 ，单张多张都可
						    "type": 2, 
						},
						success: (res) => {
							let data = JSON.parse(res.data);
							uni.hideLoading();
							if(data.code == 200){
								_this.postForm.video = data.msg;
							}else {
								uni.showToast({
									 icon: 'none',
									 title: data.msg
								}); 
							}
						}
					});
				}
			})
		},
		submitApply(){
			var loginToken = uni.getStorageSync('bestpw-Token');
			if (!loginToken) {
			    uni.showModal({
			        title: '友情提示',
			        content: '用户未登录，请登录后再操作！',
			        showCancel: false
			    });
			    return;
			}
			let _this = this;
			if (_this.postForm.name =='') {
				uni.showToast({icon: 'none',title: '请填写昵称'}); 
			    return false;
			} 
			// if (_this.postForm.sex =='') {
			// 	uni.showToast({icon: 'none',title: '请选择性别'}); 
			//     return false;
			// } 
			if (_this.postForm.phone =='') {
				uni.showToast({icon: 'none',title: '请填写电话'}); 
			    return false;
			} 
			if (_this.postForm.wechat =='') {
				uni.showToast({icon: 'none',title: '请填写微信号'}); 
			    return false;
			} 
			if (_this.postForm.city =='') {
				uni.showToast({icon: 'none',title: '请填写城市'}); 
			    return false;
			} 
			if (_this.postForm.age == '') {
				uni.showToast({icon: 'none',title: '请填写年龄'}); 
			    return false;
			} 
			if (_this.postForm.constellation == '') {
				uni.showToast({icon: 'none',title: '请填写星座'}); 
			    return false;
			} 
			if (_this.postForm.serveType == '') {
				uni.showToast({icon: 'none',title: '请选择接单类型'}); 
			    return false;
			} 
			if (_this.postForm.tags == '') {
				uni.showToast({icon: 'none',title: '请选择个人标签'}); 
			    return false;
			} 
			if (_this.postForm.imgs == '' || _this.postForm.imgs.length < 4) {
				uni.showToast({icon: 'none',title: '请上传至少4张照片'}); 
			    return false;
			} 
			if (_this.postForm.video == '') {
				uni.showToast({icon: 'none',title: '请上传视频'}); 
			    return false;
			} 
			
			uni.showLoading();
			WXAPI.bestAdd(_this.postForm).then((result) => {
				uni.hideLoading();
				if(result.code == 200){
					uni.showToast({title: '申请成功'});
					setTimeout(() => {
						//关闭提示后跳转
						uni.navigateTo({
							url:'/pages/my/index'
						})
				  }, 1500);
				} else {
					uni.showToast({
						 icon: 'none',
						 title: result.msg
					}); 
				}
			});
		}
    }
};
</script>
<style>
@import './index.css';
</style>
