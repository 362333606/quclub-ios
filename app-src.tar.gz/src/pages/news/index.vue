<template>
    <view style="height: 100%">
        <view class="container">
            <view class="tab-container">
                <view class="tab-item active">
                    <view class="goods-text">
                        <!-- <template is="wxParse" :data="wxParseData:activity.nodes"/> -->
                        <mp-html style="padding: 20rpx;" :content="article_activity"></mp-html>
                    </view>
                </view>
            </view>
        </view>

        <!-- parse <template is="apifmLogin" :data="wxlogin: wxlogin"/> -->
        <template name="apifmLogin" v-if="false">
            <view class="apifmLogin" v-if="!wxlogin">
                <view class="s-b">
                    <view class="s-l-b">
                        <image src="/static/images/nologin.png" />
                        <text>授权登录</text>
                    </view>
                    <view class="s-t-b">
                        <view class="s-t-i">
                            <text>·</text>
                            请授权小程序登录
                        </view>
                        <view class="s-t-i">
                            <text>·</text>
                            我们不会公布您的这些信息
                        </view>
                        <view class="s-t-i">
                            <text>·</text>
                            只是为了给您提供更好的服务
                        </view>
                    </view>
                    <button class="l" open-type="getUserInfo" @getuserinfo="processLogin">允许</button>
                    <button class="c" @tap="cancelLogin" type="default">暂不登录</button>
                </view>
            </view>
        </template>
    </view>
</template>

<script>
// pages/freshman/freshman.js
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
const TOOLS = require('../../utils/tools.js');
export default {data() {
            return {
              wxlogin: true,
              bgPic: null,
              bgColor: null,
              wxlogin: true,
              activityDetail: "",
              article_activity: "",
			  headerTitle:''
            };
        },/**
 * 生命周期函数--监听页面加载
*/
onLoad: function (options) {
  /*
  if(app.globalData.iphone){
  this.setData({
  iphone: 'iphone'
  })
  } */

  //获取指定活动
  WXAPI.newsDetail(options.id).then(res => {
    if (res.code == 200) {
      this.article_activity = this.escape2Html(res.data.content);
	  uni.setNavigationBarTitle({
	  	title: res.data.title
	  });
    }
  });
},
/**
 * 生命周期函数--监听页面初次渲染完成
 */
onReady: function () {},
onShow() {
  this.onShowClone();
},
/**
 * 生命周期函数--监听页面隐藏
 */
onHide: function () {},
/**
 * 生命周期函数--监听页面卸载
 */
onUnload: function () {},
/**
 * 页面相关事件处理函数--监听用户下拉动作
 */
onPullDownRefresh: function () {},
/**
 * 页面上拉触底事件的处理函数
 */
onReachBottom: function () {},
/**
 * 用户点击右上角分享
 */
onShareAppMessage: function () {},
methods: {
    onShowClone() {
      AUTH.checkHasLogined().then(isLogined => {
        if (isLogined)
          {} else {
          this.setData({
            wxlogin: isLogined
          });
        }
      });
    },

    afterAuth() {
      this.setData({
        wxlogin: true
      });
    },

    cancelLogin() {
      this.setData({
        wxlogin: true
      });
    },

    processLogin(e) {
      if (!e.detail.userInfo) {
        uni.showToast({
          title: '已取消',
          icon: 'none'
        });
        return;
      }
      AUTH.register(this);
    }
}};
</script>
<style>
@import './index.css';
@import '@/template/login/index.css';
</style>
