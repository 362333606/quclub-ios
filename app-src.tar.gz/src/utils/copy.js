/**
 * 跨环境通用复制文本工具
 * @param {string|number|object} text - 待复制内容（支持字符串、数字、对象）
 * @param {string} successTip - 复制成功提示（默认：复制成功）
 * @param {string} failTip - 复制失败提示（默认：复制失败）
 * @returns {Promise<boolean>} - 成功返回true，失败返回false
 */
export const copyToClipboard = async (text, successTip = '复制成功', failTip = '复制失败') => {
  // 1. 预处理内容：确保是字符串，移除特殊字符，避免选中失败
  let copyText = '';
  if (typeof text === 'object') {
    // 若为对象/数组，转为格式化JSON（便于阅读）
    copyText = JSON.stringify(text, null, 2);
  } else {
    // 其他类型转为字符串，移除不可见特殊字符
    copyText = String(text).replace(/[\x00-\x1F\x7F]/g, '').trim();
  }

  // 2. 检查内容是否为空
  if (!copyText) {
    uni.showToast({ title: '无可用复制内容', icon: 'none', duration: 1500 });
    return false;
  }

  try {
    // 3. 区分环境处理
    if (uni.canIUse('setClipboardData')) {
      // 小程序/APP 环境：用UniApp内置API（最稳定）
      await new Promise((resolve, reject) => {
        uni.setClipboardData({
          data: copyText,
          success: resolve,
          fail: (err) => reject(err)
        });
      });
    } else if (typeof window !== 'undefined') {
      // H5 环境：优先用现代 Clipboard API，降级用文本框方案
      if (navigator.clipboard) {
        // 现代浏览器：安全上下文（HTTPS/localhost）可用
        await navigator.clipboard.writeText(copyText);
      } else {
        // 旧浏览器/非安全上下文：用文本框模拟复制
        const textarea = document.createElement('textarea');
        textarea.value = copyText;
        // 隐藏文本框，避免影响页面
        textarea.style.position = 'fixed';
        textarea.style.top = '-999px';
        textarea.style.left = '-999px';
        document.body.appendChild(textarea);
        
        // 选中内容（兼容移动设备）
        textarea.select();
        textarea.setSelectionRange(0, copyText.length);
        
        // 执行复制
        const success = document.execCommand('copy');
        if (!success) throw new Error('execCommand复制失败');
        
        // 移除文本框
        document.body.removeChild(textarea);
      }
    } else {
      // 不支持的环境
      throw new Error('当前环境不支持复制');
    }

    // 4. 复制成功提示
    uni.showToast({ title: successTip, icon: 'none', duration: 1500 });
    return true;
  } catch (err) {
    // 5. 复制失败处理（打印错误便于调试）
    console.error('复制失败详情:', err);
    // 特殊场景提示：H5非HTTPS环境
    const errMsg = (err && err.message) || ''; if (errMsg.includes('Clipboard') && typeof window !== 'undefined' && window.location && window.location.protocol === 'http:') {
      uni.showToast({ title: '请在HTTPS环境下使用复制功能', icon: 'none', duration: 2000 });
    } else {
      uni.showToast({ title: failTip, icon: 'none', duration: 1500 });
    }
    return false;
  }
};