<template>
    <view :style="'height:70px;padding-top:' + statusBarHeight + 'px;'">
        <view class="header" :style="'height:70px;padding-top:' + statusBarHeight + 'px;'">
 
			<view class="content" @click="useOutClickSide">
				<!-- <image class="search-box-image" src="/static/images/icon/location.png" style="width: 24px;height: 24px;"></image> -->
				<easy-select ref="easySelect" style="width: 50px;position: relative;float: left" :options="option" :windowHeight="800" :value="selecValue" @selectOne="selectOne"></easy-select>
				<image class="search-box-image" src="/static/images/nav/sanjiao.png" style="width: 8px;height: 8px;"></image>
			</view>
            <view v-if="showTitle" class="header-title">{{ title }}</view>
		
            <view v-if="showSearch" class="search-box" @tap="headerSearch">
                <image class="search-box-image" src="/static/components/navigation/img/search.png"></image>
                <text class="search-box-text">搜索昵称</text>
            </view>
			
			<view class="sex-content">
				
				<view class="sex-item" @click="seachSex(1)" :class="sex == 1?'sex-man':''">
					<image mode="aspectFill" class="sex" src="/static/images/nav/man.png"></image>
				</view>
				<view class="sex-item" @click="seachSex(2)" :class="sex == 2?'sex-woman':''">
					<image mode="aspectFill" class="sex" src="/static/images/nav/woman.png"></image>
				</view>
				
			</view>
		
        </view>
    </view>
</template>

<script>
const app = getApp();
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
export default {
    data() {
        return {
			sex:2,
            statusBarHeight: 0,
            titleBarHeight: 0,
			selecValue: '',
			option:[{
				value: '武汉',
				label: '武汉',
			}],
        };
    },
    props: {
        //小程序页面的表头
        title: {
            type: String,
            default: '元贞体育'
        },
        //是否展示返回和主页按钮
        showIcon: {
            type: Boolean,
            default: false
        },
        //是否显示标题
        showTitle: {
            type: Boolean,
            default: false
        },
        //是否显示搜索框
        showSearch: {
            type: Boolean,
            default: false
        },
        disableSearchJump: {
            type: Boolean,
            default: false
        }
    },
    mounted() {
        // 处理小程序 attached 生命周期
        this.attached();
        // 处理小程序 ready 生命周期
        this.$nextTick(() => this.ready());
		this.getCitys();
		this.getLocation();
		if (uni.getStorageSync('cityindex')) {
			this.selecValue = uni.getStorageSync('cityindex');
		} else {
			this.selecValue = "武汉";
			uni.setStorageSync('cityindex',this.selecValue);
		}
    },
    methods: {
		getLocation(){
			let _this = this;
			uni.getLocation({
				type: 'gcj02',
				geocode: true,
				isHighAccuracy: true,
				success: function(res) {
					console.log(res.latitude+"--"+res.longitude);
					_this.latitude = res.latitude;
					_this.longitude = res.longitude;
					
					uni.request({
						url: "/ws/geocoder/v1/",
						data: {
						 key: "3QHBZ-UQXYJ-OWAFU-DFBJH-X6DS7-PXFU7",
						 location: res.latitude + ',' + res.longitude,
						},
						success: (res) => {
							let result = eval('(' + JSON.stringify(res) + ')');
							let city = result.data.result.address_component.city;
							 console.log(city);
							if (city.indexOf('市') > -1) {
								city = city.substring(0,city.length - 1);
								uni.setStorageSync('cityindex',city);
							}
						},
						fail: (err) => {
						 console.log(err);
						}
					})
				},
				fail: function(res) {
					console.log('获取当前位置的经纬度-失败');
					console.log(res);
					
				}
			});
		},
        ready: function () {},
		selectOne(options) {
		    this.selecValue = options.title;
			uni.setStorageSync('cityindex',options.title);
			this.$emit('selectCity')
			if (this.selecValue == '杭州') {
				window.location.href = "https://hz.bestpw.cn/";
			}
		},
		getCitys(){
			WXAPI.citys().then((res) => {
				if(res.code==200){
					this.option = res.data;
				}
				// uni.setStorageSync('token',res.data[0].base.token);
			});
		},
        attached: function () {
            // 因为很多地方都需要用到，所有保存到全局对象中
            if (app.globalData && app.globalData.statusBarHeight && app.globalData.titleBarHeight) {
                this.setData({
                    statusBarHeight: app.globalData.statusBarHeight,
                    titleBarHeight: app.globalData.titleBarHeight
                });
            } else {
                let that = this;
                uni.getSystemInfo({
                    success: function (res) {
                        if (!app.globalData) {
                            app.globalData = {};
                        }
                        if (res.model.indexOf('iPhone') !== -1) {
                            app.globalData.titleBarHeight = 44 + res.statusBarHeight;
                        } else {
                            app.globalData.titleBarHeight = 48 + res.statusBarHeight;
                        }
                        app.globalData.statusBarHeight = res.statusBarHeight;
                        that.setData({
                            statusBarHeight: app.globalData.statusBarHeight,
                            titleBarHeight: app.globalData.titleBarHeight
                        });
                    },

                    failure() {
                        that.setData({
                            statusBarHeight: 0,
                            titleBarHeight: 0
                        });
                    }
                });
            }
        },

        headerBack() {
            uni.navigateBack({
                delta: 1,
                fail(e) {
                    uni.switchTab({
                        url: '/pages/index/index'
                    });
                }
            });
        },
		useOutClickSide() {
			this.$refs.easySelect.hideOptions && this.$refs.easySelect.hideOptions()
		},

        headerHome() {
            uni.switchTab({
                url: '/pages/index/index'
            });
        },

        headerSearch() {
            // if (this.disableSearchJump) {
            //     return;
            // }
            uni.navigateTo({
                url: '/pages/search/index'
            });
        },
		seachSex(sex) {
			this.sex = sex;
			this.$emit('seachSex',this.sex)
		},
	
    },
    created: function () {}
};
</script>
<style>
@import './navigation.css';
</style>
