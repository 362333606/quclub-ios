<template>
    <view class="flex b tb ac" v-if="calendar">
        <view class="calendar b tb">
            <!-- 头部操作栏 -->
            <view v-if="!calendarConfig.hideHeadOnWeekMode" :class="'handle ' + calendarConfig.theme + '_handle-color fs28 b lr ac pc'">
                <view class="prev fs36" v-if="calendarConfig.showHandlerOnWeekMode || !calendar.weekMode">
                    <text class="prev-handle iconfont icon-doubleleft" @tap="chooseDate" data-type="prev_year"></text>
                    <text class="prev-handle iconfont icon-left" @tap="chooseDate" data-type="prev_month"></text>
                </view>
                <view class="flex date-in-handle b lr cc" @tap="doubleClickToToday">{{ calendar.curYear || '--' }} 年 {{ calendar.curMonth || '--' }} 月</view>
                <view class="next fs36" v-if="calendarConfig.showHandlerOnWeekMode || !calendar.weekMode">
                    <text class="next-handle iconfont icon-right" @tap="chooseDate" data-type="next_month"></text>
                    <text class="next-handle iconfont icon-doubleright" @tap="chooseDate" data-type="next_year"></text>
                </view>
            </view>
            <!-- 星期栏 -->
            <view :class="'weeks b lr ac ' + calendarConfig.theme + '_week-color'">
                <view class="week fs28" :data-idx="index" v-for="(item, index) in calendar.weeksCh" :key="index">{{ item }}</view>
            </view>
            <!-- 日历面板主体 -->
            <view class="b lr wrap" @touchstart="calendarTouchstart" @touchmove="calendarTouchmove" @touchend="calendarTouchend">
                <!-- 上月日期格子 -->
                <view
                    :class="'grid b ac pc ' + calendarConfig.theme + '_prev-month-date'"
                    v-if="calendar.empytGrids"
                    :data-idx="index"
                    v-for="(item, index) in calendar.empytGrids"
                    :key="index"
                >
                    <view class="date">
                        {{ item.day }}
                        <view v-if="calendarConfig.showLunar && item.lunar" class="date-desc date-desc-bottom">
                            {{ item.lunar.Term || item.lunar.IDayCn }}
                        </view>
                    </view>
                </view>
                <!-- 本月日期格子 -->
                <view
                    :class="'grid ' + calendarConfig.theme + '_normal-date b ac pc'"
                    :data-disable="item.disable"
                    :data-idx="index"
                    @tap="tapDayItem"
                    v-for="(item, index) in calendar.days"
                    :key="index"
                >
                    <view class="date-wrap b cc">
                        <view
                            :class="
                                'date b ac pc ' +
                                (item.class ? item.class : '') +
                                ' ' +
                                (calendarConfig.chooseAreaMode ? 'date-area-mode' : '') +
                                ' ' +
                                (item.week === 0 || item.week === 6 ? calendarConfig.theme + '_weekend-color' : '') +
                                ' ' +
                                (calendar.todoLabelCircle && item.showTodoLabel && !item.choosed ? calendarConfig.theme + '_todo-circle todo-circle' : '') +
                                ' ' +
                                (item.isToday ? calendarConfig.theme + '_today' : '') +
                                ' ' +
                                (item.choosed ? calendarConfig.theme + '_choosed' : '') +
                                ' ' +
                                (item.disable ? calendarConfig.theme + '_date-disable' : '')
                            "
                        >
                            {{ calendarConfig.markToday && item.isToday ? calendarConfig.markToday : item.day }}
                            <view
                                v-if="(calendarConfig.showLunar && item.lunar && !item.showTodoLabel) || (item.showTodoLabel && calendar.todoLabelPos !== 'bottom')"
                                :class="
                                    'date-desc ' +
                                    calendarConfig.theme +
                                    '_date-desc date-desc-bottom ' +
                                    (item.choosed || item.isToday ? 'date-desc-bottom-always' : '') +
                                    ' ' +
                                    (item.disable ? calendarConfig.theme + '_date-desc-disable' : '')
                                "
                            >
                                {{ item.lunar.Term || item.lunar.IDayCn }}
                            </view>
                            <view
                                v-if="item.showTodoLabel && !calendar.todoLabelCircle"
                                :class="
                                    (item.todoText ? 'date-desc' : calendarConfig.theme + '_todo-dot todo-dot') +
                                    ' ' +
                                    (calendarConfig.showLunar ? calendarConfig.theme + '_date-desc-lunar' : '') +
                                    ' ' +
                                    (calendar.todoLabelPos === 'bottom' ? 'date-desc-bottom todo-dot-bottom' : 'date-desc-top todo-dot-top') +
                                    ' ' +
                                    (calendar.showLabelAlways && item.choosed && calendar.todoLabelPos === 'bottom' ? 'date-desc-bottom-always todo-dot-bottom-always' : '') +
                                    ' ' +
                                    (calendar.showLabelAlways && item.choosed && calendar.todoLabelPos === 'top' ? 'date-desc-top-always todo-dot-top-always' : '')
                                "
                                :style="'background-color: ' + (item.todoLabelColor || calendar.todoLabelColor) + ';'"
                            >
                                {{ item.todoText }}
                            </view>
                        </view>
                    </view>
                </view>
                <!-- 下月日期格子 -->
                <view :class="'grid b ac pc ' + calendarConfig.theme + '_next-month-date'" :data-idx="index" v-for="(item, index) in calendar.lastEmptyGrids" :key="index">
                    <view class="date">
                        {{ item.day }}
                        <view v-if="calendarConfig.showLunar && item.lunar" class="date-desc date-desc-bottom">
                            {{ item.lunar.Term || item.lunar.IDayCn }}
                        </view>
                    </view>
                </view>
            </view>
        </view>
    </view>
</template>

<script>
	
	export default {
	    data() {
	        return {
	            handleMap: {
	                prev_year: 'chooseYear',
	                prev_month: 'chooseMonth',
	                next_month: 'chooseMonth',
	                next_year: 'chooseYear'
	            },
	
	            calendar: {
	                enableArea: '',
	                days: '',
	                selectedDay: '',
	                enableAreaTimestamp: [],
	                enableDays: '',
	                enableDaysTimestamp: '',
	                disableDays: '',
	                chooseAreaTimestamp: [],
	                specialStyleDates: '',
	                weekMode: false,
	                curYear: '',
	                curMonth: '',
	                empytGrids: [],
	                lastEmptyGrids: [],
	                todoLabels: '',
	                leftSwipe: 0,
	                rightSwipe: 0,
	                lastChoosedDate: '',
	                weeksCh: [],
	                todoLabelCircle: '',
	                todoLabelPos: '',
	                showLabelAlways: '',
	                todoLabelColor: ''
	            },
	
	            gesture: {
	                startX: '',
	                startY: ''
	            },
	
	            t: 0
	        };
	    },
	    options: {
	        styleIsolation: 'apply-shared',
	        multipleSlots: true
	    },
	    props: {
	        calendarConfig: {
	            type: Object,
	            default: () => ({})
	        }
	    },
	    mounted() {
	        // 处理小程序 attached 生命周期
	        this.attached();
	    },
	    methods: {
	        attached: function () {
	            this.initComp();
	        },
	
	        attached: function () {
	            this.initComp();
	        },
	
	        initComp() {
	            const e = this.calendarConfigClone || {};
	            this.setConfig(e);
	            (0, s.default)(this, e);
	        },
	
	        setConfig(e) {
	            if (e.markToday && 'string' == typeof e.markToday) {
	                e.highlightToday = true;
	            }
	            e.theme = e.theme || 'default';
	            this.setData({
	                calendarConfig: e
	            });
	        },
	
	        chooseDate(e) {
	            const { type: t } = e.currentTarget.dataset;
	            if (t) {
	                this[this.handleMap[t]](t);
	            }
	        },
	
	        chooseYear(e) {
	            const { curYear: t, curMonth: a } = this.calendar;
	            if (!t || !a) {
	                return l.warn('异常：未获取到当前年月');
	            }
	            if (this.weekMode) {
	                return console.warn('周视图下不支持点击切换年月');
	            }
	            let n = +t;
	            let o = +a;
	            if ('prev_year' === e) {
	                n -= 1;
	            } else {
	                if ('next_year' === e) {
	                    n += 1;
	                }
	            }
	            this.render(t, a, n, o);
	        },
	
	        chooseMonth(e) {
	            const { curYear: t, curMonth: a } = this.calendar;
	            if (!t || !a) {
	                return l.warn('异常：未获取到当前年月');
	            }
	            if (this.weekMode) {
	                return console.warn('周视图下不支持点击切换年月');
	            }
	            let n = +t;
	            let o = +a;
	            if ('prev_month' === e) {
	                if ((o -= 1) < 1) {
	                    n -= 1;
	                    o = 12;
	                }
	            } else {
	                if ('next_month' === e && (o += 1) > 12) {
	                    n += 1;
	                    o = 1;
	                }
	            }
	            this.render(t, a, n, o);
	        },
	
	        render(e, t, a, n) {
	            s.whenChangeDate.call(this, {
	                curYear: e,
	                curMonth: t,
	                newYear: a,
	                newMonth: n
	            });
	            this.setData({
	                'calendar.curYear': a,
	                'calendar.curMonth': n
	            });
	            s.renderCalendar.call(this, a, n);
	        },
	
	        tapDayItem(e) {
	            const { idx: t, disable: a } = e.currentTarget.dataset;
	            if (a) {
	                return;
	            }
	            const n = this.calendarConfigClone || this.config || {};
	            const { multi: o, chooseAreaMode: r } = n;
	            if (o) {
	                s.whenMulitSelect.call(this, t);
	            } else {
	                if (r) {
	                    s.whenChooseArea.call(this, t);
	                } else {
	                    s.whenSingleSelect.call(this, t);
	                }
	            }
	        },
	
	        doubleClickToToday() {
	            if (!this.config.multi && !this.weekMode) {
	                if (void 0 === this.count) {
	                    this.count = 1;
	                } else {
	                    this.count += 1;
	                }
	                if (this.lastClick) {
	                    if (new Date().getTime() - this.lastClick < 500 && this.count >= 2) {
	                        s.jump.call(this);
	                    }
	                    this.count = void 0;
	                    this.lastClick = void 0;
	                } else {
	                    this.lastClick = new Date().getTime();
	                }
	            }
	        },
	
	        calendarTouchstart(e) {
	            const t = e.touches[0];
	            const a = t.clientX;
	            const n = t.clientY;
	            this.slideLock = true;
	            this.setData({
	                'gesture.startX': a,
	                'gesture.startY': n
	            });
	        },
	
	        handleSwipe(e) {
	            let t = 'calendar.leftSwipe';
	            let a = 'next_month';
	            let n = 'next_week';
	            if ('right' === e) {
	                t = 'calendar.rightSwipe';
	                a = 'prev_month';
	                n = 'prev_week';
	            }
	            this.setData({
	                [t]: 1
	            });
	            this.currentYM = (0, s.getCurrentYM)();
	            if (this.weekMode) {
	                this.slideLock = false;
	                this.currentDates = (0, s.getCalendarDates)();
	                if ('prev_week' === n) {
	                    (0, o.default)(this).calculatePrevWeekDays();
	                } else {
	                    if ('next_week' === n) {
	                        (0, o.default)(this).calculateNextWeekDays();
	                    }
	                }
	                this.onSwipeCalendar(n);
	                return void this.onWeekChange(n);
	            }
	            this.chooseMonth(a);
	            this.onSwipeCalendar(a);
	        },
	
	        calendarTouchmove(e) {
	            const { gesture: t } = this;
	            const { preventSwipe: a } = this.calendarConfigClone;
	            if (this.slideLock && !a) {
	                if (c.isLeft(t, e.touches[0])) {
	                    this.handleSwipe('left');
	                    this.slideLock = false;
	                }
	                if (c.isRight(t, e.touches[0])) {
	                    this.handleSwipe('right');
	                    this.slideLock = false;
	                }
	            }
	        },
	
	        calendarTouchend(e) {
	            this.setData({
	                'calendar.leftSwipe': 0,
	                'calendar.rightSwipe': 0
	            });
	        },
	
	        onSwipeCalendar(e) {
	            this.$emit('onSwipe', {
	                detail: {
	                    directionType: e,
	                    currentYM: this.currentYM
	                }
	            });
	        },
	
	        onWeekChange(e) {
	            this.$emit('whenChangeWeek', {
	                detail: {
	                    current: {
	                        currentYM: this.currentYM,
	                        dates: [...this.currentDates]
	                    },
	                    next: {
	                        currentYM: (0, s.getCurrentYM)(),
	                        dates: (0, s.getCalendarDates)()
	                    },
	                    directionType: e
	                }
	            });
	            this.currentDates = null;
	            this.currentYM = null;
	        }
	    },
	    created: function () {}
	};
!(function (e) {
    var t = {};
    function a(n) {
        if (t[n]) {
            return t[n].exports;
        }
        var o = (t[n] = {
            i: n,
            l: false,
            exports: {}
        });
        e[n].call(o.exports, o, o.exports, a);
        o.l = true;
        return o.exports;
    }
    a.m = e;
    a.c = t;
    a.d = function (e, t, n) {
        a.o(e, t) ||
            Object.defineProperty(e, t, {
                enumerable: true,
                get: n
            });
    };
    a.r = function (e) {
        if ('undefined' != typeof Symbol && Symbol.toStringTag) {
            Object.defineProperty(e, Symbol.toStringTag, {
                value: 'Module'
            });
        }
        Object.defineProperty(e, '__esModule', {
            value: true
        });
    };
    a.t = function (e, t) {
        if (1 & t) {
            e = a(e);
        }
        if (8 & t) {
            return e;
        }
        if (4 & t && 'object' == typeof e && e && e.__esModule) {
            return e;
        }
        var n = Object.create(null);
        a.r(n);
        Object.defineProperty(n, 'default', {
            enumerable: true,
            value: e
        });
        if (2 & t && 'string' != typeof e) {
            for (var o in e) {
                a.d(
                    n,
                    o,
                    function (t) {
                        return e[t];
                    }.bind(null, o)
                );
            }
        }
        return n;
    };
    a.n = function (e) {
        var t =
            e && e.__esModule
                ? function () {
                      return e.default;
                  }
                : function () {
                      return e;
                  };
        a.d(t, 'a', t);
        return t;
    };
    a.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t);
    };
    a.p = '';
    a((a.s = 8));
})([
    function (e, t, a) {
        'use strict';

        Object.defineProperty(t, '__esModule', {
            value: true
        });
        t.default = void 0;
        var n = class {
            constructor(e) {
                this.Component = e;
            }
            getData(e) {
                const t = this.Component.data;
                if (!e) {
                    return t;
                }
                if (e.includes('.')) {
                    return e.split('.').reduce((e, t) => e[t], t);
                }
                return this.Component.data[e];
            }
            setData(e, t = () => {}) {
                if (e && 'object' == typeof e) {
                    this.Component.setData(e, t);
                }
            }
        };
        t.default = n;
    },
    function (e, t, a) {
        'use strict';

        let n;
        function o() {
            return n || (n = uni.getSystemInfoSync());
        }
        Object.defineProperty(t, '__esModule', {
            value: true
        });
        t.getSystemInfo = o;
        t.isComponent = function (e) {
            return e && void 0 !== e.__wxExparserNodeId__ && 'function' == typeof e.setData;
        };
        t.isIos = c;
        t.getCurrentPage = l;
        t.getComponent = function (e) {
            const t = new r();
            let a = l() || {};
            if (a.selectComponent && 'function' == typeof a.selectComponent) {
                if (e) {
                    return a.selectComponent(e);
                }
                t.warn('请传入组件ID');
            } else {
                t.warn('该基础库暂不支持多个小程序日历组件');
            }
        };
        t.uniqueArrayByDate = function (e = []) {
            let t = {};
            let a = [];
            e.forEach((e) => {
                t[`${e.year}-${e.month}-${e.day}`] = e;
            });
            for (let e in t) {
                a.push(t[e]);
            }
            return a;
        };
        t.delRepeatedEnableDay = function (e = [], t = []) {
            let a;
            let n;
            if (2 === t.length) {
                const { startTimestamp: e, endTimestamp: o } = i(t);
                a = e;
                n = o;
            }
            return f(e).filter((e) => e < a || e > n);
        };
        t.convertEnableAreaToTimestamp = i;
        t.getDateTimeStamp = d;
        t.converEnableDaysToTimestamp = f;
        t.initialTasks = t.GetDate = t.Slide = t.Logger = void 0;
        class r {
            info(e) {
                console.log('%cInfo: %c' + e, 'color:#FF0080;font-weight:bold', 'color: #FF509B');
            }
            warn(e) {
                console.log('%cWarn: %c' + e, 'color:#FF6600;font-weight:bold', 'color: #FF9933');
            }
            tips(e) {
                console.log('%cTips: %c' + e, 'color:#00B200;font-weight:bold', 'color: #00CC33');
            }
        }
        t.Logger = r;
        t.Slide = class {
            isUp(e = {}, t = {}) {
                const { startX: a, startY: n } = e;
                const o = t.clientX - a;
                return t.clientY - n < -60 && o < 20 && o > -20 && ((this.slideLock = false), true);
            }
            isDown(e = {}, t = {}) {
                const { startX: a, startY: n } = e;
                const o = t.clientX - a;
                return t.clientY - n > 60 && o < 20 && o > -20;
            }
            isLeft(e = {}, t = {}) {
                const { startX: a, startY: n } = e;
                const o = t.clientX - a;
                const r = t.clientY - n;
                return o < -60 && r < 20 && r > -20;
            }
            isRight(e = {}, t = {}) {
                const { startX: a, startY: n } = e;
                const o = t.clientX - a;
                const r = t.clientY - n;
                return o > 60 && r < 20 && r > -20;
            }
        };
        class s {
            newDate(e, t, a) {
                let n = `${+e}-${+t}-${+a}`;
                if (c()) {
                    n = `${+e}/${+t}/${+a}`;
                }
                return new Date(n);
            }
            thisMonthDays(e, t) {
                return new Date(Date.UTC(e, t, 0)).getUTCDate();
            }
            firstDayOfWeek(e, t) {
                return new Date(Date.UTC(e, t - 1, 1)).getUTCDay();
            }
            dayOfWeek(e, t, a) {
                return new Date(Date.UTC(e, t - 1, a)).getUTCDay();
            }
            todayDate() {
                const e = new Date();
                return {
                    year: e.getFullYear(),
                    month: e.getMonth() + 1,
                    date: e.getDate()
                };
            }
            todayTimestamp() {
                const { year: e, month: t, date: a } = this.todayDate();
                return this.newDate(e, t, a).getTime();
            }
            toTimeStr(e) {
                return `${e.year}-${e.month}-${e.day}`;
            }
            sortDates(e, t) {
                return e.sort(function (e, a) {
                    return d(e) < d(a) && 'desc' !== t ? -1 : 1;
                });
            }
            prevMonth(e) {
                return +e.month > 1
                    ? {
                          year: e.year,
                          month: e.month - 1
                      }
                    : {
                          year: e.year - 1,
                          month: 12
                      };
            }
            nextMonth(e) {
                return +e.month < 12
                    ? {
                          year: e.year,
                          month: e.month + 1
                      }
                    : {
                          year: e.year + 1,
                          month: 1
                      };
            }
        }
        function c() {
            const e = o();
            return /iphone|ios/i.test(e.platform);
        }
        function l() {
            const e = getCurrentPages();
            return e[e.length - 1];
        }
        function i(e = []) {
            const t = new s();
            const a = e[0].split('-');
            const n = e[1].split('-');
            const o = new r();
            return 3 !== a.length || 3 !== n.length
                ? (o.warn('enableArea() 参数格式为: ["2018-2-1", "2018-3-1"]'), {})
                : {
                      start: a,
                      end: n,
                      startTimestamp: t.newDate(a[0], a[1], a[2]).getTime(),
                      endTimestamp: t.newDate(n[0], n[1], n[2]).getTime()
                  };
        }
        function d(e) {
            if ('[object Object]' !== Object.prototype.toString.call(e)) {
                return;
            }
            return new s().newDate(e.year, e.month, e.day).getTime();
        }
        function f(e = []) {
            const t = new r();
            const a = new s();
            const n = [];
            e.forEach((e) => {
                if ('string' != typeof e) {
                    return t.warn('enableDays()入参日期格式错误');
                }
                const o = e.split('-');
                if (3 !== o.length) {
                    return t.warn('enableDays()入参日期格式错误');
                }
                const r = a.newDate(o[0], o[1], o[2]).getTime();
                n.push(r);
            });
            return n;
        }
        t.GetDate = s;
        t.initialTasks = {
            flag: 'finished',
            tasks: []
        };
    },
    function (e, t, a) {
        'use strict';

        Object.defineProperty(t, '__esModule', {
            value: true
        });
        t.default = void 0;
        const n = {
            lunarInfo: [
                19416, 19168, 42352, 21717, 53856, 55632, 91476, 22176, 39632, 21970, 19168, 42422, 42192, 53840, 119381, 46400, 54944, 44450, 38320, 84343, 18800, 42160, 46261,
                27216, 27968, 109396, 11104, 38256, 21234, 18800, 25958, 54432, 59984, 28309, 23248, 11104, 100067, 37600, 116951, 51536, 54432, 120998, 46416, 22176, 107956, 9680,
                37584, 53938, 43344, 46423, 27808, 46416, 86869, 19872, 42416, 83315, 21168, 43432, 59728, 27296, 44710, 43856, 19296, 43748, 42352, 21088, 62051, 55632, 23383,
                22176, 38608, 19925, 19152, 42192, 54484, 53840, 54616, 46400, 46752, 103846, 38320, 18864, 43380, 42160, 45690, 27216, 27968, 44870, 43872, 38256, 19189, 18800,
                25776, 29859, 59984, 27480, 21952, 43872, 38613, 37600, 51552, 55636, 54432, 55888, 30034, 22176, 43959, 9680, 37584, 51893, 43344, 46240, 47780, 44368, 21977,
                19360, 42416, 86390, 21168, 43312, 31060, 27296, 44368, 23378, 19296, 42726, 42208, 53856, 60005, 54576, 23200, 30371, 38608, 19195, 19152, 42192, 118966, 53840,
                54560, 56645, 46496, 22224, 21938, 18864, 42359, 42160, 43600, 111189, 27936, 44448, 84835, 37744, 18936, 18800, 25776, 92326, 59984, 27424, 108228, 43744, 41696,
                53987, 51552, 54615, 54432, 55888, 23893, 22176, 42704, 21972, 21200, 43448, 43344, 46240, 46758, 44368, 21920, 43940, 42416, 21168, 45683, 26928, 29495, 27296,
                44368, 84821, 19296, 42352, 21732, 53600, 59752, 54560, 55968, 92838, 22224, 19168, 43476, 41680, 53584, 62034, 54560
            ],
            solarMonth: [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
            Gan: ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'],
            Zhi: ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'],
            Animals: ['鼠', '牛', '虎', '兔', '龙', '蛇', '马', '羊', '猴', '鸡', '狗', '猪'],
            solarTerm: [
                '小寒',
                '大寒',
                '立春',
                '雨水',
                '惊蛰',
                '春分',
                '清明',
                '谷雨',
                '立夏',
                '小满',
                '芒种',
                '夏至',
                '小暑',
                '大暑',
                '立秋',
                '处暑',
                '白露',
                '秋分',
                '寒露',
                '霜降',
                '立冬',
                '小雪',
                '大雪',
                '冬至'
            ],
            sTermInfo: [
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b97bd19801ec9210c965cc920e',
                '97bcf97c3598082c95f8c965cc920f',
                '97bd0b06bdb0722c965ce1cfcc920f',
                'b027097bd097c36b0b6fc9274c91aa',
                '97b6b97bd19801ec9210c965cc920e',
                '97bcf97c359801ec95f8c965cc920f',
                '97bd0b06bdb0722c965ce1cfcc920f',
                'b027097bd097c36b0b6fc9274c91aa',
                '97b6b97bd19801ec9210c965cc920e',
                '97bcf97c359801ec95f8c965cc920f',
                '97bd0b06bdb0722c965ce1cfcc920f',
                'b027097bd097c36b0b6fc9274c91aa',
                '9778397bd19801ec9210c965cc920e',
                '97b6b97bd19801ec95f8c965cc920f',
                '97bd09801d98082c95f8e1cfcc920f',
                '97bd097bd097c36b0b6fc9210c8dc2',
                '9778397bd197c36c9210c9274c91aa',
                '97b6b97bd19801ec95f8c965cc920e',
                '97bd09801d98082c95f8e1cfcc920f',
                '97bd097bd097c36b0b6fc9210c8dc2',
                '9778397bd097c36c9210c9274c91aa',
                '97b6b97bd19801ec95f8c965cc920e',
                '97bcf97c3598082c95f8e1cfcc920f',
                '97bd097bd097c36b0b6fc9210c8dc2',
                '9778397bd097c36c9210c9274c91aa',
                '97b6b97bd19801ec9210c965cc920e',
                '97bcf97c3598082c95f8c965cc920f',
                '97bd097bd097c35b0b6fc920fb0722',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b97bd19801ec9210c965cc920e',
                '97bcf97c3598082c95f8c965cc920f',
                '97bd097bd097c35b0b6fc920fb0722',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b97bd19801ec9210c965cc920e',
                '97bcf97c359801ec95f8c965cc920f',
                '97bd097bd097c35b0b6fc920fb0722',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b97bd19801ec9210c965cc920e',
                '97bcf97c359801ec95f8c965cc920f',
                '97bd097bd097c35b0b6fc920fb0722',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b97bd19801ec9210c965cc920e',
                '97bcf97c359801ec95f8c965cc920f',
                '97bd097bd07f595b0b6fc920fb0722',
                '9778397bd097c36b0b6fc9210c8dc2',
                '9778397bd19801ec9210c9274c920e',
                '97b6b97bd19801ec95f8c965cc920f',
                '97bd07f5307f595b0b0bc920fb0722',
                '7f0e397bd097c36b0b6fc9210c8dc2',
                '9778397bd097c36c9210c9274c920e',
                '97b6b97bd19801ec95f8c965cc920f',
                '97bd07f5307f595b0b0bc920fb0722',
                '7f0e397bd097c36b0b6fc9210c8dc2',
                '9778397bd097c36c9210c9274c91aa',
                '97b6b97bd19801ec9210c965cc920e',
                '97bd07f1487f595b0b0bc920fb0722',
                '7f0e397bd097c36b0b6fc9210c8dc2',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b97bd19801ec9210c965cc920e',
                '97bcf7f1487f595b0b0bb0b6fb0722',
                '7f0e397bd097c35b0b6fc920fb0722',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b97bd19801ec9210c965cc920e',
                '97bcf7f1487f595b0b0bb0b6fb0722',
                '7f0e397bd097c35b0b6fc920fb0722',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b97bd19801ec9210c965cc920e',
                '97bcf7f1487f531b0b0bb0b6fb0722',
                '7f0e397bd097c35b0b6fc920fb0722',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b97bd19801ec9210c965cc920e',
                '97bcf7f1487f531b0b0bb0b6fb0722',
                '7f0e397bd07f595b0b6fc920fb0722',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b97bd19801ec9210c9274c920e',
                '97bcf7f0e47f531b0b0bb0b6fb0722',
                '7f0e397bd07f595b0b0bc920fb0722',
                '9778397bd097c36b0b6fc9210c91aa',
                '97b6b97bd197c36c9210c9274c920e',
                '97bcf7f0e47f531b0b0bb0b6fb0722',
                '7f0e397bd07f595b0b0bc920fb0722',
                '9778397bd097c36b0b6fc9210c8dc2',
                '9778397bd097c36c9210c9274c920e',
                '97b6b7f0e47f531b0723b0b6fb0722',
                '7f0e37f5307f595b0b0bc920fb0722',
                '7f0e397bd097c36b0b6fc9210c8dc2',
                '9778397bd097c36b0b70c9274c91aa',
                '97b6b7f0e47f531b0723b0b6fb0721',
                '7f0e37f1487f595b0b0bb0b6fb0722',
                '7f0e397bd097c35b0b6fc9210c8dc2',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b7f0e47f531b0723b0b6fb0721',
                '7f0e27f1487f595b0b0bb0b6fb0722',
                '7f0e397bd097c35b0b6fc920fb0722',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b7f0e47f531b0723b0b6fb0721',
                '7f0e27f1487f531b0b0bb0b6fb0722',
                '7f0e397bd097c35b0b6fc920fb0722',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b7f0e47f531b0723b0b6fb0721',
                '7f0e27f1487f531b0b0bb0b6fb0722',
                '7f0e397bd097c35b0b6fc920fb0722',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b7f0e47f531b0723b0b6fb0721',
                '7f0e27f1487f531b0b0bb0b6fb0722',
                '7f0e397bd07f595b0b0bc920fb0722',
                '9778397bd097c36b0b6fc9274c91aa',
                '97b6b7f0e47f531b0723b0787b0721',
                '7f0e27f0e47f531b0b0bb0b6fb0722',
                '7f0e397bd07f595b0b0bc920fb0722',
                '9778397bd097c36b0b6fc9210c91aa',
                '97b6b7f0e47f149b0723b0787b0721',
                '7f0e27f0e47f531b0723b0b6fb0722',
                '7f0e397bd07f595b0b0bc920fb0722',
                '9778397bd097c36b0b6fc9210c8dc2',
                '977837f0e37f149b0723b0787b0721',
                '7f07e7f0e47f531b0723b0b6fb0722',
                '7f0e37f5307f595b0b0bc920fb0722',
                '7f0e397bd097c35b0b6fc9210c8dc2',
                '977837f0e37f14998082b0787b0721',
                '7f07e7f0e47f531b0723b0b6fb0721',
                '7f0e37f1487f595b0b0bb0b6fb0722',
                '7f0e397bd097c35b0b6fc9210c8dc2',
                '977837f0e37f14998082b0787b06bd',
                '7f07e7f0e47f531b0723b0b6fb0721',
                '7f0e27f1487f531b0b0bb0b6fb0722',
                '7f0e397bd097c35b0b6fc920fb0722',
                '977837f0e37f14998082b0787b06bd',
                '7f07e7f0e47f531b0723b0b6fb0721',
                '7f0e27f1487f531b0b0bb0b6fb0722',
                '7f0e397bd097c35b0b6fc920fb0722',
                '977837f0e37f14998082b0787b06bd',
                '7f07e7f0e47f531b0723b0b6fb0721',
                '7f0e27f1487f531b0b0bb0b6fb0722',
                '7f0e397bd07f595b0b0bc920fb0722',
                '977837f0e37f14998082b0787b06bd',
                '7f07e7f0e47f531b0723b0b6fb0721',
                '7f0e27f1487f531b0b0bb0b6fb0722',
                '7f0e397bd07f595b0b0bc920fb0722',
                '977837f0e37f14998082b0787b06bd',
                '7f07e7f0e47f149b0723b0787b0721',
                '7f0e27f0e47f531b0b0bb0b6fb0722',
                '7f0e397bd07f595b0b0bc920fb0722',
                '977837f0e37f14998082b0723b06bd',
                '7f07e7f0e37f149b0723b0787b0721',
                '7f0e27f0e47f531b0723b0b6fb0722',
                '7f0e397bd07f595b0b0bc920fb0722',
                '977837f0e37f14898082b0723b02d5',
                '7ec967f0e37f14998082b0787b0721',
                '7f07e7f0e47f531b0723b0b6fb0722',
                '7f0e37f1487f595b0b0bb0b6fb0722',
                '7f0e37f0e37f14898082b0723b02d5',
                '7ec967f0e37f14998082b0787b0721',
                '7f07e7f0e47f531b0723b0b6fb0722',
                '7f0e37f1487f531b0b0bb0b6fb0722',
                '7f0e37f0e37f14898082b0723b02d5',
                '7ec967f0e37f14998082b0787b06bd',
                '7f07e7f0e47f531b0723b0b6fb0721',
                '7f0e37f1487f531b0b0bb0b6fb0722',
                '7f0e37f0e37f14898082b072297c35',
                '7ec967f0e37f14998082b0787b06bd',
                '7f07e7f0e47f531b0723b0b6fb0721',
                '7f0e27f1487f531b0b0bb0b6fb0722',
                '7f0e37f0e37f14898082b072297c35',
                '7ec967f0e37f14998082b0787b06bd',
                '7f07e7f0e47f531b0723b0b6fb0721',
                '7f0e27f1487f531b0b0bb0b6fb0722',
                '7f0e37f0e366aa89801eb072297c35',
                '7ec967f0e37f14998082b0787b06bd',
                '7f07e7f0e47f149b0723b0787b0721',
                '7f0e27f1487f531b0b0bb0b6fb0722',
                '7f0e37f0e366aa89801eb072297c35',
                '7ec967f0e37f14998082b0723b06bd',
                '7f07e7f0e47f149b0723b0787b0721',
                '7f0e27f0e47f531b0723b0b6fb0722',
                '7f0e37f0e366aa89801eb072297c35',
                '7ec967f0e37f14998082b0723b06bd',
                '7f07e7f0e37f14998083b0787b0721',
                '7f0e27f0e47f531b0723b0b6fb0722',
                '7f0e37f0e366aa89801eb072297c35',
                '7ec967f0e37f14898082b0723b02d5',
                '7f07e7f0e37f14998082b0787b0721',
                '7f07e7f0e47f531b0723b0b6fb0722',
                '7f0e36665b66aa89801e9808297c35',
                '665f67f0e37f14898082b0723b02d5',
                '7ec967f0e37f14998082b0787b0721',
                '7f07e7f0e47f531b0723b0b6fb0722',
                '7f0e36665b66a449801e9808297c35',
                '665f67f0e37f14898082b0723b02d5',
                '7ec967f0e37f14998082b0787b06bd',
                '7f07e7f0e47f531b0723b0b6fb0721',
                '7f0e36665b66a449801e9808297c35',
                '665f67f0e37f14898082b072297c35',
                '7ec967f0e37f14998082b0787b06bd',
                '7f07e7f0e47f531b0723b0b6fb0721',
                '7f0e26665b66a449801e9808297c35',
                '665f67f0e37f1489801eb072297c35',
                '7ec967f0e37f14998082b0787b06bd',
                '7f07e7f0e47f531b0723b0b6fb0721',
                '7f0e27f1487f531b0b0bb0b6fb0722'
            ],
            nStr1: ['日', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十'],
            nStr2: ['初', '十', '廿', '卅'],
            nStr3: ['正', '二', '三', '四', '五', '六', '七', '八', '九', '十', '冬', '腊'],
            lYearDays: function (e) {
                let t;
                let a = 348;
                for (t = 32768; t > 8; t >>= 1) {
                    if (n.lunarInfo[e - 1900] & t) {
                        a += 1;
                    } else {
                        a += 0;
                    }
                }
                return a + n.leapDays(e);
            },
            leapMonth: function (e) {
                return 15 & n.lunarInfo[e - 1900];
            },
            leapDays: function (e) {
                return n.leapMonth(e) ? (65536 & n.lunarInfo[e - 1900] ? 30 : 29) : 0;
            },
            monthDays: function (e, t) {
                return t > 12 || t < 1 ? -1 : n.lunarInfo[e - 1900] & (65536 >> t) ? 30 : 29;
            },
            solarDays: function (e, t) {
                if (t > 12 || t < 1) {
                    return -1;
                }
                const a = t - 1;
                return 1 == +a ? ((e % 4 == 0 && e % 100 != 0) || e % 400 == 0 ? 29 : 28) : n.solarMonth[a];
            },
            toGanZhiYear: function (e) {
                let t = (e - 3) % 10;
                let a = (e - 3) % 12;
                if (0 == +t) {
                    t = 10;
                }
                if (0 == +a) {
                    a = 12;
                }
                return n.Gan[t - 1] + n.Zhi[a - 1];
            },
            toAstro: function (e, t) {
                return '魔羯水瓶双鱼白羊金牛双子巨蟹狮子处女天秤天蝎射手魔羯'.substr(2 * e - (t < [20, 19, 21, 21, 21, 22, 23, 23, 23, 23, 22, 22][e - 1] ? 2 : 0), 2) + '座';
            },
            toGanZhi: function (e) {
                return n.Gan[e % 10] + n.Zhi[e % 12];
            },
            getTerm: function (e, t) {
                if (e < 1900 || e > 2100) {
                    return -1;
                }
                if (t < 1 || t > 24) {
                    return -1;
                }
                const a = n.sTermInfo[e - 1900];
                const o = [
                    parseInt('0x' + a.substr(0, 5)).toString(),
                    parseInt('0x' + a.substr(5, 5)).toString(),
                    parseInt('0x' + a.substr(10, 5)).toString(),
                    parseInt('0x' + a.substr(15, 5)).toString(),
                    parseInt('0x' + a.substr(20, 5)).toString(),
                    parseInt('0x' + a.substr(25, 5)).toString()
                ];
                const r = [
                    o[0].substr(0, 1),
                    o[0].substr(1, 2),
                    o[0].substr(3, 1),
                    o[0].substr(4, 2),
                    o[1].substr(0, 1),
                    o[1].substr(1, 2),
                    o[1].substr(3, 1),
                    o[1].substr(4, 2),
                    o[2].substr(0, 1),
                    o[2].substr(1, 2),
                    o[2].substr(3, 1),
                    o[2].substr(4, 2),
                    o[3].substr(0, 1),
                    o[3].substr(1, 2),
                    o[3].substr(3, 1),
                    o[3].substr(4, 2),
                    o[4].substr(0, 1),
                    o[4].substr(1, 2),
                    o[4].substr(3, 1),
                    o[4].substr(4, 2),
                    o[5].substr(0, 1),
                    o[5].substr(1, 2),
                    o[5].substr(3, 1),
                    o[5].substr(4, 2)
                ];
                return parseInt(r[t - 1]);
            },
            toChinaMonth: function (e) {
                if (e > 12 || e < 1) {
                    return -1;
                }
                let t = n.nStr3[e - 1];
                return (t += '月');
            },
            toChinaDay: function (e) {
                let t;
                switch (e) {
                    case 10:
                        t = '初十';
                        break;
                    case 20:
                        t = '二十';
                        break;
                    case 30:
                        t = '三十';
                        break;
                    default:
                        t = n.nStr2[Math.floor(e / 10)];
                        t += n.nStr1[e % 10];
                }
                return t;
            },
            getAnimal: function (e) {
                return n.Animals[(e - 4) % 12];
            },
            solar2lunar: function (e, t, a) {
                if (e < 1900 || e > 2100) {
                    return -1;
                }
                if (1900 == +e && 1 == +t && +a < 31) {
                    return -1;
                }
                let o;
                let r;
                let s = 0;
                let c = 0;
                e = (e ? (o = new Date(e, parseInt(t) - 1, a)) : (o = new Date())).getFullYear();
                t = o.getMonth() + 1;
                a = o.getDate();
                let l = (Date.UTC(o.getFullYear(), o.getMonth(), o.getDate()) - Date.UTC(1900, 0, 31)) / 86400000;
                for (r = 1900; r < 2101 && l > 0; r++) {
                    l -= c = n.lYearDays(r);
                }
                if (l < 0) {
                    l += c;
                    r--;
                }
                const i = new Date();
                let d = false;
                if (i.getFullYear() === +e && i.getMonth() + 1 === +t && i.getDate() === +a) {
                    d = true;
                }
                let f = o.getDay();
                const b = n.nStr1[f];
                if (0 == +f) {
                    f = 7;
                }
                const h = r;
                s = n.leapMonth(r);
                let u = false;
                for (r = 1; r < 13 && l > 0; r++) {
                    if (s > 0 && r === s + 1 && false === u) {
                        --r;
                        u = true;
                        c = n.leapDays(h);
                    } else {
                        c = n.monthDays(h, r);
                    }
                    if (true === u && r === s + 1) {
                        u = false;
                    }
                    l -= c;
                }
                if (0 === l && s > 0 && r === s + 1) {
                    if (u) {
                        u = false;
                    } else {
                        u = true;
                        --r;
                    }
                }
                if (l < 0) {
                    l += c;
                    --r;
                }
                const y = r;
                const m = l + 1;
                const D = t - 1;
                const p = n.toGanZhiYear(h);
                const g = n.getTerm(e, 2 * t - 1);
                const T = n.getTerm(e, 2 * t);
                let C = n.toGanZhi(12 * (e - 1900) + t + 11);
                if (a >= g) {
                    C = n.toGanZhi(12 * (e - 1900) + t + 12);
                }
                let w = false;
                let M = null;
                if (+g === a) {
                    w = true;
                    M = n.solarTerm[2 * t - 2];
                }
                if (+T === a) {
                    w = true;
                    M = n.solarTerm[2 * t - 1];
                }
                const _ = Date.UTC(e, D, 1, 0, 0, 0, 0) / 86400000 + 25567 + 10;
                const S = n.toGanZhi(_ + a - 1);
                const k = n.toAstro(t, a);
                return {
                    lYear: h,
                    lMonth: y,
                    lDay: m,
                    Animal: n.getAnimal(h),
                    IMonthCn: (u ? '闰' : '') + n.toChinaMonth(y),
                    IDayCn: n.toChinaDay(m),
                    cYear: e,
                    cMonth: t,
                    cDay: a,
                    gzYear: p,
                    gzMonth: C,
                    gzDay: S,
                    isToday: d,
                    isLeap: u,
                    nWeek: f,
                    ncWeek: '星期' + b,
                    isTerm: w,
                    Term: M,
                    astro: k
                };
            },
            lunar2solar: function (e, t, a, o) {
                o = !!o;
                const r = n.leapMonth(e);
                if (o && r !== t) {
                    return -1;
                }
                if ((2100 == +e && 12 == +t && +a > 1) || (1900 == +e && 1 == +t && +a < 31)) {
                    return -1;
                }
                const s = n.monthDays(e, t);
                let c = s;
                if (o) {
                    c = n.leapDays(e, t);
                }
                if (e < 1900 || e > 2100 || a > c) {
                    return -1;
                }
                let l = 0;
                for (let t = 1900; t < e; t++) {
                    l += n.lYearDays(t);
                }
                let i = 0;
                let d = false;
                for (let a = 1; a < t; a++) {
                    i = n.leapMonth(e);
                    d || (i <= a && i > 0 && ((l += n.leapDays(e)), (d = true)));
                    l += n.monthDays(e, a);
                }
                if (o) {
                    l += s;
                }
                const f = Date.UTC(1900, 1, 30, 0, 0, 0);
                const b = new Date(86400000 * (l + a - 31) + f);
                const h = b.getUTCFullYear();
                const u = b.getUTCMonth() + 1;
                const y = b.getUTCDate();
                return n.solar2lunar(h, u, y);
            }
        };
        const { Gan: o, Zhi: r, nStr1: s, nStr2: c, nStr3: l, Animals: i, solarTerm: d, lunarInfo: f, sTermInfo: b, solarMonth: h, ...u } = n;
        var y = u;
        t.default = y;
    },
    function (e, t, a) {
        'use strict';

        Object.defineProperty(t, '__esModule', {
            value: true
        });
        t.default = void 0;
        var n = c(a(0));
        var o = c(a(4));
        var r = c(a(2));
        var s = a(1);
        function c(e) {
            return e && e.__esModule
                ? e
                : {
                      default: e
                  };
        }
        const l = new s.Logger();
        const i = new s.GetDate();
        const d = Object.prototype.toString;
        class f extends n.default {
            constructor(e) {
                super(e);
                this.Component = e;
            }
            getCalendarConfig() {
                return this.Component.config;
            }
            buildDate(e, t) {
                const a = i.todayDate();
                const n = i.thisMonthDays(e, t);
                const o = [];
                const { showLunar: s } = this.getCalendarConfig();
                for (let c = 1; c <= n; c++) {
                    const n = +a.year == +e && +a.month == +t && c === +a.date;
                    const l = this.getCalendarConfig();
                    const d = {
                        year: e,
                        month: t,
                        day: c,
                        choosed: false,
                        week: i.dayOfWeek(e, t, c),
                        isToday: n && l.highlightToday
                    };
                    if (s) {
                        d.lunar = r.default.solar2lunar(+d.year, +d.month, +d.day);
                    }
                    o.push(d);
                }
                return o;
            }
            enableArea(e = []) {
                if (2 === e.length) {
                    if (this.__judgeParam(e)) {
                        let { days: t = [], selectedDay: a = [] } = this.getData('calendar');
                        const { startTimestamp: n, endTimestamp: o } = (0, s.convertEnableAreaToTimestamp)(e);
                        const r = this.__handleEnableArea(
                            {
                                dateArea: e,
                                days: t,
                                startTimestamp: n,
                                endTimestamp: o
                            },
                            a
                        );
                        this.setData({
                            'calendar.enableArea': e,
                            'calendar.days': r.dates,
                            'calendar.selectedDay': r.selectedDay,
                            'calendar.enableAreaTimestamp': [n, o]
                        });
                    }
                } else {
                    l.warn('enableArea()参数需为时间范围数组，形如：["2018-8-4" , "2018-8-24"]');
                }
            }
            enableDays(e = []) {
                const { enableArea: t = [] } = this.getData('calendar');
                let a = [];
                if (t.length) {
                    a = (0, s.delRepeatedEnableDay)(e, t);
                } else {
                    a = (0, s.converEnableDaysToTimestamp)(e);
                }
                let { days: n = [], selectedDay: o = [] } = this.getData('calendar');
                const r = this.__handleEnableDays(
                    {
                        days: n,
                        expectEnableDaysTimestamp: a
                    },
                    o
                );
                this.setData({
                    'calendar.days': r.dates,
                    'calendar.selectedDay': r.selectedDay,
                    'calendar.enableDays': e,
                    'calendar.enableDaysTimestamp': a
                });
            }
            setSelectedDays(e) {
                if (!(0, o.default)(this.Component).getCalendarConfig().multi) {
                    return l.warn('单选模式下不能设置多日期选中，请配置 multi');
                }
                let { days: t } = this.getData('calendar');
                let a = [];
                if (e) {
                    if (e && e.length) {
                        const { dates: n, selectedDates: o } = this.__handleSelectedDays(t, a, e);
                        t = n;
                        a = o;
                    }
                } else {
                    t.map((e) => {
                        e.choosed = true;
                        e.showTodoLabel = false;
                    });
                    a = t;
                }
                (0, o.default)(this.Component).setCalendarConfig('multi', true);
                this.setData({
                    'calendar.days': t,
                    'calendar.selectedDay': a
                });
            }
            disableDays(e) {
                const { disableDays: t = [], days: a } = this.getData('calendar');
                if ('[object Array]' !== Object.prototype.toString.call(e)) {
                    return l.warn('disableDays 参数为数组');
                }
                let n = [];
                if (e.length) {
                    const o = (n = (0, s.uniqueArrayByDate)(e.concat(t))).map((e) => i.toTimeStr(e));
                    a.forEach((e) => {
                        const t = i.toTimeStr(e);
                        if (o.includes(t)) {
                            e.disable = true;
                        }
                    });
                } else {
                    a.forEach((e) => {
                        e.disable = false;
                    });
                }
                this.setData({
                    'calendar.days': a,
                    'calendar.disableDays': n
                });
            }
            chooseArea(e = []) {
                return new Promise((t, a) => {
                    if (1 === e.length) {
                        e = e.concat(e);
                    }
                    if (2 === e.length) {
                        if (this.__judgeParam(e)) {
                            const n = (0, o.default)(this.Component).getCalendarConfig();
                            const { startTimestamp: r, endTimestamp: c } = (0, s.convertEnableAreaToTimestamp)(e);
                            this.setData(
                                {
                                    calendarConfig: {
                                        ...n,
                                        chooseAreaMode: true,
                                        mulit: true
                                    },
                                    'calendar.chooseAreaTimestamp': [r, c]
                                },
                                () => {
                                    this.__chooseContinuousDates(r, c).then(t).catch(a);
                                }
                            );
                        }
                    }
                });
            }
            __pusheNextMonthDateArea(e, t, a) {
                const n = this.buildDate(e.year, e.month);
                let o = n.length;
                for (let e = 0; e < o; e++) {
                    const r = n[e];
                    const c = (0, s.getDateTimeStamp)(r);
                    if (c <= t) {
                        a.push({
                            ...r,
                            choosed: true
                        });
                    }
                    if (e === o - 1 && c < t) {
                        this.__pusheNextMonthDateArea(i.nextMonth(r), t, a);
                    }
                }
            }
            __pushPrevMonthDateArea(e, t, a) {
                const n = i.sortDates(this.buildDate(e.year, e.month), 'desc');
                let o = n.length;
                for (let e = 0; e < o; e++) {
                    const r = n[e];
                    const c = (0, s.getDateTimeStamp)(r);
                    if (!(c >= t)) {
                        return;
                    }
                    a.push({
                        ...r,
                        choosed: true
                    });
                    if (e === o - 1 && c > t) {
                        this.__pushPrevMonthDateArea(i.prevMonth(r), t, a);
                    }
                }
            }
            __calcDateWhenNotInOneMonth(e) {
                const { firstDate: t, lastDate: a, startTimestamp: n, endTimestamp: o, filterSelectedDate: r } = e;
                if ((0, s.getDateTimeStamp)(t) > n) {
                    this.__pushPrevMonthDateArea(i.prevMonth(t), o, r);
                }
                if ((0, s.getDateTimeStamp)(a) < o) {
                    this.__pusheNextMonthDateArea(i.nextMonth(a), o, r);
                }
                return [...i.sortDates(r)];
            }
            __chooseContinuousDates(e, t) {
                return new Promise((a, n) => {
                    const { days: o, selectedDay: r = [] } = this.getData('calendar');
                    const c = [];
                    let l = [];
                    r.forEach((a) => {
                        const n = (0, s.getDateTimeStamp)(a);
                        if (n >= e && n <= t) {
                            l.push(a);
                            c.push(i.toTimeStr(a));
                        }
                    });
                    o.forEach((a) => {
                        const n = (0, s.getDateTimeStamp)(a);
                        const o = c.includes(i.toTimeStr(a));
                        if (n >= e && n <= t) {
                            if (o) {
                                return;
                            }
                            a.choosed = true;
                            l.push(a);
                        } else {
                            a.choosed = false;
                            if (o) {
                                const e = l.findIndex((e) => i.toTimeStr(e) === i.toTimeStr(a));
                                if (e > -1) {
                                    l.splice(e, 1);
                                }
                            }
                        }
                    });
                    const d = o[0];
                    const f = o[o.length - 1];
                    const b = this.__calcDateWhenNotInOneMonth({
                        firstDate: d,
                        lastDate: f,
                        startTimestamp: e,
                        endTimestamp: t,
                        filterSelectedDate: l
                    });
                    try {
                        this.setData(
                            {
                                'calendar.days': [...o],
                                'calendar.selectedDay': b
                            },
                            () => {
                                a(b);
                            }
                        );
                    } catch (e) {
                        n(e);
                    }
                });
            }
            setDateStyle(e) {
                if ('[object Array]' !== d.call(e)) {
                    return;
                }
                const { days: t, specialStyleDates: a } = this.getData('calendar');
                if ('[object Array]' === d.call(a)) {
                    e = (0, s.uniqueArrayByDate)([...a, ...e]);
                }
                const n = e.map((e) => `${e.year}_${e.month}_${e.day}`);
                const o = t.map((t) => {
                    const a = n.indexOf(`${t.year}_${t.month}_${t.day}`);
                    return a > -1
                        ? {
                              ...t,
                              class: e[a].class
                          }
                        : {
                              ...t
                          };
                });
                this.setData({
                    'calendar.days': o,
                    'calendar.specialStyleDates': e
                });
            }
            __judgeParam(e) {
                const { start: t, end: a, startTimestamp: n, endTimestamp: o } = (0, s.convertEnableAreaToTimestamp)(e);
                if (!t || !a) {
                    return;
                }
                const r = i.thisMonthDays(t[0], t[1]);
                const c = i.thisMonthDays(a[0], a[1]);
                return t[2] > r || t[2] < 1
                    ? (l.warn('enableArea() 开始日期错误，指定日期不在当前月份天数范围内'), false)
                    : t[1] > 12 || t[1] < 1
                    ? (l.warn('enableArea() 开始日期错误，月份超出1-12月份'), false)
                    : a[2] > c || a[2] < 1
                    ? (l.warn('enableArea() 截止日期错误，指定日期不在当前月份天数范围内'), false)
                    : a[1] > 12 || a[1] < 1
                    ? (l.warn('enableArea() 截止日期错误，月份超出1-12月份'), false)
                    : !(n > o) || (l.warn('enableArea()参数最小日期大于了最大日期'), false);
            }
            __handleEnableArea(e = {}, t = []) {
                const { area: a, days: n, startTimestamp: o, endTimestamp: r } = e;
                const c = this.getData('calendar.enableDays') || [];
                let l = [];
                if (c.length) {
                    l = (0, s.delRepeatedEnableDay)(c, a);
                }
                const { disablePastDay: d, disableLaterDay: f } = this.getCalendarConfig();
                let b = i.todayTimestamp();
                const h = [...n];
                h.forEach((e) => {
                    const a = +i.newDate(e.year, e.month, e.day).getTime();
                    if (((+o > a || a > +r) && !l.includes(a)) || (d && a < b) || (f && a > b)) {
                        e.disable = true;
                        if (e.choosed) {
                            e.choosed = false;
                            t = t.filter((t) => i.toTimeStr(e) !== i.toTimeStr(t));
                        }
                    } else {
                        if (e.disable) {
                            e.disable = false;
                        }
                    }
                });
                return {
                    dates: h,
                    selectedDay: t
                };
            }
            __handleEnableDays(e = {}, t = []) {
                const { days: a, expectEnableDaysTimestamp: n } = e;
                const { enableAreaTimestamp: o = [] } = this.getData('calendar');
                const r = [...a];
                r.forEach((e) => {
                    const a = i.newDate(e.year, e.month, e.day).getTime();
                    let r = false;
                    if (o.length) {
                        if ((+o[0] > +a || +a > +o[1]) && !n.includes(+a)) {
                            r = true;
                        }
                    } else {
                        n.includes(+a) || (r = true);
                    }
                    if (r) {
                        e.disable = true;
                        if (e.choosed) {
                            e.choosed = false;
                            t = t.filter((t) => i.toTimeStr(e) !== i.toTimeStr(t));
                        }
                    } else {
                        e.disable = false;
                    }
                });
                return {
                    dates: r,
                    selectedDay: t
                };
            }
            __handleSelectedDays(e = [], t = [], a) {
                const { selectedDay: n, showLabelAlways: o } = this.getData('calendar');
                if (n && n.length) {
                    t = (0, s.uniqueArrayByDate)(n.concat(a));
                } else {
                    t = a;
                }
                const { year: r, month: c } = e[0];
                const l = [];
                t.forEach((e) => {
                    if (+e.year == +r && +e.month == +c) {
                        l.push(i.toTimeStr(e));
                    }
                });
                [...e].map((e) => {
                    if (l.includes(i.toTimeStr(e))) {
                        e.choosed = true;
                        if (o && e.showTodoLabel) {
                            e.showTodoLabel = true;
                        } else {
                            e.showTodoLabel = false;
                        }
                    }
                });
                return {
                    dates: e,
                    selectedDates: t
                };
            }
        }
        t.default = (e) => new f(e);
    },
    function (e, t, a) {
        'use strict';

        Object.defineProperty(t, '__esModule', {
            value: true
        });
        t.default = void 0;
        var n;
        var o =
            (n = a(0)) && n.__esModule
                ? n
                : {
                      default: n
                  };
        class r extends o.default {
            constructor(e) {
                super(e);
                this.Component = e;
            }
            getCalendarConfig() {
                return this.Component && this.Component.config ? this.Component.config : {};
            }
            setCalendarConfig(e) {
                return new Promise((t, a) => {
                    if (!this.Component || !this.Component.config) {
                        return void a('异常：未找到组件配置信息');
                    }
                    let n = {
                        ...this.Component.config,
                        ...e
                    };
                    this.Component.config = n;
                    this.setData(
                        {
                            calendarConfig: n
                        },
                        () => {
                            t(n);
                        }
                    );
                });
            }
        }
        t.default = (e) => new r(e);
    },
    function (e, t, a) {
        'use strict';

        Object.defineProperty(t, '__esModule', {
            value: true
        });
        t.default = void 0;
        var n = i(a(3));
        var o = i(a(0));
        var r = i(a(6));
        var s = i(a(4));
        var c = i(a(2));
        var l = a(1);
        function i(e) {
            return e && e.__esModule
                ? e
                : {
                      default: e
                  };
        }
        const d = new l.GetDate();
        const f = new l.Logger();
        class b extends o.default {
            constructor(e) {
                super(e);
                this.Component = e;
                this.getCalendarConfig = (0, s.default)(this.Component).getCalendarConfig;
            }
            switchWeek(e, t) {
                return new Promise((a, n) => {
                    if ((0, s.default)(this.Component).getCalendarConfig().multi) {
                        return f.warn('多选模式不能切换周月视图');
                    }
                    const { selectedDay: o = [], curYear: c, curMonth: l } = this.getData('calendar');
                    if (!o.length) {
                        return this.__tipsWhenCanNotSwtich();
                    }
                    const i = o[0];
                    if ('week' === e) {
                        if (this.Component.weekMode) {
                            return;
                        }
                        const e = t || i;
                        const { year: o, month: r } = e;
                        if (c !== o || l !== r) {
                            return this.__tipsWhenCanNotSwtich();
                        }
                        this.Component.weekMode = true;
                        this.setData({
                            'calendar.weekMode': true
                        });
                        this.jump(e).then(a).catch(n);
                    } else {
                        this.Component.weekMode = false;
                        this.setData({
                            'calendar.weekMode': false
                        });
                        (0, r.default)(this.Component).renderCalendar(c, l, t).then(a).catch(n);
                    }
                });
            }
            updateCurrYearAndMonth(e) {
                let { days: t, curYear: a, curMonth: n } = this.getData('calendar');
                const { month: o } = t[0];
                const { month: r } = t[t.length - 1];
                const s = d.thisMonthDays(a, n);
                const c = t[t.length - 1];
                const l = t[0];
                if ((c.day + 7 > s || (n === o && o !== r)) && 'next' === e) {
                    if ((n += 1) > 12) {
                        a += 1;
                        n = 1;
                    }
                } else {
                    if ((+l.day <= 7 || (n === r && o !== r)) && 'prev' === e && (n -= 1) <= 0) {
                        a -= 1;
                        n = 12;
                    }
                }
                return {
                    Uyear: a,
                    Umonth: n
                };
            }
            calculateLastDay() {
                const { days: e = [], curYear: t, curMonth: a } = this.getData('calendar');
                return {
                    lastDayInThisWeek: e[e.length - 1].day,
                    lastDayInThisMonth: d.thisMonthDays(t, a)
                };
            }
            calculateFirstDay() {
                const { days: e } = this.getData('calendar');
                return {
                    firstDayInThisWeek: e[0].day
                };
            }
            firstWeekInMonth(e, t, a) {
                let o = d.dayOfWeek(e, t, 1);
                if (a && 0 === o) {
                    o = 7;
                }
                const [, r] = [0, 7 - o];
                let s = this.getData('calendar.days') || [];
                if (this.Component.weekMode) {
                    s = (0, n.default)(this.Component).buildDate(e, t);
                }
                return s.slice(0, a ? r + 1 : r);
            }
            lastWeekInMonth(e, t, a) {
                const o = d.thisMonthDays(e, t);
                const r = d.dayOfWeek(e, t, o);
                const [s, c] = [o - r, o];
                let l = this.getData('calendar.days') || [];
                if (this.Component.weekMode) {
                    l = (0, n.default)(this.Component).buildDate(e, t);
                }
                return l.slice(a ? s : s - 1, c);
            }
            initSelectedDay(e) {
                let t = [...e];
                const { selectedDay: a = [] } = this.getData('calendar');
                const n = a.map((e) => `${+e.year}-${+e.month}-${+e.day}`);
                const o = this.getCalendarConfig();
                return (t = t.map((e) => {
                    let t = {
                        ...e
                    };
                    if (n.includes(`${+t.year}-${+t.month}-${+t.day}`)) {
                        t.choosed = true;
                    } else {
                        t.choosed = false;
                    }
                    t = this.__setTodoWhenJump(t, o);
                    if (o.showLunar) {
                        t = this.__setSolarLunar(t);
                    }
                    if (o.highlightToday) {
                        t = this.__highlightToday(t);
                    }
                    return t;
                }));
            }
            setEnableAreaOnWeekMode(e = []) {
                let { todayTimestamp: t, enableAreaTimestamp: a = [], enableDaysTimestamp: n = [] } = this.getData('calendar');
                e.forEach((e) => {
                    const o = d.newDate(e.year, e.month, e.day).getTime();
                    let r = false;
                    if (a.length) {
                        if ((+a[0] > +o || +o > +a[1]) && !n.includes(+o)) {
                            r = true;
                        }
                    } else {
                        if (n.length && !n.includes(+o)) {
                            r = true;
                        }
                    }
                    if (r) {
                        e.disable = true;
                        e.choosed = false;
                    }
                    const { disablePastDay: c } = (0, s.default)(this.Component).getCalendarConfig() || {};
                    if (c && o - t < 0 && !e.disable) {
                        e.disable = true;
                    }
                });
            }
            calculateNextWeekDays() {
                let { lastDayInThisWeek: e, lastDayInThisMonth: t } = this.calculateLastDay();
                let { curYear: a, curMonth: o } = this.getData('calendar');
                let r = [];
                if (t - e >= 7) {
                    const { Uyear: t, Umonth: n } = this.updateCurrYearAndMonth('next');
                    a = t;
                    o = n;
                    for (let t = e + 1; t <= e + 7; t++) {
                        r.push({
                            year: a,
                            month: o,
                            day: t,
                            week: d.dayOfWeek(a, o, t)
                        });
                    }
                } else {
                    for (let n = e + 1; n <= t; n++) {
                        r.push({
                            year: a,
                            month: o,
                            day: n,
                            week: d.dayOfWeek(a, o, n)
                        });
                    }
                    const { Uyear: n, Umonth: s } = this.updateCurrYearAndMonth('next');
                    a = n;
                    o = s;
                    for (let n = 1; n <= 7 - (t - e); n++) {
                        r.push({
                            year: a,
                            month: o,
                            day: n,
                            week: d.dayOfWeek(a, o, n)
                        });
                    }
                }
                r = this.initSelectedDay(r);
                this.setEnableAreaOnWeekMode(r);
                this.setData(
                    {
                        'calendar.curYear': a,
                        'calendar.curMonth': o,
                        'calendar.days': r
                    },
                    () => {
                        (0, n.default)(this.Component).setDateStyle();
                    }
                );
            }
            calculatePrevWeekDays() {
                let { firstDayInThisWeek: e } = this.calculateFirstDay();
                let { curYear: t, curMonth: a } = this.getData('calendar');
                let o = [];
                if (e - 7 > 0) {
                    const { Uyear: n, Umonth: r } = this.updateCurrYearAndMonth('prev');
                    t = n;
                    a = r;
                    for (let n = e - 7; n < e; n++) {
                        o.push({
                            year: t,
                            month: a,
                            day: n,
                            week: d.dayOfWeek(t, a, n)
                        });
                    }
                } else {
                    let n = [];
                    for (let o = 1; o < e; o++) {
                        n.push({
                            year: t,
                            month: a,
                            day: o,
                            week: d.dayOfWeek(t, a, o)
                        });
                    }
                    const { Uyear: r, Umonth: s } = this.updateCurrYearAndMonth('prev');
                    t = r;
                    a = s;
                    const c = d.thisMonthDays(t, a);
                    for (let n = c - Math.abs(e - 7); n <= c; n++) {
                        o.push({
                            year: t,
                            month: a,
                            day: n,
                            week: d.dayOfWeek(t, a, n)
                        });
                    }
                    o = o.concat(n);
                }
                o = this.initSelectedDay(o);
                this.setEnableAreaOnWeekMode(o);
                this.setData(
                    {
                        'calendar.curYear': t,
                        'calendar.curMonth': a,
                        'calendar.days': o
                    },
                    () => {
                        (0, n.default)(this.Component).setDateStyle();
                    }
                );
            }
            calculateDatesWhenJump({ year: e, month: t, day: a }, { firstWeekDays: n, lastWeekDays: o }, r) {
                const s = this.__dateIsInWeek(
                    {
                        year: e,
                        month: t,
                        day: a
                    },
                    n
                );
                const c = this.__dateIsInWeek(
                    {
                        year: e,
                        month: t,
                        day: a
                    },
                    o
                );
                let l = [];
                return s
                    ? (l = this.__calculateDatesWhenInFirstWeek(n, r))
                    : c
                    ? (l = this.__calculateDatesWhenInLastWeek(o, r))
                    : (l = this.__calculateDates(
                          {
                              year: e,
                              month: t,
                              day: a
                          },
                          r
                      ));
            }
            jump({ year: e, month: t, day: a }) {
                return new Promise((o) => {
                    if (!a) {
                        return;
                    }
                    const r = this.getCalendarConfig();
                    const s = 'Mon' === r.firstDayOfWeek;
                    const c = this.firstWeekInMonth(e, t, s);
                    let l = this.lastWeekInMonth(e, t, s);
                    let i = this.calculateDatesWhenJump(
                        {
                            year: e,
                            month: t,
                            day: a
                        },
                        {
                            firstWeekDays: c,
                            lastWeekDays: l
                        },
                        s
                    );
                    i = i.map((n) => {
                        let o = {
                            ...n
                        };
                        if (+o.year == +e && +o.month == +t && +o.day == +a) {
                            o.choosed = true;
                        }
                        o = this.__setTodoWhenJump(o, r);
                        if (r.showLunar) {
                            o = this.__setSolarLunar(o);
                        }
                        if (r.highlightToday) {
                            o = this.__highlightToday(o);
                        }
                        return o;
                    });
                    this.setEnableAreaOnWeekMode(i);
                    this.setData(
                        {
                            'calendar.days': i,
                            'calendar.curYear': e,
                            'calendar.curMonth': t,
                            'calendar.empytGrids': [],
                            'calendar.lastEmptyGrids': [],
                            'calendar.selectedDay': i.filter((e) => e.choosed)
                        },
                        () => {
                            (0, n.default)(this.Component).setDateStyle();
                            o({
                                year: e,
                                month: t,
                                date: a
                            });
                        }
                    );
                });
            }
            __setTodoWhenJump(e) {
                const t = {
                    ...e
                };
                const { todoLabels: a = [], showLabelAlways: n } = this.getData('calendar');
                const o = a.map((e) => `${+e.year}-${+e.month}-${+e.day}`).indexOf(`${+t.year}-${+t.month}-${+t.day}`);
                if (-1 !== o) {
                    t.showTodoLabel = !!n || !t.choosed;
                    const e = a[o] || {};
                    if (t.showTodoLabel && e.todoText) {
                        t.todoText = e.todoText;
                    }
                }
                return t;
            }
            __setSolarLunar(e) {
                const t = {
                    ...e
                };
                t.lunar = c.default.solar2lunar(+t.year, +t.month, +t.day);
                return t;
            }
            __highlightToday(e) {
                const t = {
                    ...e
                };
                const a = d.todayDate();
                const n = +a.year == +t.year && +a.month == +t.month && +t.day == +a.date;
                t.isToday = n;
                return t;
            }
            __calculateDatesWhenInFirstWeek(e, t) {
                const a = [...e];
                if (a.length < 7) {
                    let e;
                    let { year: t, month: n } = a[0];
                    let o = 7 - a.length;
                    for (n > 1 ? ((n -= 1), (e = d.thisMonthDays(t, n))) : ((n = 12), (t -= 1), (e = d.thisMonthDays(t, n))); o; ) {
                        a.unshift({
                            year: t,
                            month: n,
                            day: e,
                            week: d.dayOfWeek(t, n, e)
                        });
                        e -= 1;
                        o -= 1;
                    }
                }
                return a;
            }
            __calculateDatesWhenInLastWeek(e, t) {
                const a = [...e];
                if (t && a.length < 7) {
                    let { year: e, month: t } = a[0];
                    let n = 7 - a.length;
                    let o = 1;
                    for (t > 11 ? ((t = 1), (e += 1)) : (t += 1); n; ) {
                        a.push({
                            year: e,
                            month: t,
                            day: o,
                            week: d.dayOfWeek(e, t, o)
                        });
                        o += 1;
                        n -= 1;
                    }
                }
                return a;
            }
            __calculateDates({ year: e, month: t, day: a }, o) {
                const r = d.dayOfWeek(e, t, a);
                let s = [a - r, a + (6 - r)];
                if (o) {
                    s = [a + 1 - r, a + (7 - r)];
                }
                return (0, n.default)(this.Component)
                    .buildDate(e, t)
                    .slice(s[0] - 1, s[1]);
            }
            __dateIsInWeek(e, t) {
                return t.find((t) => +t.year == +e.year && +t.month == +e.month && +t.day == +e.day);
            }
            __tipsWhenCanNotSwtich() {
                f.info('当前月份未选中日期下切换为周视图，不能明确该展示哪一周的日期，故此情况不允许切换');
            }
        }
        t.default = (e) => new b(e);
    },
    function (e, t, a) {
        'use strict';

        Object.defineProperty(t, '__esModule', {
            value: true
        });
        t.default = void 0;
        var n = l(a(3));
        var o = l(a(7));
        var r = l(a(0));
        var s = l(a(2));
        var c = a(1);
        function l(e) {
            return e && e.__esModule
                ? e
                : {
                      default: e
                  };
        }
        const i = new c.GetDate();
        class d extends r.default {
            constructor(e) {
                super(e);
                this.Component = e;
            }
            getCalendarConfig() {
                return this.Component.config;
            }
            renderCalendar(e, t, a) {
                return new Promise((r) => {
                    this.calculateEmptyGrids(e, t);
                    this.calculateDays(e, t, a).then(() => {
                        const { todoLabels: a, specialStyleDates: s } = this.getData('calendar') || {};
                        if (a && a.find((a) => +a.month == +t && +a.year == +e)) {
                            (0, o.default)(this.Component).setTodoLabels();
                        }
                        if (s && s.length && s.find((a) => +a.month == +t && +a.year == +e)) {
                            (0, n.default)(this.Component).setDateStyle(s);
                        }
                        if (this.Component.firstRender) {
                            r({
                                firstRender: false
                            });
                        } else {
                            r({
                                firstRender: true
                            });
                        }
                    });
                });
            }
            calculateEmptyGrids(e, t) {
                this.calculatePrevMonthGrids(e, t);
                this.calculateNextMonthGrids(e, t);
            }
            calculatePrevMonthGrids(e, t) {
                let a = [];
                const n = i.thisMonthDays(e, t - 1);
                let o = i.firstDayOfWeek(e, t);
                const r = this.getCalendarConfig() || {};
                if ('Mon' === r.firstDayOfWeek) {
                    if (0 === o) {
                        o = 6;
                    } else {
                        o -= 1;
                    }
                }
                if (o > 0) {
                    const c = n - o;
                    const { onlyShowCurrentMonth: l } = r;
                    const { showLunar: i } = this.getCalendarConfig();
                    for (let o = n; o > c; o--) {
                        if (l) {
                            a.push('');
                        } else {
                            a.push({
                                day: o,
                                lunar: i ? s.default.solar2lunar(e, t - 1, o) : null
                            });
                        }
                    }
                    this.setData({
                        'calendar.empytGrids': a.reverse()
                    });
                } else {
                    this.setData({
                        'calendar.empytGrids': null
                    });
                }
            }
            calculateExtraEmptyDate(e, t, a) {
                let n = 0;
                if (2 == +t) {
                    n += 7;
                    let o = i.dayOfWeek(e, t, 1);
                    if ('Mon' === a.firstDayOfWeek) {
                        if (1 == +o) {
                            n += 7;
                        }
                    } else {
                        if (0 == +o) {
                            n += 7;
                        }
                    }
                } else {
                    let o = i.dayOfWeek(e, t, 1);
                    if ('Mon' === a.firstDayOfWeek) {
                        if (0 !== o && o < 6) {
                            n += 7;
                        }
                    } else {
                        if (o < 5) {
                            n += 7;
                        }
                    }
                }
                return n;
            }
            calculateNextMonthGrids(e, t) {
                let a = [];
                const n = i.thisMonthDays(e, t);
                let o = i.dayOfWeek(e, t, n);
                const r = this.getCalendarConfig() || {};
                if ('Mon' === r.firstDayOfWeek) {
                    if (0 === o) {
                        o = 6;
                    } else {
                        o -= 1;
                    }
                }
                let c = 7 - (o + 1);
                const { onlyShowCurrentMonth: l, showLunar: d } = r;
                l || (c += this.calculateExtraEmptyDate(e, t, r));
                for (let n = 1; n <= c; n++) {
                    if (l) {
                        a.push('');
                    } else {
                        a.push({
                            day: n,
                            lunar: d ? s.default.solar2lunar(e, t + 1, n) : null
                        });
                    }
                }
                this.setData({
                    'calendar.lastEmptyGrids': a
                });
            }
            setSelectedDay(e, t, a) {
                let n = [];
                const o = this.getCalendarConfig();
                if (o.noDefault) {
                    n = [];
                    o.noDefault = false;
                } else {
                    const o = this.getData('calendar') || {};
                    const { showLunar: r } = this.getCalendarConfig();
                    if (a) {
                        n = [
                            {
                                year: e,
                                month: t,
                                day: a,
                                choosed: true,
                                week: i.dayOfWeek(e, t, a),
                                lunar: r ? s.default.solar2lunar(e, t, a) : null
                            }
                        ];
                    } else {
                        n = o.selectedDay;
                    }
                }
                return n;
            }
            calculateDays(e, t, a) {
                return new Promise((o) => {
                    let r = [];
                    const { todayTimestamp: s, disableDays: l = [], chooseAreaTimestamp: d = [] } = this.getData('calendar');
                    r = (0, n.default)(this.Component).buildDate(e, t);
                    const f = this.setSelectedDay(e, t, a);
                    const b = f.map((e) => i.toTimeStr(e));
                    const h = l.map((e) => i.toTimeStr(e));
                    const [u, y] = d;
                    r.forEach((e) => {
                        const t = i.toTimeStr(e);
                        const a = (0, c.getDateTimeStamp)(e);
                        if (b.includes(t)) {
                            e.choosed = true;
                            if (a > y || a < u) {
                                const t = f.findIndex((t) => i.toTimeStr(t) === i.toTimeStr(e));
                                f.splice(t, 1);
                            }
                        } else {
                            if (u && y && a >= u && a <= y) {
                                e.choosed = true;
                                f.push(e);
                            }
                        }
                        if (h.includes(t)) {
                            e.disable = true;
                        }
                        const { disablePastDay: n, disableLaterDay: o } = this.getCalendarConfig();
                        let r = false;
                        if (n) {
                            r = n && a - s < 0 && !e.disable;
                        } else {
                            if (o) {
                                r = o && a - s > 0 && !e.disable;
                            }
                        }
                        if (r || this.__isDisable(a)) {
                            e.disable = true;
                            e.choosed = false;
                        }
                    });
                    this.setData(
                        {
                            'calendar.days': r,
                            'calendar.selectedDay': [...f] || false
                        },
                        () => {
                            o();
                        }
                    );
                });
            }
            __isDisable(e) {
                const { enableArea: t = [], enableDays: a = [], enableAreaTimestamp: n = [] } = this.getData('calendar');
                let o = false;
                let r = (0, c.converEnableDaysToTimestamp)(a);
                if (t.length) {
                    r = (0, c.delRepeatedEnableDay)(a, t);
                }
                if (n.length) {
                    if ((+n[0] > +e || +e > +n[1]) && !r.includes(+e)) {
                        o = true;
                    }
                } else {
                    if (r.length && !r.includes(+e)) {
                        o = true;
                    }
                }
                return o;
            }
        }
        t.default = (e) => new d(e);
    },
    function (e, t, a) {
        'use strict';

        Object.defineProperty(t, '__esModule', {
            value: true
        });
        t.default = void 0;
        var n;
        var o =
            (n = a(0)) && n.__esModule
                ? n
                : {
                      default: n
                  };
        var r = a(1);
        const s = new r.Logger();
        const c = new r.GetDate();
        class l extends o.default {
            constructor(e) {
                super(e);
                this.Component = e;
            }
            setTodoLabels(e) {
                if (e) {
                    this.Component.todoConfig = e;
                }
                const t = this.getData('calendar');
                if (!t || !t.days) {
                    return s.warn('请等待日历初始化完成后再调用该方法');
                }
                const a = [...t.days];
                const { curYear: n, curMonth: o } = t;
                const { circle: c, dotColor: l = '', pos: i = 'bottom', showLabelAlways: d, days: f = [] } = e || this.Component.todoConfig || {};
                const { todoLabels: b = [], todoLabelPos: h, todoLabelColor: u } = t;
                const y = this.getTodoLabels({
                    year: n,
                    month: o
                });
                let m = f.filter((e) => +e.year == +n && +e.month == +o);
                if (this.Component.weekMode) {
                    m = f;
                }
                const D = y.concat(m);
                for (let e of D) {
                    let t;
                    if (this.Component.weekMode ? (t = a.find((t) => +e.year == +t.year && +e.month == +t.month && +e.day == +t.day)) : (t = a[e.day - 1])) {
                        t.showTodoLabel = !!d || !t.choosed;
                        if (t.showTodoLabel && e.todoText) {
                            t.todoText = e.todoText;
                        }
                        if (e.todoLabelColor) {
                            t.todoLabelColor = e.todoLabelColor;
                        }
                    }
                }
                const p = {
                    'calendar.days': a,
                    'calendar.todoLabels': (0, r.uniqueArrayByDate)(f.concat(b))
                };
                c || (i && i !== h && (p['calendar.todoLabelPos'] = i), l && l !== u && (p['calendar.todoLabelColor'] = l));
                p['calendar.todoLabelCircle'] = c || false;
                p['calendar.showLabelAlways'] = d || false;
                this.setData(p);
            }
            deleteTodoLabels(e) {
                if (!(e instanceof Array && e.length)) {
                    return;
                }
                const t = this.filterTodos(e);
                const { days: a, curYear: n, curMonth: o } = this.getData('calendar');
                const r = t.filter((e) => n === +e.year && o === +e.month);
                a.forEach((e) => {
                    e.showTodoLabel = false;
                });
                r.forEach((e) => {
                    a[e.day - 1].showTodoLabel = !a[e.day - 1].choosed;
                });
                this.setData({
                    'calendar.days': a,
                    'calendar.todoLabels': t
                });
            }
            clearTodoLabels() {
                const { days: e = [] } = this.getData('calendar');
                const t = [].concat(e);
                t.forEach((e) => {
                    e.showTodoLabel = false;
                });
                this.setData({
                    'calendar.days': t,
                    'calendar.todoLabels': []
                });
            }
            getTodoLabels(e) {
                const { todoLabels: t = [] } = this.getData('calendar');
                if (e) {
                    const { year: a, month: n } = e;
                    return t.filter((e) => +e.year == +a && +e.month == +n);
                }
                return t;
            }
            filterTodos(e) {
                const t = this.getData('calendar.todoLabels') || [];
                const a = e.map((e) => c.toTimeStr(e));
                return t.filter((e) => !a.includes(c.toTimeStr(e)));
            }
            showTodoLabels(e, t, a) {
                e.forEach((e) => {
                    if (this.Component.weekMode) {
                        t.forEach((n, o) => {
                            if (+n.day == +e.day) {
                                const n = t[o];
                                n.hasTodo = true;
                                n.todoText = e.todoText;
                                if (a && a.length && +a[0].day == +e.day) {
                                    n.showTodoLabel = true;
                                }
                            }
                        });
                    } else {
                        const n = t[e.day - 1];
                        if (!n) {
                            return;
                        }
                        n.hasTodo = true;
                        n.todoText = e.todoText;
                        if (a && a.length && +a[0].day == +e.day) {
                            t[a[0].day - 1].showTodoLabel = true;
                        }
                    }
                });
            }
        }
        t.default = (e) => new l(e);
    },
    function (e, t, a) {
        'use strict';

        var n;
        var o =
            (n = a(5)) && n.__esModule
                ? n
                : {
                      default: n
                  };
        var r = a(1);
        var s = (function (e) {
            if (e && e.__esModule) {
                return e;
            }
            var t = {};
            if (null != e) {
                for (var a in e) {
                    if (Object.prototype.hasOwnProperty.call(e, a)) {
                        var n = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(e, a) : {};
                        if (n.get || n.set) {
                            Object.defineProperty(t, a, n);
                        } else {
                            t[a] = e[a];
                        }
                    }
                }
            }
            t.default = e;
            return t;
        })(a(9));
        const c = new r.Slide();
        const l = new r.Logger();
        
    },
    function (e, t, a) {
        'use strict';

        Object.defineProperty(t, '__esModule', {
            value: true
        });
        t.getCurrentYM = L;
        t.getSelectedDay = v;
        t.cancelAllSelectedDay = W;
        t.jump = A;
        t.setTodoLabels = x;
        t.deleteTodoLabels = O;
        t.clearTodoLabels = Y;
        t.getTodoLabels = E;
        t.disableDay = P;
        t.enableArea = I;
        t.enableDays = j;
        t.setSelectedDays = $;
        t.getCalendarConfig = G;
        t.setCalendarConfig = U;
        t.getCalendarDates = F;
        t.chooseDateArea = N;
        t.setDateStyle = R;
        t.switchView = X;
        t.default = t.calculateNextWeekDays = t.calculatePrevWeekDays = t.whenMulitSelect = t.whenChooseArea = t.whenSingleSelect = t.renderCalendar = t.whenChangeDate = void 0;
        var n = f(a(3));
        var o = f(a(5));
        var r = f(a(7));
        var s = f(a(0));
        var c = f(a(6));
        var l = f(a(4));
        var i = f(a(2));
        var d = a(1);
        function f(e) {
            return e && e.__esModule
                ? e
                : {
                      default: e
                  };
        }
        let b = {};
        let h = new d.Logger();
        let u = new d.GetDate();
        let y = null;
        function m(e) {
            if (e) {
                b = (0, d.getComponent)(e);
            }
            return b;
        }
        function D(e, t) {
            m(t);
            return (y = new s.default(b)).getData(e);
        }
        function p(e, t = () => {}) {
            return new s.default(b).setData(e, t);
        }
        const g = {
            renderCalendar(e, t, a) {
                if ((0, d.isComponent)(this)) {
                    b = this;
                }
                return new Promise((n, o) => {
                    (0, c.default)(b)
                        .renderCalendar(e, t, a)
                        .then((o = {}) => {
                            if (!o.firstRender) {
                                return n({
                                    year: e,
                                    month: t,
                                    date: a
                                });
                            }
                            !(function (e) {
                                e.calendar = {
                                    jump: A,
                                    switchView: X,
                                    disableDay: P,
                                    enableArea: I,
                                    enableDays: j,
                                    chooseDateArea: N,
                                    getCurrentYM: L,
                                    getSelectedDay: v,
                                    cancelAllSelectedDay: W,
                                    setDateStyle: R,
                                    setTodoLabels: x,
                                    getTodoLabels: E,
                                    deleteTodoLabels: O,
                                    clearTodoLabels: Y,
                                    setSelectedDays: $,
                                    getCalendarConfig: G,
                                    setCalendarConfig: U,
                                    getCalendarDates: F
                                };
                            })((0, d.getCurrentPage)());
                            b.$emit('afterCalendarRender', {
                                detail: b
                            });
                            b.firstRender = true;
                            d.initialTasks.flag = 'finished';
                            if (d.initialTasks.tasks.length) {
                                d.initialTasks.tasks.shift()();
                            }
                            n({
                                year: e,
                                month: t,
                                date: a
                            });
                        })
                        .catch((e) => {
                            o(e);
                        });
                });
            },
            whenChangeDate({ curYear: e, curMonth: t, newYear: a, newMonth: n }) {
                b.$emit('whenChangeMonth', {
                    detail: {
                        current: {
                            year: e,
                            month: t
                        },
                        next: {
                            year: a,
                            month: n
                        }
                    }
                });
            },
            whenMulitSelect(e) {
                if ((0, d.isComponent)(this)) {
                    b = this;
                }
                const { calendar: t = {} } = D();
                const { days: a, todoLabels: n } = t;
                const o = (0, l.default)(b).getCalendarConfig();
                let { selectedDay: r = [] } = t;
                const s = a[e];
                if (s) {
                    s.choosed = !s.choosed;
                    if (s.choosed) {
                        s.cancel = false;
                        const { showLabelAlways: e } = D('calendar');
                        if (e && s.showTodoLabel) {
                            s.showTodoLabel = true;
                        } else {
                            s.showTodoLabel = false;
                        }
                        o.takeoverTap || r.push(s);
                    } else {
                        s.cancel = true;
                        const e = u.toTimeStr(s);
                        r = r.filter((t) => e !== u.toTimeStr(t));
                        if (n) {
                            n.forEach((t) => {
                                if (e === u.toTimeStr(t)) {
                                    s.showTodoLabel = true;
                                }
                            });
                        }
                    }
                    if (o.takeoverTap) {
                        return b.$emit('onTapDay', {
                            detail: s
                        });
                    }
                    p({
                        'calendar.days': a,
                        'calendar.selectedDay': r
                    });
                    g.afterTapDay(s, r);
                }
            },
            whenSingleSelect(e) {
                if ((0, d.isComponent)(this)) {
                    b = this;
                }
                const { calendar: t = {} } = D();
                const { days: a, selectedDay: n = [], todoLabels: o } = t;
                let s = [];
                const c = a[e];
                if (!c) {
                    return;
                }
                const i = (n[0] || {}).day;
                const f = (i && a[i - 1]) || {};
                const { month: h, year: u } = a[0] || {};
                const y = (0, l.default)(b).getCalendarConfig();
                if (y.takeoverTap) {
                    return b.$emit('onTapDay', {
                        detail: c
                    });
                }
                g.afterTapDay(c);
                if (!y.inverse && f.day === c.day) {
                    return;
                }
                if (b.weekMode) {
                    a.forEach((e, t) => {
                        if (e.day === i) {
                            a[t].choosed = false;
                        }
                    });
                }
                if (o) {
                    s = o.filter((e) => +e.year === u && +e.month === h);
                }
                (0, r.default)(b).showTodoLabels(s, a, n);
                const m = {
                    'calendar.days': a
                };
                if (f.day !== c.day) {
                    f.choosed = false;
                    c.choosed = true;
                    (t.showLabelAlways && c.showTodoLabel) || (c.showTodoLabel = false);
                    m['calendar.selectedDay'] = [c];
                } else {
                    if (y.inverse) {
                        c.choosed = !c.choosed;
                        if (c.choosed) {
                            if (c.showTodoLabel && t.showLabelAlways) {
                                c.showTodoLabel = true;
                            } else {
                                c.showTodoLabel = false;
                            }
                        }
                        m['calendar.selectedDay'] = [];
                    }
                }
                p(m);
            },
            gotoSetContinuousDates: (e, t) => N([`${u.toTimeStr(e)}`, `${u.toTimeStr(t)}`]),
            timeRangeHelper(e, t) {
                const a = (0, d.getDateTimeStamp)(e);
                const n = t[0];
                let o;
                let r;
                let s = t.length;
                if (s > 1) {
                    o = t[s - 1];
                    r = (0, d.getDateTimeStamp)(o);
                }
                return {
                    endDate: o,
                    startDate: n,
                    currentDateTimestamp: a,
                    endDateTimestamp: r,
                    startTimestamp: (0, d.getDateTimeStamp)(n)
                };
            },
            calculateDateRange(e, t) {
                const { endDate: a, startDate: n, currentDateTimestamp: o, endDateTimestamp: r, startTimestamp: s } = this.timeRangeHelper(e, t);
                let c = [];
                let l = t.length;
                const i = t.filter((t) => u.toTimeStr(t) === u.toTimeStr(e));
                if (2 === l && i.length) {
                    return (c = [e, e]);
                }
                if (o >= s && r && o <= r) {
                    if (l / 2 > t.findIndex((t) => u.toTimeStr(t) === u.toTimeStr(e))) {
                        c = [e, a];
                    } else {
                        c = [n, e];
                    }
                } else {
                    if (o < s) {
                        c = [e, a];
                    } else {
                        if (o > s) {
                            c = [n, e];
                        }
                    }
                }
                return c;
            },
            whenChooseArea(e) {
                return new Promise((t, a) => {
                    if ((0, d.isComponent)(this)) {
                        b = this;
                    }
                    if (b.weekMode) {
                        return;
                    }
                    const { days: n = [], selectedDay: o, lastChoosedDate: r } = D('calendar');
                    const s = n[e];
                    if (!s.disable) {
                        if ((0, l.default)(b).getCalendarConfig().takeoverTap) {
                            return b.$emit('onTapDay', {
                                detail: s
                            });
                        }
                        if (o && o.length > 1) {
                            const e = g.calculateDateRange(s, u.sortDates(o));
                            return g
                                .gotoSetContinuousDates(...e)
                                .then((e) => {
                                    t(e);
                                    g.afterTapDay(s);
                                })
                                .catch((e) => {
                                    a(e);
                                    g.afterTapDay(s);
                                });
                        }
                        if (r || (o && 1 === o.length)) {
                            const e = r || o[0];
                            let n = [e, s];
                            const c = (0, d.getDateTimeStamp)(s);
                            if ((0, d.getDateTimeStamp)(e) > c) {
                                n = [s, e];
                            }
                            return g
                                .gotoSetContinuousDates(...n)
                                .then((e) => {
                                    t(e);
                                    g.afterTapDay(s);
                                })
                                .catch((e) => {
                                    a(e);
                                    g.afterTapDay(s);
                                });
                        }
                        n.forEach((e) => {
                            if (+e.day == +s.day) {
                                e.choosed = true;
                            } else {
                                e.choosed = false;
                            }
                        });
                        this.setData({
                            'calendar.days': [...n],
                            'calendar.lastChoosedDate': s
                        });
                    }
                });
            },
            afterTapDay(e, t) {
                const a = (0, l.default)(b).getCalendarConfig();
                const { multi: n } = a;
                if (n) {
                    b.$emit('afterTapDay', {
                        detail: {
                            currentSelected: e,
                            selectedDates: t
                        }
                    });
                } else {
                    b.$emit('afterTapDay', {
                        detail: e
                    });
                }
            },
            jumpToToday: () =>
                new Promise((e, t) => {
                    const { year: a, month: n, date: o } = u.todayDate();
                    const r = u.todayTimestamp();
                    const s = (0, l.default)(b).getCalendarConfig();
                    p({
                        'calendar.curYear': a,
                        'calendar.curMonth': n,
                        'calendar.selectedDay': [
                            {
                                year: a,
                                day: o,
                                month: n,
                                choosed: true,
                                lunar: s.showLunar ? i.default.solar2lunar(a, n, o) : null
                            }
                        ],
                        'calendar.todayTimestamp': r
                    });
                    g.renderCalendar(a, n, o)
                        .then(() => {
                            e({
                                year: a,
                                month: n,
                                date: o
                            });
                        })
                        .catch(() => {
                            t('jump failed');
                        });
                })
        };
        const T = g.whenChangeDate;
        t.whenChangeDate = T;
        const C = g.renderCalendar;
        t.renderCalendar = C;
        const w = g.whenSingleSelect;
        t.whenSingleSelect = w;
        const M = g.whenChooseArea;
        t.whenChooseArea = M;
        const _ = g.whenMulitSelect;
        t.whenMulitSelect = _;
        const S = g.calculatePrevWeekDays;
        t.calculatePrevWeekDays = S;
        const k = g.calculateNextWeekDays;
        function L(e) {
            m(e);
            return {
                year: D('calendar.curYear'),
                month: D('calendar.curMonth')
            };
        }
        function v(e) {
            m(e);
            return D('calendar.selectedDay');
        }
        function W(e) {
            m(e);
            const t = [...D('calendar.days')];
            t.map((e) => {
                e.choosed = false;
            });
            p({
                'calendar.days': t,
                'calendar.selectedDay': []
            });
        }
        function A(e, t, a, n) {
            return new Promise((r, s) => {
                m(n);
                const { selectedDay: c = [], weekMode: l } = D('calendar') || {};
                const { year: i, month: d, day: f } = c[0] || {};
                if (+i != +e || +d != +t || +f != +a) {
                    if (l) {
                        return (0, o.default)(b)
                            .jump({
                                year: e,
                                month: t,
                                day: a
                            })
                            .then((e) => {
                                r(e);
                            })
                            .catch((e) => {
                                s(e);
                            });
                    }
                    if (e && t) {
                        if ('number' != typeof +e || 'number' != typeof +t) {
                            return h.warn('jump 函数年月日参数必须为数字');
                        }
                        const n = u.todayTimestamp();
                        p(
                            {
                                'calendar.curYear': e,
                                'calendar.curMonth': t,
                                'calendar.todayTimestamp': n
                            },
                            () => {
                                g.renderCalendar(e, t, a)
                                    .then((e) => {
                                        r(e);
                                    })
                                    .catch((e) => {
                                        s(e);
                                    });
                            }
                        );
                    } else {
                        g.jumpToToday()
                            .then((e) => {
                                r(e);
                            })
                            .catch((e) => {
                                s(e);
                            });
                    }
                }
            });
        }
        function x(e, t) {
            m(t);
            (0, r.default)(b).setTodoLabels(e);
        }
        function O(e, t) {
            m(t);
            (0, r.default)(b).deleteTodoLabels(e);
        }
        function Y(e) {
            m(e);
            (0, r.default)(b).clearTodoLabels();
        }
        function E(e) {
            m(e);
            return (0, r.default)(b).getTodoLabels();
        }
        function P(e = [], t) {
            m(t);
            (0, n.default)(b).disableDays(e);
        }
        function I(e = [], t) {
            m(t);
            (0, n.default)(b).enableArea(e);
        }
        function j(e = [], t) {
            m(t);
            (0, n.default)(b).enableDays(e);
        }
        function $(e, t) {
            m(t);
            (0, n.default)(b).setSelectedDays(e);
        }
        function G(e) {
            m(e);
            return (0, l.default)(b).getCalendarConfig();
        }
        function U(e, t) {
            m(t);
            if (!e || 0 === Object.keys(e).length) {
                return h.warn('setCalendarConfig 参数必须为非空对象');
            }
            const a = G();
            return new Promise((t, n) => {
                (0, l.default)(b)
                    .setCalendarConfig(e)
                    .then((n) => {
                        t(n);
                        const o = 'disableLaterDay' in e && a.disableLaterDay !== e.disableLaterDay;
                        const r = 'disablePastDay' in e && a.disablePastDay !== e.disablePastDay;
                        if (o || r) {
                            const { year: e, month: t } = L();
                            A(e, t);
                        }
                    })
                    .catch((e) => {
                        n(e);
                    });
            });
        }
        function F(e) {
            m(e);
            return D('calendar.days', e);
        }
        function N(e, t) {
            m(t);
            return (0, n.default)(b).chooseArea(e);
        }
        function R(e, t) {
            if (e) {
                m(t);
                (0, n.default)(b).setDateStyle(e);
            }
        }
        function X(...e) {
            return new Promise((t, a) => {
                const n = e[0];
                if (!e[1]) {
                    return (0, o.default)(b).switchWeek(n).then(t).catch(a);
                }
                if ('string' == typeof e[1]) {
                    m(e[1]);
                    (0, o.default)(b).switchWeek(n, e[2]).then(t).catch(a);
                } else {
                    if ('object' == typeof e[1]) {
                        if ('string' == typeof e[2]) {
                            m(e[1]);
                        }
                        (0, o.default)(b).switchWeek(n, e[1]).then(t).catch(a);
                    }
                }
            });
        }
        function Z(e, t) {
            d.initialTasks.flag = 'process';
            (b = e).config = t;
            (function (e) {
                let t = ['日', '一', '二', '三', '四', '五', '六'];
                if ('Mon' === e) {
                    t = ['一', '二', '三', '四', '五', '六', '日'];
                }
                p({
                    'calendar.weeksCh': t
                });
            })(t.firstDayOfWeek);
            (function (e) {
                if (e && 'string' == typeof e) {
                    const t = e.split('-');
                    if (t.length < 3) {
                        return h.warn('配置 jumpTo 格式应为: 2018-4-2 或 2018-04-02');
                    }
                    A(+t[0], +t[1], +t[2]);
                } else {
                    e || (b.config.noDefault = true);
                    A();
                }
            })(t.defaultDay);
            h.tips('使用中若遇问题请反馈至 https://github.com/treadpit/wx_calendar/issues ✍️');
        }
        t.calculateNextWeekDays = k;
        t.default = (e, t = {}) => {
            if ('process' === d.initialTasks.flag) {
                return d.initialTasks.tasks.push(function () {
                    Z(e, t);
                });
            }
            Z(e, t);
        };
    }
]);
</script>
<style>
@import './index.css';
</style>
