<template>
	<view>
		<view class="popup-title">
			<text class="popup-cancel" @tap="serveCancel"><text v-if="showCancel">取消</text></text>
			<text class="popup-title-text">选择约玩项目</text>
			<text class="popup-ok-btn" @tap="serveConfirm()" v-if="showConfirm">确认</text>
		</view>
		<view class="cu-load loading" style="height: 300rpx;" v-if="projects.length == 0"></view>
		<view class="project-list">
			<view class="project-item" 
			v-for="(item,indexx) in projects" 
			:class="item.id === sid ? 'active' : 'default'"
			@click="onProject(item)">
				<view class="my-icon-menu-img">
					 <image :src="imagebaseurl + item.logo" style=""></image>
				</view>
				<text>{{item.title}}</text>
			</view>
		</view>
		
	</view>
</template>

<script>
	const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
	export default {
		props: {
			showConfirm: {
			    type: Boolean,
			    default: true
			},
			showCancel: {
			    type: Boolean,
			    default: true
			},
			serveId: {
				type: Number,
				default: 0
			},
			goodsId: {
			    type: String,
			    default: ''
			}
		},
	    data() {
	        return {
				projects: [],
				sid: '',
				loading: false ,// 控制加载动画的显示与隐藏
				imagebaseurl: getApp().globalData.fileDomain,
				}
			},
			mounted: function () {
				this.sid = this.serveId;
				this.getProjects();
			},
			methods: {
				onProject(item){
					this.sid = item.id;
					// this.$emit("update:serveId", item.id);
					// this.$emit("update:price", item.price);
					// this.$emit("update:projectName", item.title);
					// this.$emit("update:attId", item.attId);
					if(!this.showConfirm) {
						this.$emit("toConfirm",item);
					}
				},
				serveConfirm(){
					this.$emit("toConfirm",this.projects.find(item=> item.id == this.sid));
				},
				serveCancel(){
					this.$emit("toCancel");
				},
				getProjects(){
					WXAPI.serveList({
						bestId: this.goodsId,
						type: 1
					}).then((res) => {
						if(res.code==200){
							this.projects = res.data;
						}
					});
				},
				
			}
		};
</script>

<style>
	.project-list{
		width: 100%;
		display: flex;
		flex-wrap: wrap;
		margin-top: 20rpx;
		margin-bottom: 20rpx;
	}
	.project-item{
		width: 30%;
		text-align: center;
		padding: 20rpx;
		margin: 10rpx;
		border-radius: 20rpx;
		font-size: 24rpx;
	}
	.project-item image{
		width: 80rpx;
		height: 80rpx;
	}
	.active{
		background-color: #39b54a;
		color: white;
	}
	.default{
		background-color: #f6f7fd;
		color: black;
	}
	.popup-title{
		display: flex;
	}
	.popup-title text{
		width: 33.3%;
	}
	.popup-title-text{
		font-weight: bolder;
		text-align: center;
	}
	.popup-ok-btn{
		color: #39b54a;
		font-weight: bolder;
		text-align: right;
	}
	
</style>