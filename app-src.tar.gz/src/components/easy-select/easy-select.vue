<template>
	<view class="easy-select">
		<input type="text" v-model="value">
		<view class="easy-select-options" v-if="showOptions">
			<view class="sanjiao-top"></view>
			<view class="easy-select-options-item" v-for="item in options" :key="item.title" @click.stop="select(item)" :class="{active: value === item.title}">
				<text>{{item.title}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	/**
	 * easy-select
	 * @author Snoop zhang
	 * @description Select Component
	 * */
	
	export default {
		props: {
			windowHeight: {
				type: [Number, String],
				default: 0
			},
			placeholder: {
				type: String,
				default: '请选择'
			},
			value: {
				type: String,
				default: ''
			},
			size: {
				type: String,
				default: 'medium'
			},
			options: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				showOptions: false,
			}
		},
		computed: {
			// showSuffix() {
			// 	return this.showOptions ? 'showOptions' : 'no-showOptions'
			// },
		},
		mounted() {
		},
		methods: {
	
			select(options) {
				this.showOptions = false
				this.$emit('selectOne', options)
			},
			hideOptions() {
				this.showOptions = true;
			}
		}
	}
</script>

<style scoped>
	.easy-select {
		position: relative;
		/* border: 1px solid #dcdfe6; */
		border-radius: 4px;
		font-size: 36rpx;
		color: #333;
		outline: none;
		box-sizing: content-box;
		height: 30px;
	}
	.sanjiao-top{
		position: absolute;
		width: 20px;
		height: 10px;
		background: url(/static/images/icon/sanjiao-top.png) no-repeat center center;
		background-size: cover;
		left: 15px;
		top: -10px;
	}
	.easy-select input {
		/* padding: 0 18rpx; */
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
		height: 100% !important;
		min-height: 100% !important;
		color: #737373;
		pointer-events: none;
		user-select: none;
		font-family: NewYork;
	}

	.easy-select .easy-select-suffix {
		position: absolute;
		box-sizing: border-box;
		height: 100%;
		right: 5px;
		top: 0;
		display: flex;
		align-items: center;
		transform: rotate(180deg);
		transition: all .3s;
		transform-origin: center;
	}

	.easy-select .showOptions {
		transform: rotate(0) !important;
	}

	.easy-select .no-showOptions {
		transform: rotate(180deg) !important;
	}

	.easy-select .easy-select-options {
		position: absolute;
		padding: 30rpx 30rpx 10rpx 32rpx;
		border: 1px solid #e4e7ed;
		border-radius: 10px;
		background-color: white;
		box-shadow: 0 2px 12px 0 rgba(0, 0, 0, .1);
		box-sizing: border-box;
		transform-origin: center top;
		z-index: 2238;
		width: 375px;
		top:30px
	}

	.easy-select .easy-select-options-item {
		padding: 6rpx 20rpx;
		position: relative;
		white-space: nowrap;
		font-size: 12px;
		color: black;
		box-sizing: border-box;
		float: left;
		border: 1px solid #68AFEF;
		border-radius: 4rpx;
		margin-bottom: 20rpx;
		margin-right: 36rpx;
		margin-left: 6rpx;
	}

	.easy-select .active {
		color: white;
		background-color: #68AFEF;
	}
</style>
