<template>
    <view style="height: 100%">
        <!-- components/share/index.wxml -->
        <view class="goods-button" @tap="switchShow">
            <image :src="icon"></image>
        </view>
        <view :class="'cu-modal bottom-modal ' + (show ? 'show' : '')" :style="'z-index: ' + zIndex + ';'">
            <view class="cu-dialog">
                <view class="cu-bar bg-white">
                    <view></view>
                    <view class="action text-blue" @tap="switchShow">取消</view>
                </view>
                <view class="padding-xl">
                    <view class="flex share-list">
                        <view class="item">
                            <view><text class="cuIcon-weixin text-green lg"></text></view>
                            <view><text class="">微信</text></view>
                            <button open-type="share" class="share-btn" @tap="switchShow"></button>
                        </view>
                        <view class="item margin-left-lg">
                           <poster
                                id="poster"
                                @tap.native="onCreatePoster($event, { tagId: 'poster' })"
                                :config="posterConfig"
                                @success="onPosterSuccess($event, { tagId: 'poster' })"
                                @fail="onPosterFail($event, { tagId: 'poster' })"
                            >
                                <view><text class="cuIcon-picfill text-red lg"></text></view>
                                <view><text class="">海报</text></view>
                            </poster>
                        </view>
                    </view>
                </view>
            </view>
        </view>
        <view :class="'cu-modal  ' + (showPic ? 'show' : '')" :style="'z-index: ' + (zIndex + 1) + ';'">
            <view class="cu-dialog" :style="'width:' + dialogWidth + 'rpx;background: none;'">
                <view :style="'height: ' + dialogHeight + 'rpx;width: ' + dialogWidth + 'rpx;'">
                    <image :src="poster" style="height: 100%; width: 100%"></image>
                </view>
                <view class="cu-bar flex justify-between">
                    <!-- <view class="action flex justify-between" style="background: none;width: 100%;"> -->
                    <button class="cu-btn line-white text-white" @tap="hidePicModal">关闭</button>
                    <button class="cu-btn line-green text-white" @tap="saveToAlbum">保存到相册</button>
                    <!-- </view> -->
                </view>
            </view>
        </view>
    </view>
</template>

<script>
// import poster from './wxa-plugin-canvas/poster';
// components/share/index.js
// import Poster from './wxa-plugin-canvas/poster/poster';
// const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const AUTH = require('../../utils/auth');
var posterConfig = {
    width: 750,
    height: 1334,
    backgroundColor: '#fff',
    debug: false,
    pixelRatio: 1,
    blocks: [
        {
            width: 690,
            height: 808,
            x: 30,
            y: 183,
            borderWidth: 2,
            borderColor: '#f0c2a0',
            borderRadius: 20
        },
        {
            width: 634,
            height: 74,
            x: 59,
            y: 770,
            backgroundColor: '#fff',
            opacity: 0.5,
            zIndex: 100
        }
    ],
    texts: [
        {
            x: 113,
            y: 61,
            baseLine: 'middle',
            text: '伟仔',
            fontSize: 32,
            color: '#8d8d8d'
        },
        {
            x: 30,
            y: 113,
            baseLine: 'top',
            text: '发现一个好物，推荐给你呀',
            fontSize: 38,
            color: '#080808'
        },
        {
            x: 92,
            y: 810,
            fontSize: 38,
            baseLine: 'middle',
            text: '标题标题标题标题标题标题标题标题标题',
            width: 570,
            lineNum: 1,
            color: '#8d8d8d',
            zIndex: 200
        },
        {
            x: 59,
            y: 895,
            baseLine: 'middle',
            text: [
                {
                    text: '2人拼',
                    fontSize: 28,
                    color: '#ec1731'
                },
                {
                    text: '¥99',
                    fontSize: 36,
                    color: '#ec1731',
                    marginLeft: 30
                }
            ]
        },
        {
            x: 522,
            y: 895,
            baseLine: 'middle',
            text: '已拼2件',
            fontSize: 28,
            color: '#929292'
        },
        {
            x: 59,
            y: 945,
            baseLine: 'middle',
            fontSize: 28,
            color: '#929292',
            text: '错过再等一年'
        },
        {
            x: 360,
            y: 1065,
            baseLine: 'top',
            text: '长按识别小程序码',
            fontSize: 38,
            color: '#080808'
        },
        {
            x: 360,
            y: 1123,
            baseLine: 'top',
            text: '超值好货一起拼',
            fontSize: 28,
            color: '#929292'
        }
    ],
    images: [
        {
            width: 62,
            height: 62,
            x: 30,
            y: 30,
            borderRadius: 62,
            url: ''
        },
        {
            width: 634,
            height: 634,
            x: 59,
            y: 210,
            url: ''
        },
        {
            width: 220,
            height: 220,
            x: 92,
            y: 1020,
            url: ''
        },
        {
            width: 750,
            height: 90,
            x: 0,
            y: 1244,
            url: ''
        }
    ]
};
export default {
    components: {
        // poster
    },
    data() {
        return {
            show: true,

            posterConfig: {
                debug: false
            },

            showPic: false,
            dialogWidth: 550,

            //todo:是否可以高度充满屏幕,宽度自适应,避免底部按钮被遮盖?
            dialogHeight: 0,

            poster: ''
        };
    },
    options: {
        addGlobalClass: true
    },
    /**
     * 组件的属性列表
     */
    props: {
        icon: {
            type: String,
            default: '/static/images/share.png'
        },
        zIndex: {
            type: Number,
            default: 999999
        },
        goodsInfo: {
            type: Object,
            default: () => ({})
        },
        footerImage: {
            type: String,
            default: 'https://wwww.bestpw.cn/uploads/qrbg.png'
        }
    },
    mounted() {
        // 处理小程序 attached 生命周期
        this.attached();
    },
    /**
     * 组件的方法列表
     */
    methods: {
        attached() {
            const dialogWidth = this.dialogWidth;
            const dialogHeight = (posterConfig.height / posterConfig.width) * dialogWidth;
            this.setData({
                dialogHeight: dialogHeight
            });
        },

        switchShow() {
            this.setData({
                show: !this.show
            });
        },

        hidePicModal() {
            this.setData({
                showPic: false
            });
        },

        saveToAlbum() {
            const that = this;
            uni.saveImageToPhotosAlbum({
                filePath: this.poster,
                success() {
                    uni.showToast({
                        title: '保存成功',
                        icon: 'success'
                    });
                    that.setData({
                        showPic: false
                    });
                }
            });
        },

        async onCreatePoster(e, _dataset) {
            /* ---处理dataset begin--- */
            this.handleDataset(e, _dataset);
            /* ---处理dataset end--- */
            AUTH.checkHasLogined((isLogined) => {
                if (!isLogined) {
                    uni.showToast({
                        title: '请先登录',
                        icon: 'none'
                    });
                    return;
                }
            });
            const userInfoRes = await WXAPI.userDetail(uni.getStorageSync('bestpw-Token'));
            const userInfo = userInfoRes.data;
            posterConfig.images[0].url = 'https://www.bestpw.cn/uploads/logo.png'; //userInfo.base.avatarUrl
            posterConfig.images[1].url = this.goodsInfo.pic;
            posterConfig.images[3].url = this.footerImage;
            posterConfig.texts[0].text = userInfo.base.nick;
            posterConfig.texts[2].text = this.goodsInfo.name;
            if (this.goodsInfo.pingtuan) {
                posterConfig.texts[3].text[0].text = '拼团价';
                posterConfig.texts[3].text[1].text = '¥' + this.goodsInfo.pingtuanPrice;
            } else if (this.goodsInfo.kanjia) {
                posterConfig.texts[3].text[0].text = '砍价底价';
                posterConfig.texts[3].text[1].text = '¥' + this.goodsInfo.kanjiaPrice;
            } else {
                posterConfig.texts[3].text[0].text = '特惠价';
                posterConfig.texts[3].text[1].text = '¥' + this.goodsInfo.minPrice;
            }
            posterConfig.texts[4].text = '已售' + this.goodsInfo.numberOrders + '件';
            if (this.goodsInfo.characteristic) {
                posterConfig.texts[5].text = this.goodsInfo.characteristic;
            } else {
                posterConfig.texts[5].text = '手慢无';
            }
            const qrcodeRes = await WXAPI.wxaQrcode({
                scene: this.goodsInfo.id + ',' + uni.getStorageSync('uid'),
                page: 'pages/goods-details/index',
                //注意:如果已上线的小程序,如果此处路径在线上版本不存在的话也无法获取二维码
                is_hyaline: false,
                expireHours: 1
            });
            if (qrcodeRes.code != 0) {
                uni.showModal({
                    title: '错误',
                    content: '无法获取小程序码',
                    showCancel: false
                });
                return;
            }
            posterConfig.images[2].url = qrcodeRes.data;
            this.setData(
                {
                    posterConfig: posterConfig
                },
                () => {
                    Poster.create(true, this);
                }
            );
        },

        onPosterSuccess(e, _dataset) {
            /* ---处理dataset begin--- */
            this.handleDataset(e, _dataset);
            /* ---处理dataset end--- */
            const { detail } = e;
            this.setData({
                poster: detail,
                showPic: true,
                show: false
            }); //未解之谜:为什么在这里set dialogHeight不生效???
        },

        onPosterFail(e, _dataset) {
            /* ---处理dataset begin--- */
            this.handleDataset(e, _dataset);
            /* ---处理dataset end--- */
            console.log(e);
        }
    },
    created: function () {}
};
</script>
<style>
@import './index.css';
</style>
