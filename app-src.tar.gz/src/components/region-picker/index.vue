<template>
    <view style="height: 100%">
        <view class="bg"></view>
        <view class="container-box">
            <view class="h">
                <text>请选择</text>
                <image src="/static/images/icon/close.svg" @tap="close"></image>
            </view>
            <view class="tabs">
                <view v-if="index <= tabIndex" :class="'tab ' + (tabIndex == index ? 'active' : '')" :data-index="index" @tap="tabClick" v-for="(item, index) in tabs" :key="index">
                    {{ item }}
                </view>
            </view>
            <view class="data">
                <scroll-view scroll-y scroll-with-animation>
                    <view class="inner-box">
                        <view :class="item.active ? 'active' : ''" :data-index="index" @tap="clickFun" v-for="(item, index) in redionData" :key="index">{{ item.name }}</view>
                    </view>
                </scroll-view>
            </view>
        </view>
    </view>
</template>

<script>
// const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');

export default {
    data() {
        return {
            // tabs: ['省', '市', '区/县', '街道/镇', '社区/村委会'],
            tabs: ['省', '市', '区/县', '街道/镇'],

            tabIndex: 0,

            // 已选择
            selectRegion: [],

            redionData: ''
        };
    },
    options: {
        addGlobalClass: true
    },
    /**
     * 组件的对外属性，是属性名到属性设置的映射表
     */
    props: {
        activePos: String,
        level: {
            type: Number,
            default: 4
        }
    },
    mounted() {
        // 处理小程序 attached 生命周期
        this.attached();
    },
    destroyed: function () {
        // 在组件实例被从页面节点树移除时执行
    },
    /**
     * 组件的方法列表
     */
    methods: {
        attached: function () {
            this.provinces();
        },

        async provinces() {
            const res = await WXAPI.province();
            if (res.code == 0) {
                this.setData({
                    redionData: res.data
                });
            }
        },

        async clickFun(e) {
            const index = e.currentTarget.dataset.index;
            let redionData = this.redionData;
            const _curEntity = redionData[index];
            redionData.forEach((ele) => {
                ele.active = false;
            });
            _curEntity.active = true;
            this.selectRegion[this.tabIndex] = _curEntity;
            let tabIndex = this.tabIndex;
            const res = await WXAPI.nextRegion(_curEntity.id);
            if (res.code == 0) {
                tabIndex++;
                redionData = res.data;
            }
            this.setData({
                redionData: redionData,
                selectRegion: this.selectRegion,
                tabIndex
            });
            if (res.code != 0 || tabIndex === this.level) {
                this.$emit(
                    'selectAddress',
                    {
                        detail: this
                    },
                    {}
                );
                this.close();
            }
        },

        async tabClick(e) {
            const index = e.currentTarget.dataset.index;
            if (index == this.tabIndex) {
                return;
            }
            const selectRegion = this.selectRegion;
            selectRegion.splice(index);
            let redionData = this.redionData;
            if (index == 0) {
                const res = await await WXAPI.province();
                if (res.code == 0) {
                    redionData = res.data;
                }
            } else {
                const lastSelectEntity = selectRegion[selectRegion.length - 1];
                const res = await WXAPI.nextRegion(lastSelectEntity.id);
                if (res.code == 0) {
                    redionData = res.data;
                }
            }
            this.setData({
                tabIndex: index,
                selectRegion,
                redionData
            });
        },

        close() {
            this.$emit(
                'closeAddress',
                {
                    detail: {}
                },
                {}
            );
        }
    },
    created: function () {}
};
</script>
<style>
@import './index.css';
</style>
