<template>
	<view>
		<view class="popup-title">
			<text class="popup-cancel" @tap="timeCancel"><text v-if="showCancel">取消</text></text>
			<text class="popup-title-text">邀约时间</text>
			<text class="popup-ok-btn" @tap="timeConfirm()" v-if="showConfirm">确认</text>
		</view>
		<view class="tags-list">
			<view class="tags-title-text">
				<text>选择日期</text>
				<text style="float: right;">{{times[chooseDateIndex]}}</text>
			</view>
			<view class="day-list">
				<view v-for="(week,index) in weekDay">
					<text class="day-item" :class="index === chooseDateIndex ? 'active' : 'default'" @click="chooseDateIndex = index">{{week}}</text>
				</view>
			</view>
			<view class="date-list">
				<text class="date-item" v-for="(time,indexx) in times" :class="indexx === chooseDateIndex ? 'active' : 'default'" @click="chooseDateIndex = indexx">{{time}}</text>
			</view>
		</view>
		<view class="tags-list">
			<view class="tags-title-text">
				<text>选择时间</text>
				<text style="float: right;">{{timeArray[chooseTimeIndex]}}</text>
			</view>
			<view class="time-list">
				<text class="time-item" v-for="(time,indext) in timeArray" :class="indext === chooseTimeIndex ? 'active' : 'default'" @click="chooseTimeIndex = indext">{{time}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			showConfirm: {
			    type: Boolean,
			    default: true
			},
			showCancel: {
			    type: Boolean,
			    default: true
			},
			indexx: {
				type: Number,
				default: 0
			},
			date: {
				type: String,
				default: ''
			},
			time: {
				type: String,
				default: ''
			}
		},
	    data() {
	        return {
				times:[],
				weekDay: ["今天", "明天", "后天"],
				timeArray: ["90分钟到达", "14:00-17:00", "17:00-21:00", "18:00-22:00", "19:00-23:00", "20:00-24:00"],
				chooseDateIndex:'',
				chooseTimeIndex:'',
				}
			},
			mounted: function () {
				this.times = this.getTime();
			},
			watch: {
				chooseDateIndex(newValue, oldValue) {
					this.$emit('update:date', this.times[newValue])
				},
				chooseTimeIndex(newValue, oldValue) {
					this.$emit('update:time', this.timeArray[newValue])
				}
			},
			methods: {
				timeConfirm(){
					this.$emit("toConfirm",this.times[this.chooseDateIndex], this.timeArray[this.chooseTimeIndex]);
				},
				timeCancel(){
					this.$emit("toCancel");
				},
				getTime() {
					var date = new Date();
					var base = Date.parse(date); // 转换为时间戳
					var year = date.getFullYear(); //获取当前年份
					var mon = date.getMonth() + 1; //获取当前月份
					var day = date.getDate(); //获取当前日
					var oneDay = 24 * 3600 * 1000
					var daytime = `${year}-${mon >= 10 ? mon : '0' + mon}-${day >= 10 ? day : '0' + day}`; //今日时间
					var daytimeArr = [daytime]
					for (var i = 1; i < 3; i++) {
						var now = new Date(base += oneDay);
						var myear = now.getFullYear();
						var month = now.getMonth() + 1;
						var mday = now.getDate()
						daytimeArr.push([myear, month >= 10 ? month : '0' + month, mday >= 10 ? mday : '0' + mday].join('-'))
					}
					return daytimeArr
				},
			}
		};
</script>

<style>
	.active{
		background-color: #39b54a;
		color: white;
	}
	.default{
		background-color: #f6f7fd;
		color: black;
	}
	.popup-title{
		display: flex;
	}
	.popup-title text{
		width: 33.3%;
	}
	.popup-title-text{
		font-weight: bolder;
		text-align: center;
	}
	.popup-ok-btn{
		color: #39b54a;
		font-weight: bolder;
		text-align: right;
	}
	
	
	.tags-list{
		margin-top: 20rpx;
	}
	.tags-title-text{
		font-weight: bolder;
	}
	.time-list{
		padding: 20rpx 0;
		display: flex;
		flex-wrap: wrap;
	}
	.time-item{
		width: 30%;
		margin: 10rpx;
		text-align: center;
		padding: 16rpx 0rpx;
		border-radius: 10rpx;
	}
	.day-list{
		display: flex;
		flex-wrap: wrap;
		padding: 20rpx 0;
	}
	.date-list{
		display: flex;
		flex-wrap: wrap;
		padding: 20rpx 0;
	}
	.day-list{
		display: flex;
		flex-wrap: wrap;
		padding: 20rpx 0;
		margin-top: 20rpx;
	}
	.day-list view{
		width: 33.3%;
		text-align: center;
	}
	.day-item{
		width: 100rpx;
		margin: 10rpx;
		text-align: center;
		border-radius: 10rpx;
		padding: 16rpx 30rpx;
	}
	.date-item{
		width: 30%;
		margin: 10rpx;
		text-align: center;
		border-radius: 10rpx;
		padding: 16rpx 0rpx;
	}
	
</style>