<template>
    <view class="sales-goods" v-if="show">
        <view class="sales-title">{{ title }}</view>
        <view class="goods-list">
            <navigator class="goods-box" :url="'/pages_details/goods-details/index?id=' + item.id" v-for="(item, index) in list" :key="index">
                <view class="img-box">
                    <image :src="item.pic" class="image" mode="aspectFill" />
                    <view class="goods-characteristic">
                        <text>{{ item.characteristic }}</text>
                    </view>
                </view>

                <view class="goods-title">{{ item.name }}</view>

                <view style="display: flex">
                    <view class="goods-price">Ұ{{ item.minPrice }}</view>
                    <view class="goods-price-naver">已售{{ item.numberOrders }}</view>
                </view>
            </navigator>
        </view>
    </view>
</template>

<script>
// components/guess-u-like/index.js
// const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
export default {
    data() {
        return {
            list: []
        };
    },
    /**
     * 组件的属性列表
     */
    props: {
        title: {
            type: String,
            default: '猜你喜欢'
        },
        // 排序规则：priceUp 价格升序，priceDown 价格倒序，ordersUp 销量升序，ordersDown 销量降序，addedUp 发布时间升序，addedDown 发布时间倒序
        orderBy: {
            type: String,
            default: 'ordersDown'
        },
        count: {
            type: Number,
            default: 4
        },
        show: {
            type: Boolean,
            default: true
        },
        goods: {
            type: String,
            default: ''
        }
    },
    mounted() {
        // 处理小程序 attached 生命周期
        this.attached();
    },
    /**
     * 组件的方法列表
     */
    methods: {
        attached() {
            this.getList();
        },

        getList(value) {
            if (value && value != '') {
                let goodsIdArr = value.split(',');
                let goodsArr = [];
                for (let i = 0; i < goodsIdArr.length; i++) {
                    WXAPI.goodsDetail(goodsIdArr[i]).then((res) => {
                        if (res.code == 0) {
                            goodsArr.push(res.data.basicInfo);
                        }
                        this.setData({
                            list: goodsArr
                        });
                    });
                }
            } else {
                WXAPI.goods({
                    recommendStatus: 1,
                    orderBy: this.orderBy,
                    pageSize: this.count
                }).then((res) => {
                    if (res.code == 0) {
                        this.setData({
                            list: res.data
                        });
                    }
                });
            }
        }
    },
    created: function () {},
    watch: {
        goods: {
            handler: function (value) {
                if (value != '') {
                    this.getList(value);
                } else {
                    this.getList();
                }
            },

            immediate: true
        }
    }
};
</script>
<style>
@import './index.css';
</style>
