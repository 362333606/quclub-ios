<template>
    <view style="height: 100%">
        <view v-if="isClose" class="float-menu-cover" @tap="open">
            <image class="arrows" src="/static/images/icon/go-l.svg"></image>
            <view class="r">
                <text>快速</text>
                <text>导航</text>
            </view>
        </view>
        <view v-else class="float-menu-cover float-menu-cover-open" @tap="close">
            <image class="arrows" src="/static/images/icon/go-r.svg"></image>
            <view class="r">
                <text>快速</text>
                <text>导航</text>
            </view>
        </view>
        <view v-if="!isClose" class="float-menu-items">
            <navigator url="/pages/index/index" open-type="switchTab">
                <view class="item">
                    <image src="/static/images/nav/home-off.png"></image>
                    <text>首页</text>
                </view>
            </navigator>
            <navigator url="/pages/goods/list" open-type="switchTab">
                <view class="item">
                    <image src="/static/images/nav/best.png"></image>
                    <text>陪玩</text>
                </view>
            </navigator>
            <navigator url="/pages/shop/list" open-type="switchTab">
                <view class="item">
                    <image src="/static/images/nav/shop.png"></image>
                    <text>商户</text>
                </view>
            </navigator>
            <navigator url="/pages/my/index" open-type="switchTab">
                <view class="item">
                    <image src="/static/images/nav/my.png"></image>
                    <text>我的</text>
                </view>
            </navigator>
        </view>
    </view>
</template>

<script>
const app = getApp();
export default {
    data() {
        return {
            isClose: true
        };
    },
    options: {
        addGlobalClass: true
    },
    /**
     * 组件的对外属性，是属性名到属性设置的映射表
     */
    props: {
        activePos: String
    },
    mounted() {
        // 处理小程序 attached 生命周期
        this.attached();
    },
    destroyed: function () {
        // 在组件实例被从页面节点树移除时执行
    },
    /**
     * 组件的方法列表
     */
    methods: {
        attached: function () {
            this.setData({});
        },

        //回退
        open() {
            this.setData({
                isClose: false
            });
        },

        close() {
            this.setData({
                isClose: true
            });
        },

        navBack: function () {
            uni.navigateBack({
                delta: 1
            });
        },

        //回主页
        toIndex: function () {
            uni.navigateTo({
                url: '/pages/admin/home/index/index'
            });
        }
    },
    created: function () {}
};
</script>
<style>
@import './index.css';
</style>
