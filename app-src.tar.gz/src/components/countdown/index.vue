<template>
    <view style="height: 100%">
        <view class="contdown flex justify-center align-center" v-if="!isOver">
            <view class="icon">
                <image src="/static/images/clock.png"></image>
            </view>
            <text class="num bg-olive">{{ dateEnd.day }}</text>
            <text class="unit">天</text>
            <text class="num bg-olive">{{ dateEnd.hour }}</text>
            <text class="unit">时</text>
            <text class="num bg-olive">{{ dateEnd.minute }}</text>
            <text class="unit">分</text>
            <text class="num bg-olive">{{ dateEnd.seconds }}</text>
            <text class="unit">秒</text>
            <text class="end">后截止</text>
        </view>
        <view class="text-center text-grey text-lg" v-else>
            <text class="cuIcon-remind"></text>
            活动已结束！
        </view>
    </view>
</template>

<script>
const app = getApp();
import Countdown from '../../utils/wxCountdown.js';
export default {
    data() {
        return {
            isOver: false,

            dateEnd: {
                day: '',
                hour: '',
                minute: '',
                seconds: ''
            }
        };
    },
    options: {
        addGlobalClass: true
    },
    /**
     * 组件的对外属性，是属性名到属性设置的映射表
     */
    props: {
        date: String
    },
    mounted() {
        // 处理小程序 attached 生命周期
        this.attached();
    },
    destroyed: function () {
        // 在组件实例被从页面节点树移除时执行
    },
    /**
     * 组件的方法列表
     */
    methods: {
        attached: function () {
            const currentTime = new Date();
            const endTime = this.date.replace(/-/g, '/');
            if (currentTime.getTime() > new Date(endTime).getTime()) {
                uni.showToast({
                    title: '已结束',
                    icon: 'none',
                    duration: 2000
                });
                this.setData({
                    isOver: true
                });
            } else {
                Countdown.init(this.date, 'dateEnd', this);
            }
        }
    },
    created: function () {}
};
</script>
<style>
@import './index.css';
</style>
