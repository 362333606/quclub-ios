<template>
	<view class="upload-content">
		<view class="upload-item" v-for="(item, i) in imgs" :key="i" style="position: relative;">
			<video id="myVideo"
			:src="imagebaseurl+item"
			:poster="imagebaseurl + item + '?x-oss-process=video/snapshot,t_0,f_jpg'"
			:enable-progress-gesture="false" :controls="false" @play="pay(item)"></video>
			<uni-icons type="close" size="40" color="#ccc" class="clearVideoDiv" @click="delVideo"></uni-icons>
		</view>
		<view class="upload-item" @click="upLoadVideo()" v-if="imgs.length == 0">
			<uni-icons type="camera-filled" size="45" color="#c5d8f3"></uni-icons>
			<view class="upload-text">上传视频</view>
		</view>
		<q-previewImage :urls="previewImgs" ref="previewImage"></q-previewImage>
	</view>
</template>

<script>
	const app = getApp();
	export default {
		props: ['imgsUrl'],
	    data() {
	        return {
				previewImgs:[],
				upload:true,
				imagebaseurl: getApp().globalData.fileDomain,
				imgs:[],
				}
			},
			mounted: function () {
				this.videoContext = uni.createVideoContext('myVideo');
			},
			watch: {
				imgs(newValue, oldValue) {
					console.log('值发生了变化:', newValue);

					this.$emit('update:imgsUrl', newValue)
					if(newValue.length == 0) {
						this.upload = false;
					} else {
						this.upload = true;
					}
				}
			},
			methods: {
				pay(url) {
					this.videoContext.pause();
					this.previewImgs = [];
					this.previewImgs.push(url)
					this.$refs.previewImage.open(this.previewImgs[0]);
				},
				delVideo(i){
					this.imgs.splice(i, 1);
				},
				upLoadVideo() {
					let _this = this;
					uni.chooseVideo({
						maxDuration: 30,
					    sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
					    sourceType: ['album'], //从相册选择
					    success: function(res) {
							
							let videoFile = res.tempFilePath;
							if (res.size > 100*1024*1024) {
								uni.showToast({
									title:'视频大小不得高于100M',
									icon:"none"
								})
								return;
							}
							uni.showLoading({
								title: "上传中"
							});
							uni.uploadFile({
								url: app.globalData.api_root + '/upload', //接口地址
								filePath: videoFile,
								name: 'file',
								formData:{  //后台所需除图片外的参数可以写在这里面 ，单张多张都可
								    "type": 2, 
								},
								success: (res) => {
									let data = JSON.parse(res.data);
									uni.hideLoading();
									if(data.code == 200){
										_this.imgs.push(data.msg);
									}else {
										uni.showToast({
											 icon: 'none',
											 title: data.msg
										}); 
									}
								}
							});
						}
					})
				},
			}
		};
</script>

<style>
	.upload-content{
		width: 100%;
		display: inline-block;
	}
	.upload-item{
		width: 30%;
		background-color: #f2f3f3;
		margin-bottom: 20rpx;
		float: left;
		margin-left: 20rpx;
		height: 220rpx;
		text-align: center;
		flex-direction: column;
		display: flex;
		justify-content: center;
		border-radius: 4px;
	}
	.clearDiv{
		position: absolute;
		top: 0px;
		right: 0;
		text-align: center;
		margin: 0 auto;
		line-height: 20px;
	}
	#myVideo{
		width: auto;
	}
	.clearVideoDiv{
		position: absolute;
		top: 0px;
		right: -40px;
		text-align: center;
		margin: 0 auto;
		line-height: 20px;
	}
	
</style>