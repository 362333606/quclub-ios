<template>
	<view class="upload-content">
		<view class="upload-item" v-for="(item, i) in imgs" :key="i" style="position: relative;">
			<image class="uploadImage" :src="imagebaseurl+item" style="width: 100%;height: 100%;" @click="preview(imagebaseurl+item)"></image>
			<uni-icons type="close" size="30" color="#red" class="clearDiv" @click="delimg(i)"></uni-icons>
		</view>
		<view class="upload-item" @click="upLoadPhoto()" v-if="upload && imgs.length < 9">
			<uni-icons type="camera-filled" size="45" color="#c5d8f3"></uni-icons>
			<view class="upload-text">上传图片</view>
		</view>
		<q-previewImage :urls="imgs" ref="previewImage"></q-previewImage>
	</view>
	
</template>

<script>
	const app = getApp();
	export default {
		props: ['imgsUrl'],
	    data() {
	        return {
				upload:true,
				imagebaseurl: getApp().globalData.fileDomain,
				imgs:[],
				// previewImgs:[]
				}
			},
			mounted: function () {
			},
			watch: {
				imgs(newValue, oldValue) {
					console.log('值发生了变化:', newValue);

					this.$emit('update:imgsUrl', newValue)
					if(newValue.length == 9) {
						this.upload = false;
					} else {
						this.upload = true;
					}
				}
			},
			methods: {
				preview(url) {
					// this.image_list.push(imgs);
					this.$refs.previewImage.open(url);
				},
				delimg(i){
					this.imgs.splice(i, 1);
				},
				upLoadPhoto(){
					console.info(0)
					if(this.imgs.length >= 9){
						uni.showToast({
							title:'图片最多上传9张',
							icon:'none'
						})
						return;
					}
					let _this = this;
					uni.chooseImage({
					    count: 4,
					    sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
					    sourceType: ['album'], //从相册选择
					    success: function(res) {
							
							if(_this.imgs.length + res.tempFilePaths.length > 9){
								uni.showToast({
									title:'图片数量不能大于9张',
									icon:'none'
								})
								return;
							}
						
							var item = res.tempFiles.find(item=>{
								return item.size > 10*1024*1024
							})
							if(item){
								uni.showToast({
									title:'单张图片大小不得高于10M',
									icon:"none"
								})
								return;
							}
							
							const tempFilePaths = res.tempFilePaths;
							uni.showLoading({
								title: "上传中"
							});
							
							 for (let i = 0; i < tempFilePaths.length; i++) {
								 
								uni.uploadFile({
									url: app.globalData.api_root + '/upload', //接口地址
									filePath: tempFilePaths[i],
									name: 'file',
									formData:{  //后台所需除图片外的参数可以写在这里面 ，单张多张都可
									    //"token": uni.getStorageSync('bestpw-Token'), 
									},
									success: (res) => {
										
										let data = JSON.parse(res.data);
										uni.hideLoading();
										if(data.code == 200){
											_this.imgs.push(data.msg);
											
											// uni.showToast({
											// 	 icon: 'none',
											// 	 title: data.msg
											// }); 
											
										}else {
											_this.value.pop();
											uni.showToast({
												 icon: 'none',
												 title: data.msg
											}); 
										}
									}
								});
							 }
						}
					})
				},
			}
		};
</script>

<style>
	.upload-content{
		width: 100%;
		display: inline-block;
	}
	.upload-item{
		width: 30%;
		background-color: #f2f3f3;
		margin-bottom: 20rpx;
		float: left;
		margin-left: 20rpx;
		height: 220rpx;
		text-align: center;
		flex-direction: column;
		display: flex;
		justify-content: center;
		border-radius: 4px;
	}
	.clearDiv{
		position: absolute;
		top: 0px;
		right: 0;
		text-align: center;
		margin: 0 auto;
		line-height: 20px;
	}
	
</style>