<template>
	<view>
		<view class="popup-title">
			<text class="popup-cancel" @tap="timeCancel"><text v-if="showCancel">取消</text></text>
			<text class="popup-title-text">加小费</text>
			<text class="popup-ok-btn" @tap="timeConfirm()" v-if="showConfirm">确认</text>
		</view>
		<view class="cu-load loading" style="height: 300rpx;" v-if="gratuityArray.length == 0"></view>
		<view class="tags-list">
			<view class="time-list">
				<text class="time-item" v-for="(gratuit,indext) in gratuityArray" :class="indext === chooseIndex ? 'active' : 'default'" @click="timeConfirm(indext)">
					<text v-if="gratuit == 0">不加了</text>
					<text v-else><text style="font-size: 30rpx;margin-right: 4rpx;">{{gratuit}}</text>元</text>
				</text>
			</view>
		</view>
	</view>
</template>

<script>
	const WXAPI = require('@/miniprogram_npm/apifm-wxapi');
	export default {
		props: {
			showConfirm: {
			    type: Boolean,
			    default: true
			},
			showCancel: {
			    type: Boolean,
			    default: true
			},
			gratuity: {
				type: Number,
				default: 0
			},
		},
	    data() {
	        return {
				gratuityArray: [],
				chooseIndex:'',
				}
			},
			mounted: function () {
				this.getGratuity();
			},
			
			methods: {
				timeConfirm(indext){
					this.chooseIndex = indext;
					this.$emit("toConfirm",this.gratuityArray[this.chooseIndex]);
				},
				timeCancel(){
					this.$emit("toCancel");
				},
				getGratuity(){
					
					WXAPI.gratuityList().then((res) => {
						if(res.code==200){
							this.gratuityArray = res.data;
						}
					});
				},
			}
		};
</script>

<style>
	.active{
		background-color: #39b54a;
		color: white;
	}
	.default{
		background-color: #f6f7fd;
		color: black;
	}
	.popup-title{
		display: flex;
	}
	.popup-title text{
		width: 33.3%;
	}
	.popup-title-text{
		font-weight: bolder;
		text-align: center;
	}
	.popup-ok-btn{
		color: #39b54a;
		font-weight: bolder;
		text-align: right;
	}
	
	
	.tags-list{
		margin-top: 20rpx;
	}
	.tags-title-text{
		font-weight: bolder;
	}
	.time-list{
		padding: 20rpx 0;
		display: flex;
		flex-wrap: wrap;
	}
	.time-item{
		width: 30%;
		margin: 10rpx;
		text-align: center;
		padding: 16rpx 0rpx;
		border-radius: 10rpx;
	}
	.day-list{
		display: flex;
		flex-wrap: wrap;
		padding: 20rpx 0;
	}
	.date-list{
		display: flex;
		flex-wrap: wrap;
		padding: 20rpx 0;
	}
	.day-list{
		display: flex;
		flex-wrap: wrap;
		padding: 20rpx 0;
		margin-top: 20rpx;
	}
	.day-list view{
		width: 33.3%;
		text-align: center;
	}
	.day-item{
		width: 100rpx;
		margin: 10rpx;
		text-align: center;
		border-radius: 10rpx;
		padding: 16rpx 30rpx;
	}
	.date-item{
		width: 30%;
		margin: 10rpx;
		text-align: center;
		border-radius: 10rpx;
		padding: 16rpx 0rpx;
	}
	
</style>